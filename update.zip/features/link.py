# -*- coding: utf-8 -*-
"""클로드 코드와 이어주기 — 사명자들이 제일 많이 막히던 자리.

두 가지를 한다. 둘 다 켤 때 저절로 된다.

1. **깔려 있는 클로드를 찾아 기억해 둔다.**
   더블클릭으로 켠 프로그램은 `~/.local/bin` 같은 데를 모른다. 그래서
   깔아 놓고도 "안 깔려 있습니다" 가 떴다. 사람은 또 깔고, 또 못 찾고…
   찾은 자리를 config 에 적어 두면 다음부터 바로 잡힌다.

2. **아델이 무엇인지 적은 안내를 사용자 폴더에 놓는다.**
   사명자가 자기 클로드 코드를 열어 말을 걸면, 그 클로드는 이 폴더가
   뭐 하는 데인지 전혀 모른다. 그래서 이어가기가 안 됐다.
   폴더에 안내를 두면 클로드가 켤 때 읽는다.
"""
from __future__ import annotations

import json
import os
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from brain import HOME_DIR                                   # noqa: E402


def _dirs() -> list[Path]:
    """클로드가 깔릴 만한 자리를 넓게 본다.

    공식 설치 스크립트는 `~/.local/bin` 에 놓지만, npm 으로 깐 사람은
    nvm 폴더 안에 들어간다. 그것까지 안 보면 '깔려 있는데 없다' 가 또 난다.
    """
    home = Path.home()
    d = [home / ".local" / "bin", home / ".claude" / "bin", home / "bin"]
    if os.name == "nt":
        d += [home / "AppData" / "Local" / "Programs" / "claude",
              home / "AppData" / "Roaming" / "npm",
              home / "AppData" / "Local" / "npm",
              Path("C:/Program Files/nodejs")]
    else:
        d += [Path("/opt/homebrew/bin"), Path("/usr/local/bin"), Path("/usr/bin")]

    for base in (home / ".nvm" / "versions" / "node",         # nvm 으로 깐 경우
                 home / ".volta" / "bin", home / ".asdf" / "shims",
                 home / ".bun" / "bin", home / ".fnm" / "node-versions"):
        try:
            if base.name in ("bin", "shims"):
                d.append(base)
                continue
            for v in sorted(base.iterdir(), reverse=True)[:12]:   # 최신 것부터
                d.append(v / "bin")
                d.append(v / "installation" / "bin")
        except OSError:
            continue
    return d


def find() -> str:
    """깔려 있는 클로드 코드의 자리. 못 찾으면 빈 값."""
    hit = shutil.which("claude")
    if hit:
        return hit
    names = ("claude.exe", "claude.cmd", "claude.bat", "claude") if os.name == "nt" else ("claude",)
    for d in _dirs():
        for n in names:
            p = d / n
            try:
                if p.exists():
                    return str(p)
            except OSError:
                continue
    return ""


def remember(path: str) -> bool:
    """찾은 자리를 config 에 적어 둔다 — 다음부터 헤매지 않게.

    설정 파일이 아직 **없을 때도** 적어야 한다. 새로 깐 사람은 설정을 한 번도
    저장한 적이 없어 파일이 없는데, 전에는 여기서 조용히 포기했다 —
    그래서 클로드를 찾아 놓고도 안 적었고, 다음에 또 못 찾았다(2026-09-04).
    """
    cfg_p = HOME_DIR / "config.json"
    try:
        cfg = json.loads(cfg_p.read_text(encoding="utf-8"))
    except FileNotFoundError:
        cfg = {}                                             # 처음이다 — 새로 만든다
    except (OSError, ValueError):
        return False
    if (cfg.get("claude_bin") or "").strip() == path:
        return False                                         # 이미 같다
    cfg["claude_bin"] = path
    try:
        cfg_p.parent.mkdir(parents=True, exist_ok=True)
        cfg_p.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
        return True
    except OSError:
        return False



def remember_app() -> bool:
    """아델 실행파일이 어디 있는지 적어 둔다 — **클로드가 아델을 깨울 수 있게.**

    까닭: 설치를 클로드 코드로 마저 하려면 아델의 작은 서버(8471)가 떠 있어야
    하는데, 전에는 사람이 「아델 켜기」를 눌러 브라우저 창을 띄워 두어야만 했다.
    부장님 데스크탑 아델은 뒤에서 도는데 사명자만 창을 붙들고 있어야 했다.
    → 자리를 적어 두면 `setup.py` 가 `Adele --serve` 로 **조용히 깨운다.**

    구운 실행파일로 돌 때만 적는다(맨 파이썬으로 돌 때의 python 경로는 쓸모없다).
    """
    if not getattr(sys, "frozen", False):
        return False
    exe = sys.executable
    cfg_p = HOME_DIR / "config.json"
    try:
        cfg = json.loads(cfg_p.read_text(encoding="utf-8"))
    except FileNotFoundError:
        cfg = {}
    except (OSError, ValueError):
        return False
    if (cfg.get("app_path") or "").strip() == exe:
        return False
    cfg["app_path"] = exe
    try:
        cfg_p.parent.mkdir(parents=True, exist_ok=True)
        cfg_p.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
        return True
    except OSError:
        return False


# 업무 레이더 화면을 올려둔 곳. 전에는 넷리파이였는데 **그 자리가 비어 있어
# 404 였다**(2026-09-03 확인). 이미 깔린 아델은 옛 주소를 그대로 들고 있는데,
# 그 주소는 설치 화면(실행파일 안)에 박혀 있어 자동으로 못 고친다.
# 그래서 여기서 바로잡아 설정에 적어 둔다 — 이 파일은 자동으로 내려간다.
BOARD_SITE = "https://soanqn144000-tech.github.io/adele-dist"

# 자기 화면을 따로 올려 둔 사람은 config.json 의 `board_site` 에 그 주소를 적으면 된다
# (넷리파이든 어디든). 전에는 여기 있는 주소로 **말없이 덮어써서**, 자기가 올린 화면을
# 쓰던 사람이 어느 날 갑자기 남의 깃허브 주소를 보게 됐다(2026-09-04 실제로 겪음).
# 이제 적어 둔 자리가 있으면 그걸 쓰고, 우리가 덮어쓰는 건 죽은 옛 주소일 때뿐이다.
DEAD_SITES = ("adele-board.netlify.app", "adele-dash.netlify.app")


def site(cfg: dict | None = None) -> str:
    """내 대시보드 화면이 올라간 자리. 내가 정한 게 있으면 그게 먼저다."""
    c = cfg
    if c is None:
        try:
            c = json.loads((HOME_DIR / "config.json").read_text(encoding="utf-8"))
        except (OSError, ValueError):
            c = {}
    mine = (c.get("board_site") or "").strip().rstrip("/")
    if mine and not any(d in mine for d in DEAD_SITES):
        return mine
    return BOARD_SITE


def board_url(cfg: dict | None = None) -> str:
    """내 설정이 담긴 대시보드 주소. 파이어베이스가 없으면 빈 값.

    설정을 주소의 # 뒤에 싣는다 — # 뒤는 브라우저가 서버로 안 보낸다.
    그래서 화면을 올려둔 곳은 남의 파이어베이스를 알 수 없다.
    """
    import base64
    c = cfg
    if c is None:
        try:
            c = json.loads((HOME_DIR / "config.json").read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return ""
    if not (c.get("fb_api_key") and c.get("fb_project")):
        return ""
    payload = {"apiKey": c["fb_api_key"],
               "authDomain": c.get("fb_auth_domain") or f"{c['fb_project']}.firebaseapp.com",
               "projectId": c["fb_project"],
               "storageBucket": c.get("fb_bucket") or f"{c['fb_project']}.firebasestorage.app",
               "messagingSenderId": c.get("fb_sender", ""),
               "appId": c.get("fb_app_id", "")}
    blob = base64.b64encode(json.dumps(payload, ensure_ascii=False).encode()).decode()
    return f"{site(c)}/#{blob}"


def fix_board() -> str:
    """주소를 손봐야 할 때만 손본다. 바꿨으면 새 주소를 돌려준다.

    아무 때나 덮어쓰면 안 된다 — 자기 화면(넷리파이 등)을 쓰던 사람의 주소를
    말없이 남의 깃허브 주소로 바꿔 버린 적이 있다. 손대는 경우는 둘뿐이다.
      · 주소가 아직 없다
      · 들고 있는 주소가 **죽은 옛 자리**다 (404 나던 넷리파이)
    설정(`board_site`)이 정한 자리는 그대로 존중한다.
    """
    f = HOME_DIR / "config.json"
    try:
        c = json.loads(f.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return ""
    url = board_url(c)
    if not url:
        return ""
    now = (c.get("board_url") or "").strip()
    if now == url:
        return ""
    dead = any(d in now for d in DEAD_SITES)
    if now and not dead and not now.startswith(site(c) + "/"):
        return ""                                            # 스스로 정해 둔 자리 — 안 건드린다
    c["board_url"] = url                                     # 없거나 · 죽었거나 · 자리는 같고 설정만 바뀜
    try:
        f.write_text(json.dumps(c, ensure_ascii=False, indent=2), encoding="utf-8")
    except OSError:
        return ""
    return url

# ── 사명자의 클로드 코드에게 여기가 어디인지 알려준다 ──────────────────
GUIDE = """# 아델 — 이 폴더가 무엇인가

당신은 지금 **아델**의 폴더에 있습니다. 아델은 교회 사명자의 업무를 돕는
비서입니다. 이 글을 먼저 읽고 시작하십시오.

## 쓰는 사람

교회에서 일하는 사명자입니다. **개발자가 아닙니다.**

- **결론부터, 짧게, 존댓말로.** 과정 설명은 물어볼 때만
- 코드 이야기를 먼저 꺼내지 마십시오. "무엇이 어떻게 된다"로 말하십시오
- 복사·붙여넣기 심부름을 시키지 마십시오. 할 수 있으면 당신이 하십시오
- 터미널을 열라고 하지 마십시오. 그게 벽입니다

## 아델이 하는 일 다섯

**1. 텔레그램으로 말 걸면 답한다** (`features/listen.py`)
24시간 떠 있습니다. 물으면 읽고 답하고, 시키면 합니다.
바깥 소식(뉴스·시세·날씨)은 **반드시 검색해서** 답하고, 못 찾았으면 그렇다고 밝힙니다.

**2. 업무 레이더** (`features/radar.py`)
하루 세 번(13시·17시·21시) 텔레그램 방을 훑어 '무슨 일이 어디까지 왔나'를 정리해
보냅니다. 업무가 여러 사람에게 흩어져 있고 텔레그램은 흘러가 버려서,
'어느 일정에 무엇을 마감해야 하는가'가 안 보이는 것을 메우려고 만들었습니다.

돌아가는 모양 — **이 나눔을 지키십시오:**

    파이썬   수집 · 걸러내기 · 날짜계산 · 그리기 · 보내기
    클로드   읽고 판단해서 **업무 목록 JSON** 을 만든다

JSON 하나가 원본입니다. 텔레그램 글도 대시보드도 **같은 JSON** 에서 나옵니다.
따로 만들면 둘이 어긋납니다.

**3. 일정** (`features/cal.py`)
캘린더를 읽고, 말로 하면 넣습니다. 아이폰(아이클라우드)과 갤럭시(구글) 둘 다.
**앱 전용 암호**가 필요합니다 — 계정 비밀번호로는 안 됩니다.

**4. 차트** (`features/chart.py`)
막대·꺾은선·비교·도넛 넉 장. 이것으로 웬만한 보고는 됩니다.

**5. 텔레그램 창고 — 가장 핵심입니다** (`features/tgbox.py`)
사용자의 텔레그램 대화를 이 컴퓨터에 모아 두고(최근 30일 안에 말이 오간 방, 1년치) 찾습니다.
텔레그램 자체 검색은 띄어쓰기가 틀리면 못 찾지만 창고는 찾습니다. 어느 방이었는지 몰라도 찾습니다.
정한 시각에 방으로 **예약 메시지**도 보냅니다. 말 걸기(listen)가 켜져 있을 때 같이 돕니다.

    curl -s http://127.0.0.1:47633/tg/search -H "X-Adele: $(cat data/tgbox.key)" --data-binary '{"q":"출결보고"}'

창구: `search`(q·room·sender·since·until·any·full) · `rooms` · `status` · `sync` ·
`send`(미리보기, 실제로는 `"send": true`) · `plan/add`(room·text·time·repeat·date) · `plan/list` · `plan/remove`.
**낱말은 1~2개만** 쓰고, 못 찾으면 바꿔 가며 여러 번 찾으십시오. 답에는 날짜·방·보낸 사람을 붙이십시오.
창구가 안 열리면(연결 거부) 말 걸기가 꺼져 있는 것입니다 — 아델을 켜 달라고 하십시오.

## 이 폴더에 있는 것

    features/       기능 코드. **여기는 고쳐도 된다**
      listen.py       텔레그램으로 말 걸기 (24시간 상주)
      radar.py        업무 레이더 브리핑
      cal.py          일정
      chart.py        차트
      tgbox.py        텔레그램 창고 — 모으기·찾기·보내기·예약
      link.py         클로드 코드 이어주기 · 이 안내문
      remote.py       크롬을 대신 움직여 주기
    knowledge/      교회 용어·조직·보고 규칙 (**암호를 넣어야 풀린다**)
    내규칙.md        사용자가 쌓아온 규칙. 말 걸 때마다 먼저 읽힌다
    CLAUDE.md       이 글
    config.json     설정 — 텔레그램 토큰, 클로드 자리 등

## 반드시 지킬 것 넷

**① 날짜 계산을 당신이 하지 마십시오.**
D-day, '다음주 화요일이 며칠', '마감 임박' 판정 — 전부 파이썬이 셉니다.
모델에게 시키면 자주 틀립니다. 날짜·시각을 **뽑는 것**까지가 당신 몫입니다.

**② 말에 없는 숫자를 그리지 마십시오.**
차트를 그리기 전에 원문과 대조하십시오. 점이 모자라면 **안 그리고 그렇다고 말합니다.**
말 속에서 숫자를 주워 그리다 사고가 난 적이 있습니다.

**③ 지어내지 마십시오.**
마감·상태는 **원문에 있는 말에서만** 뽑습니다. 없으면 '없음'이라고 씁니다.
추측한 날짜를 만들지 마십시오. 모르면 모른다고 하는 편이 낫습니다.

**④ 고쳤으면 다시 켜라고 알려 주십시오.**
`features/` 안의 파일은 **프로그램을 다시 켜야** 적용됩니다.
고쳐놓고 말 안 하면 사용자는 '안 고쳐졌다'고 생각합니다.

## 설치를 마저 해달라고 하면

사용자가 "아델 설치 마저 해줘" 라고 하면 **아래 순서 그대로** 하십시오.
지어내지 말고 이 명령만 쓰십시오. 아델 폴더(이 폴더)에서 돌립니다.

    python3 features/setup.py 상태          ← 늘 이것부터. 남은 것만 짚어준다
    python3 features/setup.py 이름 <비서이름>  ← 사용자가 지어야 한다. 물어보십시오
    python3 features/setup.py 텔레그램 <api_id> <api_hash> <전화번호>
    python3 features/setup.py 인증번호 <받은번호> [2단계암호]
    python3 features/setup.py 봇만들기
    python3 features/setup.py 암호 <교회암호>
    python3 features/setup.py 방목록         ← 번호가 붙어 나온다
    python3 features/setup.py 방고르기 core=1,3 mixed=5
    python3 features/setup.py 파이어베이스     ← 크롬을 몰아서 대신 만든다. 몇 분 걸린다
    python3 features/setup.py 24시간켜기
    python3 features/setup.py 점검          ← 마지막에 반드시

지키실 것:

- **화면을 띄우라고 하지 마십시오.** 아델이 안 떠 있으면 setup.py 가 스스로
  뒤에서 깨웁니다(처음 한 번은 몇십 초 걸립니다). 정말 못 찾을 때만 그렇다고
  나오는데, 그때만 「아델 켜기」를 눌러 달라고 하십시오.
- **api_id · api_hash 는 사용자가 my.telegram.org 에서 받아와야 합니다.**
  그 사람 계정이라 대신 받을 수 없습니다. 전화번호와 인증번호도 물어보십시오.
- **교회 암호는 사용자에게 물어보십시오.** 부장님께 받은 것이 있습니다. 지어내지 마십시오.
- **방 고르기는 사용자가 골라야 합니다.** 목록을 보여드리고 몇 번인지 물어보십시오.
  `core` 는 우리 부서 전용 방, `mixed` 는 다른 부서가 섞인 방입니다.
- **파이어베이스는 크롬이 켜져 있고 구글 로그인이 되어 있어야** 합니다. 몇 분 걸리니
  기다리십시오. 안 되면 이유가 그대로 나옵니다 — **그 글을 사용자에게 그대로 보여주십시오.**
- 이 단계는 **건너뛰어도 됩니다.** 없으면 업무 레이더 화면만 못 쓰고 나머지는 다 됩니다.
- **점검에서 ✗ 가 하나라도 있으면 끝난 게 아닙니다.** 됐다고 말하지 마십시오.

텔레그램 로그인과 봇 만들기는 **설치 화면에서** 해야 합니다(전화번호·인증번호를
받아야 하므로). 그 둘이 아직이면 상태에 ✗ 로 나옵니다 — 사용자에게 설치 화면의
4번·5번 칸을 먼저 끝내시라고 안내하십시오.

## 사용자가 시키는 흔한 것들

| 이런 말을 들으면 | 이렇게 |
|---|---|
| "이렇게 기억해", "앞으로는 이렇게" | `내규칙.md` 에 적는다 |
| "이 기능 이렇게 바꿔줘" | `features/` 안의 파일을 고치고, 다시 켜라고 알린다 |
| "브리핑 형식 바꿔줘" | `radar.py` 의 렌더 부분 |
| "이 방도 봐줘 / 빼줘" | 설치 화면에서 방을 고르게 안내한다 |
| "왜 이렇게 나왔어" | 원문을 찾아 근거를 보여준다. 변명하지 않는다 |

## 교회 지식은 잠겨 있습니다

`knowledge/` 안의 교회 용어·조직·보고 규칙은 **암호를 넣어야 풀립니다.**
풀려 있으면 읽고 그 규칙대로 쓰십시오 — 교회에는 교회의 말투와 형식이 있습니다.
안 풀려 있으면 **일반적인 말로 지어내지 말고**, 암호를 넣으면 더 정확해진다고
알려 주십시오.

## 새 버전이 오면

`features/` 와 교회 지식은 6시간마다 저절로 받아옵니다.
사용자가 **고친 파일은 덮어쓰지 않고** 옆에 `.새버전` 을 붙여 놓습니다.
`새버전 알림.txt` 가 생겨 있으면, 두 파일을 견줘서 합쳐 주십시오 —
사용자가 고친 뜻은 살리고 새 것의 고침만 가져오는 식으로.

## 자주 막히는 곳

**"클로드 코드가 안 깔려 있습니다"** 인데 사실은 깔려 있는 경우
→ 프로그램이 `claude` 를 못 찾는 것입니다. `config.json` 의 `claude_bin` 에
실제 자리를 적으면 됩니다 (`link.py` 가 켤 때 알아서 합니다).

**로그인**
→ 대신 못 해 드립니다. 설치 화면의 `로그인 창 열기` 를 누르면 창이 열리고
브라우저가 뜹니다. 허용은 사람이 눌러야 합니다.

**검색이 안 될 때**
→ 조용히 옛날 이야기를 하지 마십시오. **"검색을 못 했습니다"를 먼저 밝히십시오.**

**캘린더가 안 붙을 때**
→ 열에 아홉은 **앱 전용 암호**를 안 쓰고 계정 비밀번호를 넣은 것입니다.
삼성 클라우드 캘린더는 통로가 없어 못 붙습니다 — 구글 쪽으로 안내하십시오.

**업무 레이더 화면이 비어 있을 때**
→ 아직 한 번도 안 돌았거나, 파이어베이스가 연결 안 된 것입니다.
설치 화면 `업무 레이더 화면` 칸에서 `아델이 대신 만들어 주기` 를 누르면 됩니다.

## 하지 말 것

- 사용자 몰래 설정을 바꾸는 것
- 사용자가 **분명히 시키지 않았는데** 남의 방에 글을 보내는 것 — 애매하면 미리보기를 보여주고 묻는다
- 교회 지식을 폴더 밖으로 옮겨 적는 것
- "됐습니다"라고 먼저 말하고 확인은 나중에 하는 것 — **돌려보고 말하십시오**
"""


def guide() -> bool:
    """안내를 사용자 폴더에 놓는다. 사람이 고쳐 뒀으면 건드리지 않는다."""
    p = HOME_DIR / "CLAUDE.md"
    try:
        if p.exists():
            old = p.read_text(encoding="utf-8")
            if "아델 — 이 폴더가 무엇인가" not in old:       # 사람이 쓴 것 → 그대로 둔다
                return False
            if old == GUIDE:
                return False
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(GUIDE, encoding="utf-8")
        return True
    except OSError:
        return False


def ensure() -> dict:
    """켤 때 한 번. 조용히 실패한다 — 이것 때문에 아델이 안 켜지면 안 된다."""
    out = {"found": "", "remembered": False, "guide": False, "board": "", "app": False}
    try:
        out["guide"] = guide()
        out["app"] = remember_app()                          # 클로드가 깨울 수 있게
        out["board"] = fix_board()                           # 옛 404 주소를 바로잡는다
        hit = find()
        out["found"] = hit
        if hit:
            out["remembered"] = remember(hit)
    except Exception:                                        # noqa: BLE001
        pass
    return out


if __name__ == "__main__":
    r = ensure()
    print(f"클로드 자리 : {r['found'] or '못 찾음'}")
    print(f"기억해 둠   : {r['remembered']}")
    print(f"안내 놓음   : {r['guide']}")
