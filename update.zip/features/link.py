# -*- coding: utf-8 -*-
"""클로드 코드와 이어주기 — 사명자들이 제일 많이 막히던 자리.

두 가지를 한다. 둘 다 켤 때 저절로 된다.

1. **깔려 있는 클로드를 찾아 기억해 둔다.**
   더블클릭으로 켠 프로그램은 `~/.local/bin` 같은 데를 모른다. 그래서
   깔아 놓고도 "안 깔려 있습니다" 가 떴다. 사람은 또 깔고, 또 못 찾고…
   찾은 자리를 config 에 적어 두면 다음부터 바로 잡힌다.

2. **아델이 무엇인지 적은 안내를 사용자 폴더에 놓는다.**
   사명자가 자기 클로드 코드를 열어 말을 걸면, 그 클로드는 이 폴더가
   뭐 하는 데인지 전혀 모른다. 그래서 이어가기가 안 됐다.
   폴더에 안내를 두면 클로드가 켤 때 읽는다.
"""
from __future__ import annotations

import json
import os
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from brain import HOME_DIR                                   # noqa: E402


def _dirs() -> list[Path]:
    """클로드가 깔릴 만한 자리를 넓게 본다.

    공식 설치 스크립트는 `~/.local/bin` 에 놓지만, npm 으로 깐 사람은
    nvm 폴더 안에 들어간다. 그것까지 안 보면 '깔려 있는데 없다' 가 또 난다.
    """
    home = Path.home()
    d = [home / ".local" / "bin", home / ".claude" / "bin", home / "bin"]
    if os.name == "nt":
        d += [home / "AppData" / "Local" / "Programs" / "claude",
              home / "AppData" / "Roaming" / "npm",
              home / "AppData" / "Local" / "npm",
              Path("C:/Program Files/nodejs")]
    else:
        d += [Path("/opt/homebrew/bin"), Path("/usr/local/bin"), Path("/usr/bin")]

    for base in (home / ".nvm" / "versions" / "node",         # nvm 으로 깐 경우
                 home / ".volta" / "bin", home / ".asdf" / "shims",
                 home / ".bun" / "bin", home / ".fnm" / "node-versions"):
        try:
            if base.name in ("bin", "shims"):
                d.append(base)
                continue
            for v in sorted(base.iterdir(), reverse=True)[:12]:   # 최신 것부터
                d.append(v / "bin")
                d.append(v / "installation" / "bin")
        except OSError:
            continue
    return d


def find() -> str:
    """깔려 있는 클로드 코드의 자리. 못 찾으면 빈 값."""
    hit = shutil.which("claude")
    if hit:
        return hit
    names = ("claude.exe", "claude.cmd", "claude.bat", "claude") if os.name == "nt" else ("claude",)
    for d in _dirs():
        for n in names:
            p = d / n
            try:
                if p.exists():
                    return str(p)
            except OSError:
                continue
    return ""


def remember(path: str) -> bool:
    """찾은 자리를 config 에 적어 둔다 — 다음부터 헤매지 않게."""
    cfg_p = HOME_DIR / "config.json"
    try:
        cfg = json.loads(cfg_p.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return False
    if (cfg.get("claude_bin") or "").strip() == path:
        return False                                         # 이미 같다
    cfg["claude_bin"] = path
    try:
        cfg_p.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
        return True
    except OSError:
        return False


# ── 사명자의 클로드 코드에게 여기가 어디인지 알려준다 ──────────────────
GUIDE = """# 아델 — 이 폴더가 무엇인가

당신은 지금 **아델**의 폴더에 있습니다. 아델은 교회 사명자의 업무를 돕는
비서입니다. 사용자는 개발자가 아닙니다. **결론부터, 짧게, 존댓말로** 답하십시오.

## 아델이 하는 일

- **텔레그램으로 말을 걸면 답한다** — 이게 입구이자 출구다
- **업무 레이더** — 텔레그램 대화를 훑어 '무슨 일이 어디까지 왔나' 를 하루 세 번 정리해 보낸다
- **일정** — 캘린더를 읽고, 말로 하면 넣어준다
- **차트** — 숫자를 그림으로 그린다
- **인터넷 검색** — 바깥 소식을 찾아본다

## 이 폴더에 있는 것

    features/       기능 코드. **여기는 고쳐도 된다**
      listen.py       텔레그램으로 말 걸기 (24시간 떠 있다)
      radar.py        업무 레이더 브리핑
      cal.py          일정
      chart.py        차트
      link.py         클로드 코드 이어주기
    knowledge/      교회 용어·조직·보고 규칙 (암호를 넣어야 풀린다)
    내규칙.md        사용자가 쌓아온 규칙. 말 걸 때마다 먼저 읽힌다
    config.json     설정 — 텔레그램 토큰 등이 들어 있다

## 고칠 때 지킬 것

- **날짜 계산을 당신이 하지 마라.** 자주 틀린다 — 파이썬이 세게 돼 있다
- **말에 없는 숫자를 차트로 그리지 마라.** 그리기 전에 원문과 대조한다
- **지어내지 마라.** 모르면 모른다고 하는 편이 낫다
- `features/` 안의 파일을 고치면 **프로그램을 다시 켜야** 적용된다.
  고쳤으면 그 말을 꼭 알려 주십시오
- 사용자가 "이렇게 기억해" 라고 하면 `내규칙.md` 에 적어라

## 새 버전이 오면

`features/` 와 교회 지식은 6시간마다 저절로 받아온다. 사용자가 고친 파일은
덮어쓰지 않고 옆에 `.새버전` 을 붙여 놓는다. 그럴 땐 견줘서 합쳐 주십시오.

## 자주 막히는 곳

- **"클로드 코드가 안 깔려 있습니다"** 인데 사실은 깔려 있는 경우가 있다.
  프로그램이 `claude` 를 못 찾는 것이다. `config.json` 의 `claude_bin` 에
  실제 자리를 적으면 된다 (`link.py` 가 켤 때 알아서 한다)
- **로그인**은 대신 못 해준다. 터미널에서 `claude` 를 한 번 띄워
  브라우저에서 허용을 눌러야 한다
"""


def guide() -> bool:
    """안내를 사용자 폴더에 놓는다. 사람이 고쳐 뒀으면 건드리지 않는다."""
    p = HOME_DIR / "CLAUDE.md"
    try:
        if p.exists():
            old = p.read_text(encoding="utf-8")
            if "아델 — 이 폴더가 무엇인가" not in old:       # 사람이 쓴 것 → 그대로 둔다
                return False
            if old == GUIDE:
                return False
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(GUIDE, encoding="utf-8")
        return True
    except OSError:
        return False


def ensure() -> dict:
    """켤 때 한 번. 조용히 실패한다 — 이것 때문에 아델이 안 켜지면 안 된다."""
    out = {"found": "", "remembered": False, "guide": False}
    try:
        out["guide"] = guide()
        hit = find()
        out["found"] = hit
        if hit:
            out["remembered"] = remember(hit)
    except Exception:                                        # noqa: BLE001
        pass
    return out


if __name__ == "__main__":
    r = ensure()
    print(f"클로드 자리 : {r['found'] or '못 찾음'}")
    print(f"기억해 둠   : {r['remembered']}")
    print(f"안내 놓음   : {r['guide']}")
