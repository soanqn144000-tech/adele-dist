# -*- coding: utf-8 -*-
"""클로드 코드와 이어주기 — 사명자들이 제일 많이 막히던 자리.

두 가지를 한다. 둘 다 켤 때 저절로 된다.

1. **깔려 있는 클로드를 찾아 기억해 둔다.**
   더블클릭으로 켠 프로그램은 `~/.local/bin` 같은 데를 모른다. 그래서
   깔아 놓고도 "안 깔려 있습니다" 가 떴다. 사람은 또 깔고, 또 못 찾고…
   찾은 자리를 config 에 적어 두면 다음부터 바로 잡힌다.

2. **아델이 무엇인지 적은 안내를 사용자 폴더에 놓는다.**
   사명자가 자기 클로드 코드를 열어 말을 걸면, 그 클로드는 이 폴더가
   뭐 하는 데인지 전혀 모른다. 그래서 이어가기가 안 됐다.
   폴더에 안내를 두면 클로드가 켤 때 읽는다.
"""
from __future__ import annotations

import json
import os
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from brain import HOME_DIR                                   # noqa: E402


def _dirs() -> list[Path]:
    """클로드가 깔릴 만한 자리를 넓게 본다.

    공식 설치 스크립트는 `~/.local/bin` 에 놓지만, npm 으로 깐 사람은
    nvm 폴더 안에 들어간다. 그것까지 안 보면 '깔려 있는데 없다' 가 또 난다.
    """
    home = Path.home()
    d = [home / ".local" / "bin", home / ".claude" / "bin", home / "bin"]
    if os.name == "nt":
        d += [home / "AppData" / "Local" / "Programs" / "claude",
              home / "AppData" / "Roaming" / "npm",
              home / "AppData" / "Local" / "npm",
              Path("C:/Program Files/nodejs")]
    else:
        d += [Path("/opt/homebrew/bin"), Path("/usr/local/bin"), Path("/usr/bin")]

    for base in (home / ".nvm" / "versions" / "node",         # nvm 으로 깐 경우
                 home / ".volta" / "bin", home / ".asdf" / "shims",
                 home / ".bun" / "bin", home / ".fnm" / "node-versions"):
        try:
            if base.name in ("bin", "shims"):
                d.append(base)
                continue
            for v in sorted(base.iterdir(), reverse=True)[:12]:   # 최신 것부터
                d.append(v / "bin")
                d.append(v / "installation" / "bin")
        except OSError:
            continue
    return d


def find() -> str:
    """깔려 있는 클로드 코드의 자리. 못 찾으면 빈 값."""
    hit = shutil.which("claude")
    if hit:
        return hit
    names = ("claude.exe", "claude.cmd", "claude.bat", "claude") if os.name == "nt" else ("claude",)
    for d in _dirs():
        for n in names:
            p = d / n
            try:
                if p.exists():
                    return str(p)
            except OSError:
                continue
    return ""


def remember(path: str) -> bool:
    """찾은 자리를 config 에 적어 둔다 — 다음부터 헤매지 않게."""
    cfg_p = HOME_DIR / "config.json"
    try:
        cfg = json.loads(cfg_p.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return False
    if (cfg.get("claude_bin") or "").strip() == path:
        return False                                         # 이미 같다
    cfg["claude_bin"] = path
    try:
        cfg_p.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
        return True
    except OSError:
        return False


# ── 사명자의 클로드 코드에게 여기가 어디인지 알려준다 ──────────────────
GUIDE = """# 아델 — 이 폴더가 무엇인가

당신은 지금 **아델**의 폴더에 있습니다. 아델은 교회 사명자의 업무를 돕는
비서입니다. 이 글을 먼저 읽고 시작하십시오.

## 쓰는 사람

교회에서 일하는 사명자입니다. **개발자가 아닙니다.**

- **결론부터, 짧게, 존댓말로.** 과정 설명은 물어볼 때만
- 코드 이야기를 먼저 꺼내지 마십시오. "무엇이 어떻게 된다"로 말하십시오
- 복사·붙여넣기 심부름을 시키지 마십시오. 할 수 있으면 당신이 하십시오
- 터미널을 열라고 하지 마십시오. 그게 벽입니다

## 아델이 하는 일 넷

**1. 텔레그램으로 말 걸면 답한다** (`features/listen.py`)
24시간 떠 있습니다. 물으면 읽고 답하고, 시키면 합니다.
바깥 소식(뉴스·시세·날씨)은 **반드시 검색해서** 답하고, 못 찾았으면 그렇다고 밝힙니다.

**2. 업무 레이더** (`features/radar.py`)
하루 세 번(13시·17시·21시) 텔레그램 방을 훑어 '무슨 일이 어디까지 왔나'를 정리해
보냅니다. 업무가 여러 사람에게 흩어져 있고 텔레그램은 흘러가 버려서,
'어느 일정에 무엇을 마감해야 하는가'가 안 보이는 것을 메우려고 만들었습니다.

돌아가는 모양 — **이 나눔을 지키십시오:**

    파이썬   수집 · 걸러내기 · 날짜계산 · 그리기 · 보내기
    클로드   읽고 판단해서 **업무 목록 JSON** 을 만든다

JSON 하나가 원본입니다. 텔레그램 글도 대시보드도 **같은 JSON** 에서 나옵니다.
따로 만들면 둘이 어긋납니다.

**3. 일정** (`features/cal.py`)
캘린더를 읽고, 말로 하면 넣습니다. 아이폰(아이클라우드)과 갤럭시(구글) 둘 다.
**앱 전용 암호**가 필요합니다 — 계정 비밀번호로는 안 됩니다.

**4. 차트** (`features/chart.py`)
막대·꺾은선·비교·도넛 넉 장. 이것으로 웬만한 보고는 됩니다.

## 이 폴더에 있는 것

    features/       기능 코드. **여기는 고쳐도 된다**
      listen.py       텔레그램으로 말 걸기 (24시간 상주)
      radar.py        업무 레이더 브리핑
      cal.py          일정
      chart.py        차트
      link.py         클로드 코드 이어주기 · 이 안내문
      remote.py       크롬을 대신 움직여 주기
    knowledge/      교회 용어·조직·보고 규칙 (**암호를 넣어야 풀린다**)
    내규칙.md        사용자가 쌓아온 규칙. 말 걸 때마다 먼저 읽힌다
    CLAUDE.md       이 글
    config.json     설정 — 텔레그램 토큰, 클로드 자리 등

## 반드시 지킬 것 넷

**① 날짜 계산을 당신이 하지 마십시오.**
D-day, '다음주 화요일이 며칠', '마감 임박' 판정 — 전부 파이썬이 셉니다.
모델에게 시키면 자주 틀립니다. 날짜·시각을 **뽑는 것**까지가 당신 몫입니다.

**② 말에 없는 숫자를 그리지 마십시오.**
차트를 그리기 전에 원문과 대조하십시오. 점이 모자라면 **안 그리고 그렇다고 말합니다.**
말 속에서 숫자를 주워 그리다 사고가 난 적이 있습니다.

**③ 지어내지 마십시오.**
마감·상태는 **원문에 있는 말에서만** 뽑습니다. 없으면 '없음'이라고 씁니다.
추측한 날짜를 만들지 마십시오. 모르면 모른다고 하는 편이 낫습니다.

**④ 고쳤으면 다시 켜라고 알려 주십시오.**
`features/` 안의 파일은 **프로그램을 다시 켜야** 적용됩니다.
고쳐놓고 말 안 하면 사용자는 '안 고쳐졌다'고 생각합니다.

## 사용자가 시키는 흔한 것들

| 이런 말을 들으면 | 이렇게 |
|---|---|
| "이렇게 기억해", "앞으로는 이렇게" | `내규칙.md` 에 적는다 |
| "이 기능 이렇게 바꿔줘" | `features/` 안의 파일을 고치고, 다시 켜라고 알린다 |
| "브리핑 형식 바꿔줘" | `radar.py` 의 렌더 부분 |
| "이 방도 봐줘 / 빼줘" | 설치 화면에서 방을 고르게 안내한다 |
| "왜 이렇게 나왔어" | 원문을 찾아 근거를 보여준다. 변명하지 않는다 |

## 교회 지식은 잠겨 있습니다

`knowledge/` 안의 교회 용어·조직·보고 규칙은 **암호를 넣어야 풀립니다.**
풀려 있으면 읽고 그 규칙대로 쓰십시오 — 교회에는 교회의 말투와 형식이 있습니다.
안 풀려 있으면 **일반적인 말로 지어내지 말고**, 암호를 넣으면 더 정확해진다고
알려 주십시오.

## 새 버전이 오면

`features/` 와 교회 지식은 6시간마다 저절로 받아옵니다.
사용자가 **고친 파일은 덮어쓰지 않고** 옆에 `.새버전` 을 붙여 놓습니다.
`새버전 알림.txt` 가 생겨 있으면, 두 파일을 견줘서 합쳐 주십시오 —
사용자가 고친 뜻은 살리고 새 것의 고침만 가져오는 식으로.

## 자주 막히는 곳

**"클로드 코드가 안 깔려 있습니다"** 인데 사실은 깔려 있는 경우
→ 프로그램이 `claude` 를 못 찾는 것입니다. `config.json` 의 `claude_bin` 에
실제 자리를 적으면 됩니다 (`link.py` 가 켤 때 알아서 합니다).

**로그인**
→ 대신 못 해 드립니다. 설치 화면의 `로그인 창 열기` 를 누르면 창이 열리고
브라우저가 뜹니다. 허용은 사람이 눌러야 합니다.

**검색이 안 될 때**
→ 조용히 옛날 이야기를 하지 마십시오. **"검색을 못 했습니다"를 먼저 밝히십시오.**

**캘린더가 안 붙을 때**
→ 열에 아홉은 **앱 전용 암호**를 안 쓰고 계정 비밀번호를 넣은 것입니다.
삼성 클라우드 캘린더는 통로가 없어 못 붙습니다 — 구글 쪽으로 안내하십시오.

**업무 레이더 화면이 비어 있을 때**
→ 아직 한 번도 안 돌았거나, 파이어베이스가 연결 안 된 것입니다.
설치 화면 `업무 레이더 화면` 칸에서 `아델이 대신 만들어 주기` 를 누르면 됩니다.

## 하지 말 것

- 사용자 몰래 설정을 바꾸는 것
- 텔레그램으로 남에게 무엇을 보내는 것 (주인에게만 답합니다)
- 교회 지식을 폴더 밖으로 옮겨 적는 것
- "됐습니다"라고 먼저 말하고 확인은 나중에 하는 것 — **돌려보고 말하십시오**
"""


def guide() -> bool:
    """안내를 사용자 폴더에 놓는다. 사람이 고쳐 뒀으면 건드리지 않는다."""
    p = HOME_DIR / "CLAUDE.md"
    try:
        if p.exists():
            old = p.read_text(encoding="utf-8")
            if "아델 — 이 폴더가 무엇인가" not in old:       # 사람이 쓴 것 → 그대로 둔다
                return False
            if old == GUIDE:
                return False
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(GUIDE, encoding="utf-8")
        return True
    except OSError:
        return False


def ensure() -> dict:
    """켤 때 한 번. 조용히 실패한다 — 이것 때문에 아델이 안 켜지면 안 된다."""
    out = {"found": "", "remembered": False, "guide": False}
    try:
        out["guide"] = guide()
        hit = find()
        out["found"] = hit
        if hit:
            out["remembered"] = remember(hit)
    except Exception:                                        # noqa: BLE001
        pass
    return out


if __name__ == "__main__":
    r = ensure()
    print(f"클로드 자리 : {r['found'] or '못 찾음'}")
    print(f"기억해 둠   : {r['remembered']}")
    print(f"안내 놓음   : {r['guide']}")
