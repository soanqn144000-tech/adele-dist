# -*- coding: utf-8 -*-
"""말 걸기 — 텔레그램으로 물으면 클로드가 읽고 답한다.

이 파일만 24시간 떠 있는다. 나머지(업무 레이더)는 하루 세 번 돌고 끝난다.
상주하는 놈은 죽어도 소리가 안 나므로 guard 가 따로 지켜본다.

돌아가는 모양:
    텔레그램 서버 <-- getUpdates(밖으로 나가서 물어봄) -- 이 PC
    그래서 포트 개방도 터널도 필요 없다. 밖에서 들어오는 게 없다.

한 번에 하나만 떠 있어야 한다. 둘이면 텔레그램이 409 를 뱉고
같은 말에 두 번 답한다 — 그래서 포트를 잡아 두 번째는 스스로 나간다.
"""
from __future__ import annotations

import json
import os
import queue
import re
import socket
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
from datetime import datetime, timedelta, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
_v = ROOT / "vendor"
if _v.exists() and str(_v) not in sys.path:
    sys.path.insert(0, str(_v))

import brain
from brain import HOME_DIR                                                 # noqa: E402

KST = timezone(timedelta(hours=9))
API = "https://api.telegram.org/bot{token}/{method}"
STATE = HOME_DIR / "data" / "listen_state.json"
ALIVE = HOME_DIR / "data" / "listen_alive.txt"                   # guard 가 이걸 본다
LOCK_PORT = int(os.environ.get("ADELE_LISTEN_LOCK_PORT", "47632"))

POLL = 25                                                    # 롱폴링 — 새 글 없으면 여기까지 기다린다
MAX_ASK = 900                                                # 한 물음에 클로드가 쓸 수 있는 시간(초)
TICK = 20                                                    # 이 간격(초)으로 "아직 하고 있습니다" 를 고쳐 쓴다
_lock_sock = None                                            # GC 로 닫히면 락이 풀린다


# ── 하나만 뜨게 ───────────────────────────────────────────────────────
def _only_one() -> None:
    """이미 돌고 있으면 조용히 나간다.

    둘이 폴링하면 텔레그램이 409 를 뱉고, 같은 물음에 두 번 답한다.
    시작프로그램과 손으로 켠 게 겹치는 일이 흔하다.
    """
    global _lock_sock
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        s.bind(("127.0.0.1", LOCK_PORT))
        s.listen(1)
    except OSError:
        print(f"이미 돌고 있습니다(포트 {LOCK_PORT}) — 이 쪽은 끝냅니다.")
        raise SystemExit(0)
    _lock_sock = s


# ── 설정·상태 ─────────────────────────────────────────────────────────
def _cfg() -> dict:
    try:
        return json.loads((HOME_DIR / "config.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _state() -> dict:
    try:
        return json.loads(STATE.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _save(st: dict) -> None:
    STATE.parent.mkdir(parents=True, exist_ok=True)
    STATE.write_text(json.dumps(st, ensure_ascii=False, indent=2), encoding="utf-8")


def _beat() -> None:
    """살아있음 표시. guard 가 이 시각을 보고 죽었는지 판단한다."""
    try:
        ALIVE.parent.mkdir(parents=True, exist_ok=True)
        ALIVE.write_text(datetime.now(KST).isoformat(timespec="seconds"), encoding="utf-8")
    except OSError:
        pass


# ── 텔레그램 ──────────────────────────────────────────────────────────
def _call(token: str, method: str, payload: dict | None = None, timeout: int = 40) -> dict:
    data = json.dumps(payload).encode() if payload else None
    req = urllib.request.Request(API.format(token=token, method=method), data=data,
                                 headers={"Content-Type": "application/json"} if data else {})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        try:
            return json.loads(e.read().decode())
        except Exception:                                    # noqa: BLE001
            return {"ok": False, "description": f"HTTP {e.code}"}
    except Exception as e:                                   # noqa: BLE001
        return {"ok": False, "description": f"{type(e).__name__}: {e}"}


def _send(token: str, chat: str, text: str) -> None:
    """4096자가 한 통 한도 — 줄 단위로 끊어 보낸다."""
    chunks, buf = [], ""
    for line in (text or "(빈 답)").split("\n"):
        if len(buf) + len(line) + 1 > 3900:
            chunks.append(buf)
            buf = ""
        buf += line + "\n"
    if buf.strip():
        chunks.append(buf)
    for c in chunks or [text]:
        _call(token, "sendMessage",
              {"chat_id": chat, "text": c, "disable_web_page_preview": True})


def _say_once(token: str, chat: str, text: str) -> int:
    """한 통만 보내고 그 번호를 돌려준다 — 나중에 고쳐 쓰려고."""
    r = _call(token, "sendMessage",
              {"chat_id": chat, "text": text, "disable_web_page_preview": True})
    try:
        return int(r["result"]["message_id"])
    except (KeyError, TypeError, ValueError):
        return 0


def _edit(token: str, chat: str, mid: int, text: str) -> bool:
    """이미 보낸 통을 고쳐 쓴다. 방을 도배하지 않고 진행 상황을 보여주는 길이다."""
    if not mid:
        return False
    r = _call(token, "editMessageText",
              {"chat_id": chat, "message_id": mid, "text": text,
               "disable_web_page_preview": True})
    return bool(r.get("ok"))


def _erase(token: str, chat: str, mid: int) -> None:
    if mid:
        _call(token, "deleteMessage", {"chat_id": chat, "message_id": mid})


def _photo(token: str, chat: str, path: str, caption: str = "") -> bool:
    """사진 한 장 보내기 — 차트를 보낼 때 쓴다."""
    import mimetypes
    import uuid
    b = uuid.uuid4().hex
    name = Path(path).name
    try:
        data = Path(path).read_bytes()
    except OSError:
        return False
    body = (f"--{b}\r\nContent-Disposition: form-data; name=\"chat_id\"\r\n\r\n"
            f"{chat}\r\n").encode()
    if caption:
        body += (f"--{b}\r\nContent-Disposition: form-data; name=\"caption\"\r\n\r\n"
                 f"{caption}\r\n").encode()
    body += (f"--{b}\r\nContent-Disposition: form-data; name=\"photo\"; "
             f"filename=\"{name}\"\r\nContent-Type: "
             f"{mimetypes.guess_type(name)[0] or 'image/png'}\r\n\r\n").encode()
    body += data + f"\r\n--{b}--\r\n".encode()
    req = urllib.request.Request(
        API.format(token=token, method="sendPhoto"), data=body,
        headers={"Content-Type": f"multipart/form-data; boundary={b}"})
    try:
        urllib.request.urlopen(req, timeout=120)
        return True
    except Exception as e:                                   # noqa: BLE001
        print(f"[listen] 사진 실패 — {type(e).__name__}: {e}", file=sys.stderr)
        return False


# ── 무슨 부탁인지 가르기 ──────────────────────────────────────────────
# 말을 클로드에게 통째로 넘기기 전에, 일정·차트처럼 손이 필요한 것만 먼저 갈라낸다.
# 전부 클로드에게 맡기면 '일정 넣어줘' 에 말로만 답하고 실제로는 안 넣는다.
_CAL_SEE = re.compile(r"(오늘|이번\s*주|금주|내일).*(일정|스케줄|약속)|"
                      r"(일정|스케줄|약속).*(뭐|알려|보여|있)")
_CAL_ADD = re.compile(r"(일정|약속|스케줄).*(넣|추가|잡아|등록)|"
                      r"(넣어|추가해|잡아|등록해)\s*(줘|주세요|줘요)?$")
_CHART = re.compile(r"(차트|그래프|그림)(로|으로)?\s*(그려|만들|보여)|"
                    r"(막대|꺾은선|도넛|원)\s*(차트|그래프)")


# 설치 화면에 있는 단추는 이미 깔린 아델에서는 누를 수가 없다(실행파일 안이라
# 자동으로 안 바뀐다). 그래서 텔레그램으로도 시킬 수 있게 열어 둔다.
_BOARD_MAKE = re.compile(r"(대시보드|업무\s*보드|업무\s*화면|파이어베이스|firebase)"
                         r".*(만들|연결|설치|셋업|해\s*줘)")
_BOARD_SEE = re.compile(r"(대시보드|업무\s*보드|업무\s*화면)\s*(주소|링크|열|보여|어디)")

_SEARCH = re.compile(r"검색|찾아\s*(봐|줘|주세요|보고)|알아\s*(봐|와|줘)|"
                     r"(뉴스|시세|주가|환율|날씨|기사)\s*(좀|알려|보여|어때|어떻)?|"
                     r"요즘|최근|최신|지금\s*(뭐|어떻)")


def _route(text: str) -> str:
    """무엇을 해달라는 말인가. 애매하면 빈 값(그냥 클로드가 답한다)."""
    if _CHART.search(text):
        return "chart"
    if _CAL_ADD.search(text) and re.search(r"\d|내일|모레|다음\s*주|월요일|화요일|"
                                           r"수요일|목요일|금요일|토요일|일요일", text):
        return "cal_add"
    if _CAL_SEE.search(text):
        return "cal_see"
    if _BOARD_MAKE.search(text):
        return "board_make"                              # 대시보드를 대신 만들어 준다
    if _BOARD_SEE.search(text):
        return "board_see"                               # 내 대시보드 주소
    if _SEARCH.search(text):
        return "search"                                  # 클로드가 답하되 반드시 찾아보게
    return ""


# ── 클로드에게 넘기기 ─────────────────────────────────────────────────
RULE = """너는 {name} 이다. 교회 업무를 돕는 비서다. 지금은 {now} 이다.

이 폴더 안에 이런 것들이 있다. 필요하면 읽어라.
- knowledge/  우리 교회 용어·조직·보고 규칙 (예: knowledge/01-용어정의.md)
- features/   이 비서의 기능 코드
- 내규칙.md    사용자가 쌓아온 규칙

**사용자가 "이렇게 기억해" "앞으로는 이렇게 해" 라고 하면 내규칙.md 에 적어라.**
기능을 고쳐 달라고 하면 features/ 안의 파일을 고쳐도 된다 —
고친 것은 다음에 켤 때부터 쓰인다(프로그램을 다시 켜라고 알려줘라).

지킬 것:
- 존댓말. 짧고 정확하게.
- **모르면 모른다고 해라.** 그럴듯하게 지어내지 마라 — 그게 제일 위험하다.
- 숫자는 근거가 있을 때만. 없으면 '자료 없음' 이라고 써라.
- **바깥 소식(뉴스·시세·환율·날씨·최신 자료)은 기억으로 답하지 마라. 검색해서 답해라.**
  검색을 못 했으면 답 첫 줄에 '검색을 못 했습니다 — 아래는 예전에 알던 내용입니다'
  라고 반드시 밝혀라. 밝히지 않고 옛날 이야기를 하는 것이 제일 나쁘다.
- 날짜 계산이 필요하면 오늘({today}) 을 기준으로 하되, 헷갈리면 물어봐라.
- 텔레그램으로 보내는 글이다. 마크다운 표는 쓰지 마라(깨진다). 줄바꿈과 · 로 정리해라.

사용자가 한 말:
{text}"""


# 찾아봐 달라는 부탁일 때만 얹는다. 검색은 클로드가 대신 해 주는 것이라
# 안 되는 환경에서도 조용히 아는 대로 답해 버린다 — 그걸 못 하게 못박는다.
SEARCH_RULE = """

**이번 부탁은 찾아봐 달라는 것이다. 반드시 인터넷을 검색해서 답해라.**
- 기억으로 답하지 마라. 검색 도구를 실제로 써라.
- 검색이 안 되면 **'검색을 못 했습니다' 를 첫 줄에 쓰고** 왜 못 했는지 한 줄 덧붙여라.
  그 상태에서 아는 대로 답하려거든 '예전에 알던 내용' 이라고 반드시 표시해라.
- 찾았으면 **언제 것인지(날짜)와 어디서 봤는지**를 같이 적어라."""


def _think(text: str, what: str = "") -> str | None:
    now = datetime.now(KST)
    prompt = RULE.format(name=brain.bot_name(), now=now.strftime("%m/%d %H:%M"),
                         today=now.strftime("%Y-%m-%d"), text=text)
    if what == "search":
        prompt += SEARCH_RULE
    return brain.ask(_cfg(), prompt)


def _ago(sec: int) -> str:
    return f"{sec // 60}분 {sec % 60}초" if sec >= 60 else f"{sec}초"


class _Working:
    """일하는 동안 "하고 있습니다" 를 계속 보여준다.

    전에는 typing 표시를 한 번 켜고 조용했다. 클로드가 1~5분을 생각하는 동안
    화면에는 아무것도 없어서, 사용자는 죽은 줄 알고 또 말을 걸었다
    (2026-09-04 사명자가 실제로 겪음). 이제 한 통을 띄워 놓고 몇 초 지났는지
    **그 통을 고쳐 쓰며** 보여준다 — 방을 도배하지 않는다.

    일하는 동안 살아있음(_beat)도 여기서 찍는다. 안 찍으면 guard 가 3분 만에
    죽은 줄 알고 되살리기를 시도하며 헛경보를 보낸다.
    """

    def __init__(self, token: str, chat: str, first: str = "⏳ 처리 중입니다…"):
        self.token, self.chat, self.first = token, chat, first
        self.mid = 0
        self.t0 = time.time()
        self._stop = threading.Event()
        self._th: threading.Thread | None = None

    def __enter__(self) -> "_Working":
        self.mid = _say_once(self.token, self.chat, self.first)
        self._th = threading.Thread(target=self._tick, daemon=True)
        self._th.start()
        return self

    def _tick(self) -> None:
        while not self._stop.wait(TICK):
            _beat()                                          # 일하는 중에도 살아있다
            _call(self.token, "sendChatAction",
                  {"chat_id": self.chat, "action": "typing"})
            _edit(self.token, self.chat, self.mid,
                  f"⏳ 아직 하고 있습니다 ({_ago(int(time.time() - self.t0))} 지났습니다) — "
                  f"다 되면 바로 보내드리겠습니다.")

    def done(self, text: str = "") -> None:
        """끝났다. 안내를 마지막 말로 바꾸거나, 할 말이 없으면 지운다."""
        self._stop.set()
        if self._th:
            self._th.join(timeout=3)
        if text:
            if not _edit(self.token, self.chat, self.mid, text):
                _send(self.token, self.chat, text)
        else:
            _erase(self.token, self.chat, self.mid)

    def __exit__(self, *a) -> bool:
        self._stop.set()
        return False


def _handle(what: str, text: str, token: str, chat: str) -> bool:
    """일정·차트처럼 실제로 뭔가 해야 하는 부탁. 처리했으면 True."""
    if what == "search":                                 # 검색은 클로드가 한다 — 아래로 넘긴다
        return False
    sys.path.insert(0, str(ROOT / "features"))

    if what == "board_see":
        import link
        url = link.board_url() or link.fix_board()
        _send(token, chat, f"업무 레이더 화면입니다.\n{url}" if url else
              "아직 업무 레이더 화면이 없습니다. '대시보드 만들어줘' 라고 하시면 만들어 드립니다.")
        return True

    if what == "board_make":
        import link
        import remote
        _send(token, chat, "만들어 보겠습니다 — 3~5분 걸립니다.\n"
                           "이 컴퓨터의 크롬이 저절로 움직입니다. 그 창을 닫지 마십시오.")
        r = remote.make_firebase(_cfg())
        if not r.get("ok"):
            _send(token, chat, "못 만들었습니다 — " + (r.get("error") or "")
                  + (f"\n({r['detail']})" if r.get("detail") else ""))
            return True
        url = link.fix_board() or link.board_url()
        _send(token, chat, f"다 만들었습니다 — {r.get('project','')}\n{url}\n"
                           "브리핑이 한 번 돌면 이 화면에 뜹니다.")
        return True

    if what == "chart":
        import chart
        _call(token, "sendChatAction", {"chat_id": chat, "action": "upload_photo"})
        path, msg = chart.from_text(text)
        if path:
            _photo(token, chat, path, msg)
        else:
            _send(token, chat, msg)
        return True

    import cal
    ok, why = cal.ready()
    if not ok:
        _send(token, chat, why)
        return True

    if what == "cal_add":
        d = cal.parse(text)
        if not d:
            _send(token, chat, "무슨 일정인지 못 읽었습니다. 날짜와 할 일을 같이 말해 주십시오.")
            return True
        _send(token, chat, cal.add(d)[1])
        return True

    week = bool(re.search(r"이번\s*주|금주|주간", text))
    items = cal.this_week() if week else cal.today()
    _send(token, chat, cal.render(items, "이번주 일정" if week else "오늘 일정"))
    return True


# ── 본체 ──────────────────────────────────────────────────────────────
def _link() -> None:
    """켤 때 클로드 자리를 찾아 기억하고, 폴더에 안내를 놓는다(조용히)."""
    try:
        import link
        r = link.ensure()
        if r["remembered"]:
            print(f"[listen] 클로드 코드를 찾았습니다 — {r['found']}", flush=True)
        if not r["found"]:
            print("[listen] 클로드 코드를 못 찾았습니다 — 설치 화면에서 확인해 주십시오.",
                  file=sys.stderr)
    except Exception as e:                                   # noqa: BLE001
        print(f"[listen] 이어주기 건너뜀 — {type(e).__name__}: {e}", file=sys.stderr)


def _work(what: str, text: str, token: str, chat: str) -> None:
    """물음 하나를 끝까지 처리한다. 일하는 내내 진행 상황을 보여준다."""
    with _Working(token, chat) as w:
        if what:                                             # 손이 필요한 부탁
            try:
                if _handle(what, text, token, chat):
                    w.done()
                    return
            except Exception as e:                           # noqa: BLE001
                print(f"[listen] {what} 실패 — {type(e).__name__}: {e}", file=sys.stderr)
                w.done(f"그건 못 했습니다 — {type(e).__name__}")
                return
        got = _think(text, what)
        if got and got.strip():
            w.done()
            _send(token, chat, got.strip())
        else:
            w.done("지금은 생각하는 쪽이 답하지 않습니다.\n"
                   "이 PC 에서 claude 가 로그인돼 있는지 확인해 주십시오.")


def run() -> int:
    _link()                                              # 제일 먼저 이어둔다
    _only_one()
    cfg = _cfg()
    token = (cfg.get("telegram_bot_token") or "").strip()
    owner = str(cfg.get("admin_telegram_id") or "").strip()
    if not (token and owner):
        print("설정에 봇 토큰·chat_id 가 없습니다. 설치 화면에서 봇을 먼저 만드십시오.",
              file=sys.stderr)
        return 1

    st = _state()
    offset = int(st.get("offset", 0))
    print(f"말 걸기 시작 — 봇 대기 중 (offset {offset})", flush=True)
    _beat()

    # 일은 딴 갈래에서 한다. 전에는 여기서 그냥 클로드를 기다렸는데, 그동안
    # 새 말을 아예 못 읽었다 — 기다리다 답답해서 다시 말을 걸어도 감감무소식이었다.
    # 이제 받는 쪽은 계속 듣고, 일은 한 줄로 세워 차례대로 한다(둘이 겹치면 안 된다).
    jobs: "queue.Queue[tuple[str, str]]" = queue.Queue()
    busy = threading.Event()

    def worker() -> None:
        while True:
            what, text = jobs.get()
            busy.set()
            try:
                _work(what, text, token, owner)
            except Exception as e:                           # noqa: BLE001
                print(f"[listen] 일하다 넘어짐 — {type(e).__name__}: {e}", file=sys.stderr)
                _send(token, owner, f"그건 못 했습니다 — {type(e).__name__}")
            finally:
                busy.clear()
                jobs.task_done()
                _beat()

    threading.Thread(target=worker, daemon=True).start()

    while True:
        r = _call(token, "getUpdates",
                  {"offset": offset, "timeout": POLL, "allowed_updates": ["message"]},
                  timeout=POLL + 15)
        _beat()                                              # 조용해도 살아있다고 남긴다

        if not r.get("ok"):
            why = r.get("description", "")
            if "409" in str(why) or "Conflict" in str(why):
                print("다른 곳에서도 같은 봇을 보고 있습니다 — 끝냅니다.", file=sys.stderr)
                return 1
            print(f"[listen] {why}", file=sys.stderr)
            time.sleep(5)                                    # 인터넷이 끊겼을 수 있다 — 쉬고 다시
            continue

        for up in r.get("result", []):
            offset = max(offset, up.get("update_id", 0) + 1)
            st["offset"] = offset
            _save(st)

            msg = up.get("message") or {}
            chat = str((msg.get("chat") or {}).get("id", ""))
            text = (msg.get("text") or "").strip()
            if not text:
                continue
            if chat != owner:                                # 주인 말만 듣는다
                print(f"[listen] 모르는 사람({chat}) — 무시", file=sys.stderr)
                continue

            print(f"[listen] 받음: {text[:40]}", flush=True)
            _call(token, "sendChatAction", {"chat_id": chat, "action": "typing"})

            ahead = jobs.qsize() + (1 if busy.is_set() else 0)
            jobs.put((_route(text), text))
            if ahead:                                        # 앞의 일이 아직 안 끝났다
                _send(token, chat,
                      f"⏳ 앞의 일을 아직 하고 있습니다 — 이건 {ahead + 1}번째로 "
                      f"처리해서 보내드리겠습니다.")
            _beat()


def main() -> int:
    try:
        return run()
    except KeyboardInterrupt:
        return 0
    except Exception as e:                                   # noqa: BLE001
        print(f"[listen] 멈춤 — {type(e).__name__}: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
