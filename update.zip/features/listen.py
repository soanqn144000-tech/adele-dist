# -*- coding: utf-8 -*-
"""말 걸기 — 텔레그램으로 물으면 클로드가 읽고 답한다.

이 파일만 24시간 떠 있는다. 나머지(업무 레이더)는 하루 세 번 돌고 끝난다.
상주하는 놈은 죽어도 소리가 안 나므로 guard 가 따로 지켜본다.

돌아가는 모양:
    텔레그램 서버 <-- getUpdates(밖으로 나가서 물어봄) -- 이 PC
    그래서 포트 개방도 터널도 필요 없다. 밖에서 들어오는 게 없다.

한 번에 하나만 떠 있어야 한다. 둘이면 텔레그램이 409 를 뱉고
같은 말에 두 번 답한다 — 그래서 포트를 잡아 두 번째는 스스로 나간다.
"""
from __future__ import annotations

import json
import os
import queue
import re
import socket
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
from datetime import datetime, timedelta, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
_v = ROOT / "vendor"
if _v.exists() and str(_v) not in sys.path:
    sys.path.insert(0, str(_v))

import brain
from brain import HOME_DIR                                                 # noqa: E402

KST = timezone(timedelta(hours=9))
API = "https://api.telegram.org/bot{token}/{method}"
STATE = HOME_DIR / "data" / "listen_state.json"
ALIVE = HOME_DIR / "data" / "listen_alive.txt"                   # guard 가 이걸 본다
LOCK_PORT = int(os.environ.get("ADELE_LISTEN_LOCK_PORT", "47632"))

POLL = 25                                                    # 롱폴링 — 새 글 없으면 여기까지 기다린다
MAX_ASK = 900                                                # 한 물음에 클로드가 쓸 수 있는 시간(초)
TICK = 20                                                    # 이 간격(초)으로 "아직 하고 있습니다" 를 고쳐 쓴다
_lock_sock = None                                            # GC 로 닫히면 락이 풀린다


# ── 하나만 뜨게 ───────────────────────────────────────────────────────
def _only_one() -> None:
    """이미 돌고 있으면 조용히 나간다.

    둘이 폴링하면 텔레그램이 409 를 뱉고, 같은 물음에 두 번 답한다.
    시작프로그램과 손으로 켠 게 겹치는 일이 흔하다.
    """
    global _lock_sock
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        s.bind(("127.0.0.1", LOCK_PORT))
        s.listen(1)
    except OSError:
        print(f"이미 돌고 있습니다(포트 {LOCK_PORT}) — 이 쪽은 끝냅니다.")
        raise SystemExit(0)
    _lock_sock = s


# ── 설정·상태 ─────────────────────────────────────────────────────────
def _cfg() -> dict:
    try:
        return json.loads((HOME_DIR / "config.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _state() -> dict:
    try:
        return json.loads(STATE.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _save(st: dict) -> None:
    STATE.parent.mkdir(parents=True, exist_ok=True)
    STATE.write_text(json.dumps(st, ensure_ascii=False, indent=2), encoding="utf-8")


def _beat() -> None:
    """살아있음 표시. guard 가 이 시각을 보고 죽었는지 판단한다."""
    try:
        ALIVE.parent.mkdir(parents=True, exist_ok=True)
        ALIVE.write_text(datetime.now(KST).isoformat(timespec="seconds"), encoding="utf-8")
    except OSError:
        pass


# ── 텔레그램 ──────────────────────────────────────────────────────────
def _call(token: str, method: str, payload: dict | None = None, timeout: int = 40) -> dict:
    data = json.dumps(payload).encode() if payload else None
    req = urllib.request.Request(API.format(token=token, method=method), data=data,
                                 headers={"Content-Type": "application/json"} if data else {})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        try:
            return json.loads(e.read().decode())
        except Exception:                                    # noqa: BLE001
            return {"ok": False, "description": f"HTTP {e.code}"}
    except Exception as e:                                   # noqa: BLE001
        return {"ok": False, "description": f"{type(e).__name__}: {e}"}


def _send(token: str, chat: str, text: str) -> None:
    """4096자가 한 통 한도 — 줄 단위로 끊어 보낸다."""
    chunks, buf = [], ""
    for line in (text or "(빈 답)").split("\n"):
        if len(buf) + len(line) + 1 > 3900:
            chunks.append(buf)
            buf = ""
        buf += line + "\n"
    if buf.strip():
        chunks.append(buf)
    for c in chunks or [text]:
        _call(token, "sendMessage",
              {"chat_id": chat, "text": c, "disable_web_page_preview": True})


def _stop_btn(no: int) -> dict:
    """「이 작업 중단」 단추 — 부장님 텔레봇과 같은 모양(2026-11-18)."""
    return {"inline_keyboard": [[{"text": "🛑 이 작업 중단", "callback_data": f"stop:{no}"}]]}


def _say_once(token: str, chat: str, text: str, markup: dict | None = None) -> int:
    """한 통만 보내고 그 번호를 돌려준다 — 나중에 고쳐 쓰려고."""
    body = {"chat_id": chat, "text": text, "disable_web_page_preview": True}
    if markup:
        body["reply_markup"] = markup
    r = _call(token, "sendMessage", body)
    try:
        return int(r["result"]["message_id"])
    except (KeyError, TypeError, ValueError):
        return 0


def _edit(token: str, chat: str, mid: int, text: str, markup: dict | None = None) -> bool:
    """이미 보낸 통을 고쳐 쓴다. 방을 도배하지 않고 진행 상황을 보여주는 길이다.
    단추를 남기려면 markup 을 다시 줘야 한다(안 주면 텔레그램이 단추를 지운다)."""
    if not mid:
        return False
    body = {"chat_id": chat, "message_id": mid, "text": text, "disable_web_page_preview": True}
    if markup:
        body["reply_markup"] = markup
    r = _call(token, "editMessageText", body)
    return bool(r.get("ok"))


def _erase(token: str, chat: str, mid: int) -> None:
    if mid:
        _call(token, "deleteMessage", {"chat_id": chat, "message_id": mid})


def _photo(token: str, chat: str, path: str, caption: str = "") -> bool:
    """사진 한 장 보내기 — 차트를 보낼 때 쓴다."""
    import mimetypes
    import uuid
    b = uuid.uuid4().hex
    name = Path(path).name
    try:
        data = Path(path).read_bytes()
    except OSError:
        return False
    body = (f"--{b}\r\nContent-Disposition: form-data; name=\"chat_id\"\r\n\r\n"
            f"{chat}\r\n").encode()
    if caption:
        body += (f"--{b}\r\nContent-Disposition: form-data; name=\"caption\"\r\n\r\n"
                 f"{caption}\r\n").encode()
    body += (f"--{b}\r\nContent-Disposition: form-data; name=\"photo\"; "
             f"filename=\"{name}\"\r\nContent-Type: "
             f"{mimetypes.guess_type(name)[0] or 'image/png'}\r\n\r\n").encode()
    body += data + f"\r\n--{b}--\r\n".encode()
    req = urllib.request.Request(
        API.format(token=token, method="sendPhoto"), data=body,
        headers={"Content-Type": f"multipart/form-data; boundary={b}"})
    try:
        urllib.request.urlopen(req, timeout=120)
        return True
    except Exception as e:                                   # noqa: BLE001
        print(f"[listen] 사진 실패 — {type(e).__name__}: {e}", file=sys.stderr)
        return False


# ── 무슨 부탁인지 가르기 ──────────────────────────────────────────────
# 말을 클로드에게 통째로 넘기기 전에, 일정·차트처럼 손이 필요한 것만 먼저 갈라낸다.
# 전부 클로드에게 맡기면 '일정 넣어줘' 에 말로만 답하고 실제로는 안 넣는다.
_CAL_SEE = re.compile(r"(오늘|이번\s*주|금주|내일).*(일정|스케줄|약속)|"
                      r"(일정|스케줄|약속).*(뭐|알려|보여|있)")
_CAL_ADD = re.compile(r"(일정|약속|스케줄).*(넣|추가|잡아|등록)|"
                      r"(넣어|추가해|잡아|등록해)\s*(줘|주세요|줘요)?$")
_CHART = re.compile(r"(차트|그래프|그림)(로|으로)?\s*(그려|만들|보여)|"
                    r"(막대|꺾은선|도넛|원)\s*(차트|그래프)")


# 설치 화면에 있는 단추는 이미 깔린 아델에서는 누를 수가 없다(실행파일 안이라
# 자동으로 안 바뀐다). 그래서 텔레그램으로도 시킬 수 있게 열어 둔다.
_BOARD_MAKE = re.compile(r"(대시보드|업무\s*보드|업무\s*화면|파이어베이스|firebase)"
                         r".*(만들|연결|설치|셋업|해\s*줘)")
_BOARD_SEE = re.compile(r"(대시보드|업무\s*보드|업무\s*화면)\s*(주소|링크|열|보여|어디)")

_SEARCH = re.compile(r"검색|찾아\s*(봐|줘|주세요|보고)|알아\s*(봐|와|줘)|"
                     r"(뉴스|시세|주가|환율|날씨|기사)\s*(좀|알려|보여|어때|어떻)?|"
                     r"요즘|최근|최신|지금\s*(뭐|어떻)")

# 내 텔레그램 안의 일 — 창고(tgbox)에서 찾거나, 방에 보내거나, 예약해 달라는 말.
# 일정(cal_add)보다 먼저 본다: "매일 7시에 공지방에 보내게 등록해줘" 가 일정으로 새면 안 된다.
_TG = re.compile(r"텔레|텔방|단톡|어느\s*방|방에서|방에\s*.*(올려|올리|보내|공지|남겨|전달)|"
                 r"누가\s*.*(말|얘기|이야기|보냈|올렸|했)|(말|얘기|이야기)\s*했|"
                 r"(메시지|메세지|공지|글).*(찾|검색|어디)|"
                 r"예약\s*(메시지|메세지|발송|전송)|(보내|발송|전송|공지)\S*\s*예약|"
                 r"(매일|평일|주말|매주).*(보내|발송|올려|공지)")


def _route(text: str) -> str:
    """무엇을 해달라는 말인가. 애매하면 빈 값(그냥 클로드가 답한다)."""
    if _CHART.search(text):
        return "chart"
    if _TG.search(text):
        return "tg"                                      # 클로드가 텔레그램 창고로 한다
    if _CAL_ADD.search(text) and re.search(r"\d|내일|모레|다음\s*주|월요일|화요일|"
                                           r"수요일|목요일|금요일|토요일|일요일", text):
        return "cal_add"
    if _CAL_SEE.search(text):
        return "cal_see"
    if _BOARD_MAKE.search(text):
        return "board_make"                              # 대시보드를 대신 만들어 준다
    if _BOARD_SEE.search(text):
        return "board_see"                               # 내 대시보드 주소
    if _SEARCH.search(text):
        return "search"                                  # 클로드가 답하되 반드시 찾아보게
    return ""


# ── 클로드에게 넘기기 ─────────────────────────────────────────────────
RULE = """너는 {name} 이다. 교회 업무를 돕는 비서다. 지금은 {now} 이다.

이 폴더 안에 이런 것들이 있다. 필요하면 읽어라.
- knowledge/  우리 교회 용어·조직·보고 규칙 (예: knowledge/01-용어정의.md)
- features/   이 비서의 기능 코드
- 내규칙.md    사용자가 쌓아온 규칙

**사용자가 "이렇게 기억해" "앞으로는 이렇게 해" 라고 하면 내규칙.md 에 적어라.**
기능을 고쳐 달라고 하면 features/ 안의 파일을 고쳐도 된다 —
고친 것은 다음에 켤 때부터 쓰인다(프로그램을 다시 켜라고 알려줘라).

지킬 것:
- 존댓말. 짧고 정확하게.
- **모르면 모른다고 해라.** 그럴듯하게 지어내지 마라 — 그게 제일 위험하다.
- 숫자는 근거가 있을 때만. 없으면 '자료 없음' 이라고 써라.
- **바깥 소식(뉴스·시세·환율·날씨·최신 자료)은 기억으로 답하지 마라. 검색해서 답해라.**
  검색을 못 했으면 답 첫 줄에 '검색을 못 했습니다 — 아래는 예전에 알던 내용입니다'
  라고 반드시 밝혀라. 밝히지 않고 옛날 이야기를 하는 것이 제일 나쁘다.
- 날짜 계산이 필요하면 오늘({today}) 을 기준으로 하되, 헷갈리면 물어봐라.
- 텔레그램으로 보내는 글이다. 마크다운 표는 쓰지 마라(깨진다). 줄바꿈과 · 로 정리해라.
{tg}
사용자가 한 말:
{text}"""


# 텔레그램 창고 — 사용자의 텔레그램 대화가 이 컴퓨터에 모여 있다(features/tgbox.py).
# 뇌(부장님 아델)의 검색 규칙에서 실제로 효과 본 것만 옮겼다.
TG_TOOL = """
■ 사용자의 텔레그램 (가장 먼저 볼 곳)
사용자가 속한 텔레그램 방 대화가 이 컴퓨터 창고에 모여 있다(최근 30일 안에 말이 오간 방, 1년치).
'누가·언제·어느 방에서·무슨 말/자료' 는 전부 여기서 찾아라. 교회 안의 일은 인터넷에 없다.
부르는 법 (Bash 로 그대로 — 내용은 JSON 으로 stdin 에 넣는다. EOF 줄은 맨 앞에 붙여 써라):
curl -s http://127.0.0.1:47633/tg/search -H "X-Adele: $(cat data/tgbox.key)" --data-binary @- <<'EOF'
{{"q": "출결보고", "since": "2026-09-01"}}
EOF
  · search  q(낱말) room(방이름 일부) sender(보낸사람) since/until(YYYY-MM-DD) any(true=하나라도) oldest full(true=안 자르고) limit
  · rooms   방 목록({{"q":"방이름 일부"}}) · status 창고 상태 · sync 새 글 지금 받기
  · send    {{"room":"방이름 일부","text":"내용"}} → 미리보기만. 실제로 보내려면 "send": true
  · plan/add  {{"room":"방","text":"내용","time":"07:30","repeat":"매일|평일|주말|월,수,금|한번","date":"한번일 때 YYYY-MM-DD"}}
  · plan/list · plan/remove {{"id":"예약번호"}}
찾는 법:
  - 되묻지 마라('어느 방이요?' 금지). 먼저 스스로 찾아와라. 방·날짜를 몰라도 된다.
  - **낱말은 1~2개만.** 여러 개면 전부 들어간 글만 잡혀 정답이 빠진다. 못 찾으면 낱말을 줄이거나 바꿔 2~3번 더 찾아라.
    띄어쓰기는 창고가 알아서 무시한다. 넓게 볼 땐 any, 그 방 그날치를 통째로 볼 땐 q 없이 room+since.
  - '오늘·어제·이번주·최근' 이면 since 로 좁혀라. 같은 주제 숫자가 여러 번 바뀌었으면 가장 최신이 답이다.
  - 할당·목표 숫자와 실제 결과 숫자를 섞지 마라. 실제를 못 찾았으면 '실제 수는 못 찾음(할당은 X)' 이라고 해라.
  - 답할 땐 근거 글의 **날짜·시각·방·보낸 사람**을 붙여라. 링크가 나오면 같이 붙여라.
  - '방금 올라온 것' 을 찾으면 먼저 sync 를 한 번 부르고 찾아라.
  - 창고가 비어 있거나 모으는 중이라고 나오면 그대로 알려라. 지어내지 마라.
보내기·예약:
  - 남의 방에 나가는 글은 되돌릴 수 없다. 방과 내용이 분명하고 사용자가 '보내/공지해' 라고 했을 때만 send:true.
    애매하면 미리보기를 보여주고 '이대로 보낼까요?' 라고 물어라. 후보가 여러 방이면 절대 고르지 말고 물어라.
  - 예약은 시각·반복을 사용자 말 그대로 옮겨라. 요일·다음 날짜 계산은 창고가 한다. 결과 문장을 그대로 전해라.
  - 교인 명단·연락처·출결 같은 민감한 내용은 방에 함부로 올리지 마라.
"""


# 찾아봐 달라는 부탁일 때만 얹는다. 검색은 클로드가 대신 해 주는 것이라
# 안 되는 환경에서도 조용히 아는 대로 답해 버린다 — 그걸 못 하게 못박는다.
SEARCH_RULE = """

**이번 부탁은 찾아봐 달라는 것이다.**
- 교회 안의 일(사람·방·보고·공지·명단·일정 이야기)이면 **텔레그램 창고부터** 찾아라. 거기 없을 때만 인터넷.
- 바깥 소식(뉴스·시세·날씨·일반 지식)이면 **반드시 인터넷을 검색해서** 답해라.
- 기억으로 답하지 마라. 검색 도구를 실제로 써라.
- 검색이 안 되면 **'검색을 못 했습니다' 를 첫 줄에 쓰고** 왜 못 했는지 한 줄 덧붙여라.
  그 상태에서 아는 대로 답하려거든 '예전에 알던 내용' 이라고 반드시 표시해라.
- 찾았으면 **언제 것인지(날짜)와 어디서 봤는지**를 같이 적어라."""


# 마지막으로 물었을 때 얼마나 썼나. 답 끝에 한 줄로 붙여 준다(부장님 요청 2026-09-07).
_LAST_USE: dict = {}
_PROC: dict = {"p": None, "no": 0}                         # 지금 도는 클로드 — 「중단」 단추가 이걸 끈다
_CANCEL: set = set()                                       # 중단한 작업 번호
_TG_ON = False                                               # 텔레그램 창고가 켜졌나 — 안 켜졌으면 안내하지 않는다


def _ask_with_usage(cfg: dict, prompt: str) -> str | None:
    """클로드에게 묻고 **쓴 양까지** 받아온다.

    `brain.ask` 를 안 쓰고 여기서 따로 부르는 까닭은 `remote.py` 와 같다 —
    brain 은 구운 실행파일 안에 있어 새로 굽지 않으면 못 고치는데, 이 파일은
    저절로 내려간다. `--output-format json` 을 붙이면 답과 함께 쓴 토큰이 온다.

    사용량을 못 읽어도 **답은 나와야 한다** — 못 읽으면 조용히 비워 둔다.
    """
    _LAST_USE.clear()
    exe = brain.claude_exe(cfg)
    mine = brain.my_rules()
    # 옛 길(brain.ask)은 제 규칙을 스스로 얹는다 — 여기서 얹은 것을 그쪽에 또 주면 두 번 들어간다
    full = f"[내 규칙 — 이걸 먼저 따른다]\n{mine}\n\n---\n\n{prompt}" if mine else prompt
    no = _PROC.get("no", 0)
    try:
        p = subprocess.Popen([exe, "-p", "--permission-mode", "bypassPermissions",
                              "--output-format", "json"],
                             cwd=str(HOME_DIR), stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                             stderr=subprocess.PIPE, encoding="utf-8", errors="replace",
                             env=brain.clean_env())
        _PROC["p"] = p
        try:
            out, _err = p.communicate(full, timeout=900)
        except subprocess.TimeoutExpired:
            p.kill()
            out, _err = p.communicate()
            raise
        finally:
            _PROC["p"] = None
        if no in _CANCEL:                                    # 사람이 「중단」 을 눌렀다
            return None
        r = subprocess.CompletedProcess(p.args, p.returncode, out, _err)
    except (subprocess.TimeoutExpired, OSError) as e:
        print(f"[listen] 물어보기 실패 — {type(e).__name__}: {e}", file=sys.stderr)
        return brain.ask(cfg, prompt)                        # 옛 길로 한 번 더 (규칙은 그쪽이 얹는다)
    try:
        d = json.loads(r.stdout or "{}")
        u = d.get("usage") or {}
        _LAST_USE.update({
            "tokens": sum(int(u.get(k) or 0) for k in
                          ("input_tokens", "output_tokens",
                           "cache_creation_input_tokens", "cache_read_input_tokens")),
            "sec": int((d.get("duration_ms") or 0) / 1000)})
        return d.get("result") or None
    except (ValueError, TypeError):                          # json 이 아니면 옛 길로
        print("[listen] 사용량을 못 읽었습니다 — 답만 보냅니다", file=sys.stderr)
        return r.stdout or None


def _used(sec: int) -> str:
    """답 끝에 붙일 한 줄. 걸린 시간과 쓴 토큰."""
    tok = _LAST_USE.get("tokens") or 0
    if not tok:
        return f"\n\n· {_ago(sec)} 걸렸습니다"
    return f"\n\n· {_ago(sec)} · 토큰 {tok:,}"


def _think(text: str, what: str = "") -> str | None:
    now = datetime.now(KST)
    prompt = RULE.format(name=brain.bot_name(), now=now.strftime("%m/%d %H:%M"),
                         today=now.strftime("%Y-%m-%d"), text=text,
                         tg=TG_TOOL.format() if _TG_ON else "")
    if what == "search":
        prompt += SEARCH_RULE
    elif what == "tg":
        prompt += ("\n\n**이번 부탁은 사용자의 텔레그램 안의 일이다. 위의 텔레그램 창고로 해라.** "
                   "인터넷을 찾지 마라.")
    return _ask_with_usage(_cfg(), prompt)


def _ago(sec: int) -> str:
    return f"{sec // 60}분 {sec % 60}초" if sec >= 60 else f"{sec}초"


class _Working:
    """일하는 동안 "하고 있습니다" 를 계속 보여준다.

    전에는 typing 표시를 한 번 켜고 조용했다. 클로드가 1~5분을 생각하는 동안
    화면에는 아무것도 없어서, 사용자는 죽은 줄 알고 또 말을 걸었다
    (2026-09-04 사명자가 실제로 겪음). 이제 한 통을 띄워 놓고 몇 초 지났는지
    **그 통을 고쳐 쓰며** 보여준다 — 방을 도배하지 않는다.

    일하는 동안 살아있음(_beat)도 여기서 찍는다. 안 찍으면 guard 가 3분 만에
    죽은 줄 알고 되살리기를 시도하며 헛경보를 보낸다.
    """

    def __init__(self, token: str, chat: str, first: str = "⏳ 처리 중입니다…",
                 no: int = 0, head: str = "", mid: int = 0):
        self.token, self.chat, self.first = token, chat, first
        self.no, self.head = no, head                        # [4번] 여기서 연령특례 항목은 삭제…
        self.mid = mid                                       # 기다리라고 띄워 둔 통이 있으면 그걸 고쳐 쓴다
        self.t0 = time.time()
        self._stop = threading.Event()
        self._th: threading.Thread | None = None

    def _btn(self) -> dict | None:
        return _stop_btn(self.no) if self.no else None

    def __enter__(self) -> "_Working":
        if self.no:
            self.first = f"{self.head}\n⏳ 작업 시작했어요 — 다 되면 결과를 보내드릴게요."
        if not (self.mid and _edit(self.token, self.chat, self.mid, self.first, self._btn())):
            self.mid = _say_once(self.token, self.chat, self.first, self._btn())
        self._th = threading.Thread(target=self._tick, daemon=True)
        self._th.start()
        return self

    def _tick(self) -> None:
        while not self._stop.wait(TICK):
            _beat()                                          # 일하는 중에도 살아있다
            _call(self.token, "sendChatAction",
                  {"chat_id": self.chat, "action": "typing"})
            if self.no in _CANCEL:
                return
            lead = f"{self.head}\n" if self.no else ""
            _edit(self.token, self.chat, self.mid,
                  f"{lead}⏳ 아직 하고 있어요 ({_ago(int(time.time() - self.t0))} 지났어요) — "
                  f"다 되면 결과를 보내드릴게요.", self._btn())

    def done(self, text: str = "") -> None:
        """끝났다. 안내를 마지막 말로 바꾸거나, 할 말이 없으면 지운다."""
        self._stop.set()
        if self._th:
            self._th.join(timeout=3)
        if text:
            if not _edit(self.token, self.chat, self.mid, text):
                _send(self.token, self.chat, text)
        elif self.no:                                        # 번호 붙은 일 — 단추만 떼고 남긴다
            _edit(self.token, self.chat, self.mid, f"{self.head}\n✅ 다 했어요.")
        else:
            _erase(self.token, self.chat, self.mid)

    def __exit__(self, *a) -> bool:
        self._stop.set()
        return False


def _handle(what: str, text: str, token: str, chat: str) -> bool:
    """일정·차트처럼 실제로 뭔가 해야 하는 부탁. 처리했으면 True."""
    if what in ("search", "tg"):                         # 찾기·텔레그램은 클로드가 한다 — 아래로 넘긴다
        return False
    sys.path.insert(0, str(ROOT / "features"))

    if what == "board_see":
        import link
        url = link.board_url() or link.fix_board()
        _send(token, chat, f"업무 레이더 화면입니다.\n{url}" if url else
              "아직 업무 레이더 화면이 없습니다. '대시보드 만들어줘' 라고 하시면 만들어 드립니다.")
        return True

    if what == "board_make":
        import link
        import remote
        _send(token, chat, "만들어 보겠습니다 — 3~5분 걸립니다.\n"
                           "이 컴퓨터의 크롬이 저절로 움직입니다. 그 창을 닫지 마십시오.")
        r = remote.make_firebase(_cfg())
        if not r.get("ok"):
            _send(token, chat, "못 만들었습니다 — " + (r.get("error") or "")
                  + (f"\n({r['detail']})" if r.get("detail") else ""))
            return True
        url = link.fix_board() or link.board_url()
        _send(token, chat, f"다 만들었습니다 — {r.get('project','')}\n{url}\n"
                           "브리핑이 한 번 돌면 이 화면에 뜹니다.")
        return True

    if what == "chart":
        import chart
        _call(token, "sendChatAction", {"chat_id": chat, "action": "upload_photo"})
        path, msg = chart.from_text(text)
        if path:
            _photo(token, chat, path, msg)
        else:
            _send(token, chat, msg)
        return True

    import cal
    ok, why = cal.ready()
    if not ok:
        _send(token, chat, why)
        return True

    if what == "cal_add":
        d = cal.parse(text)
        if not d:
            _send(token, chat, "무슨 일정인지 못 읽었습니다. 날짜와 할 일을 같이 말해 주십시오.")
            return True
        _send(token, chat, cal.add(d)[1])
        return True

    week = bool(re.search(r"이번\s*주|금주|주간", text))
    items = cal.this_week() if week else cal.today()
    _send(token, chat, cal.render(items, "이번주 일정" if week else "오늘 일정"))
    return True


# ── 본체 ──────────────────────────────────────────────────────────────
def _link() -> None:
    """켤 때 클로드 자리를 찾아 기억하고, 폴더에 안내를 놓는다(조용히)."""
    try:
        import link
        r = link.ensure()
        if r["remembered"]:
            print(f"[listen] 클로드 코드를 찾았습니다 — {r['found']}", flush=True)
        if not r["found"]:
            print("[listen] 클로드 코드를 못 찾았습니다 — 설치 화면에서 확인해 주십시오.",
                  file=sys.stderr)
    except Exception as e:                                   # noqa: BLE001
        print(f"[listen] 이어주기 건너뜀 — {type(e).__name__}: {e}", file=sys.stderr)


def _head(no: int, text: str) -> str:
    one = " ".join(text.split())
    return f"[{no}번] " + (one[:18] + "…" if len(one) > 18 else one)


def _work(what: str, text: str, token: str, chat: str, no: int = 0, mid: int = 0) -> None:
    """물음 하나를 끝까지 처리한다. 일하는 내내 진행 상황을 보여준다."""
    if no in _CANCEL:                                        # 차례가 오기 전에 중단했다
        return
    _PROC["no"] = no
    with _Working(token, chat, no=no, head=_head(no, text) if no else "", mid=mid) as w:
        if what:                                             # 손이 필요한 부탁
            try:
                if _handle(what, text, token, chat):
                    w.done()
                    return
            except Exception as e:                           # noqa: BLE001
                print(f"[listen] {what} 실패 — {type(e).__name__}: {e}", file=sys.stderr)
                w.done(f"그건 못 했습니다 — {type(e).__name__}")
                return
        got = _think(text, what)
        if no in _CANCEL:
            w.done(f"{_head(no, text)}\n🛑 중단했어요.")
            return
        if got and got.strip():
            w.done()
            _send(token, chat, got.strip() + _used(int(time.time() - w.t0)))
        else:
            w.done("지금은 생각하는 쪽이 답하지 않습니다.\n"
                   "이 PC 에서 claude 가 로그인돼 있는지 확인해 주십시오.")


# ── 누구 말을 듣나 (보안) ─────────────────────────────────────────────
# 이 봇은 개인 비서다. 쓰는 사람도, 관리하는 사람도 주인 한 명뿐이다.
# 봇은 텔레그램에서 검색되므로 **아무나 말을 걸 수 있다고 전제한다.**
#   · 주인은 이 PC 에 로그인한 텔레그램 본인 계정으로만 정한다(tgbox.my_id).
#     전에는 '처음 말 거는 사람' 을 주인으로 모셨다 — 남이 먼저 걸면 PC 를 뺏긴다.
#   · 본인 계정을 못 읽을 때만 비밀 입장 링크(/start <열쇠>)로 정한다.
#     열쇠는 설정(start_key)에 있고 hmac.compare_digest 로 대조한다.
#     한 번 정해지면 owner_locked 를 남겨 링크 입장을 다시는 열지 않는다.
#   · 모르는 사람에게는 한 마디도 하지 않는다. 단체방에 끌려 들어가면 나간다.
#   · 되찾기(비상구): 이 PC 에서 `setup.py 주인다시` — PC 앞에 앉은 사람만 할 수 있다.
#   · 기록에는 받은 말의 내용·열쇠를 남기지 않는다.
RATE_N, RATE_SEC = 20, 60                                  # 한 사람이 1분에 20통 넘게 보내면 잠시 끊는다
BAD_N, BAD_BLOCK = 5, 3600                                 # 틀린 입장 5번이면 1시간 무시
_RATE: dict = {}
_BAD: dict = {}
_BLOCKED: dict = {}
_LEFT: set = set()


def _set_cfg(**kv) -> None:
    """설정에 몇 가지를 적어 둔다 — 다음에 켤 때도 그대로."""
    f = HOME_DIR / "config.json"
    try:
        try:
            c = json.loads(f.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            c = {}
        c.update(kv)
        f.parent.mkdir(parents=True, exist_ok=True)
        f.write_text(json.dumps(c, ensure_ascii=False, indent=2), encoding="utf-8")
    except OSError as e:
        print(f"[listen] 설정을 적어두지 못했습니다 — {type(e).__name__}", file=sys.stderr)


def _remember_owner(chat: str) -> None:
    _set_cfg(admin_telegram_id=str(chat), owner_locked=True)


def _start_key(cfg: dict) -> str:
    """비밀 입장 열쇠. 없으면 만든다(텔레그램 규격: 영숫자·_·- 64자 이내)."""
    key = str(cfg.get("start_key") or "")
    if not key:
        import secrets
        key = secrets.token_urlsafe(32)[:43]
        _set_cfg(start_key=key)
    return key


def _too_fast(chat: str) -> bool:
    now = time.time()
    seen = [t for t in _RATE.get(chat, []) if now - t < RATE_SEC]
    seen.append(now)
    _RATE[chat] = seen
    return len(seen) > RATE_N


def _bad(chat: str) -> None:
    """틀린 입장 시도를 센다 — 열쇠를 마구 넣어 보는 것을 막는다."""
    _BAD[chat] = _BAD.get(chat, 0) + 1
    if _BAD[chat] >= BAD_N:
        _BLOCKED[chat] = time.time() + BAD_BLOCK
        _BAD[chat] = 0


def _my_id() -> str:
    try:
        sys.path.insert(0, str(ROOT / "features"))
        import tgbox
        return tgbox.my_id()
    except Exception as e:                                   # noqa: BLE001
        print(f"[listen] 본인 계정을 못 읽음 — {type(e).__name__}", file=sys.stderr)
        return ""


def run() -> int:
    _link()                                              # 제일 먼저 이어둔다
    _only_one()
    cfg = _cfg()
    token = (cfg.get("telegram_bot_token") or "").strip()
    owner = str(cfg.get("admin_telegram_id") or "").strip()
    if not token:
        print("설정에 봇 토큰이 없습니다. 설치 화면에서 봇을 먼저 만드십시오.",
              file=sys.stderr)
        return 1
    # 주인은 이 PC 에 로그인한 본인 계정이다. 적힌 주인이 그와 다르면 바로잡는다
    # — 옛 방식(처음 말 거는 사람)으로 남이 주인이 됐을 수 있다.
    me = _my_id()
    if me and owner != me:
        if owner:
            print("[listen] 적힌 주인이 이 PC 의 텔레그램 계정과 달라 본인으로 바로잡습니다",
                  file=sys.stderr)
        owner = me
        _remember_owner(me)
    elif not owner:
        # 본인 계정을 못 읽었다 — 비밀 입장 링크로만 주인을 받는다.
        # 링크는 `setup.py 상태` 가 보여준다. 먼저 말 거는 사람을 주인으로 삼지 않는다.
        _start_key(cfg)
        print("주인이 아직 안 정해졌습니다 — 비밀 입장 링크로 들어온 분만 주인으로 모십니다.",
              flush=True)
    locked = bool(cfg.get("owner_locked")) or bool(owner)

    st = _state()
    offset = int(st.get("offset", 0))
    print(f"말 걸기 시작 — 봇 대기 중 (offset {offset})", flush=True)
    _beat()

    # 텔레그램 창고(찾기·보내기·예약)를 같이 켠다. 못 켜도 말 걸기는 살아 있어야 한다.
    global _TG_ON
    try:
        sys.path.insert(0, str(ROOT / "features"))
        import tgbox
        _TG_ON = tgbox.start(notify=lambda line: owner and _send(token, owner, line))
    except Exception as e:                                   # noqa: BLE001
        print(f"[listen] 텔레그램 창고 못 켬 — {type(e).__name__}: {e}", file=sys.stderr)

    # 일은 딴 갈래에서 한다. 전에는 여기서 그냥 클로드를 기다렸는데, 그동안
    # 새 말을 아예 못 읽었다 — 기다리다 답답해서 다시 말을 걸어도 감감무소식이었다.
    # 이제 받는 쪽은 계속 듣고, 일은 한 줄로 세워 차례대로 한다(둘이 겹치면 안 된다).
    jobs: "queue.Queue[tuple[str, str, int, int]]" = queue.Queue()
    busy = threading.Event()

    def worker() -> None:
        while True:
            what, text, no, mid = jobs.get()
            busy.set()
            try:
                _work(what, text, token, owner, no, mid)
            except Exception as e:                           # noqa: BLE001
                print(f"[listen] 일하다 넘어짐 — {type(e).__name__}: {e}", file=sys.stderr)
                _send(token, owner, f"그건 못 했습니다 — {type(e).__name__}")
            finally:
                busy.clear()
                jobs.task_done()
                _beat()

    threading.Thread(target=worker, daemon=True).start()

    # 잇달아 보낸 말은 묶어서 한 일로 한다(부장님 텔레봇과 같게 — 2026-11-18).
    # 마지막 말 뒤 GAP 초 동안 더 안 오면 그때 줄에 세운다.
    GAP = 2.5
    pend: list = []
    pend_lock = threading.Lock()
    last_in = [0.0]

    def enqueue(texts: list) -> None:
        if len(texts) > 1:
            _send(token, owner, f"⏳ 메시지 {len(texts)}개를 묶어서 한 작업으로 처리할게요…")
        text = "\n".join(texts)
        no = int(st.get("job_no", 0)) + 1
        st["job_no"] = no
        _save(st)
        ahead = jobs.qsize() + (1 if busy.is_set() else 0)
        mid = 0
        if ahead:                                            # 앞의 일이 아직 안 끝났다
            mid = _say_once(token, owner, f"{_head(no, text)}\n⏳ 앞의 일을 하고 있어요 — "
                                          f"{ahead + 1}번째로 이어서 할게요.", _stop_btn(no))
        jobs.put((_route(text), text, no, mid))
        _beat()

    def batcher() -> None:
        while True:
            time.sleep(0.5)
            with pend_lock:
                if not pend or time.time() - last_in[0] < GAP:
                    continue
                texts = pend[:]
                pend.clear()
            try:
                enqueue(texts)
            except Exception as e:                           # noqa: BLE001
                print(f"[listen] 줄 세우기 실패 — {type(e).__name__}: {e}", file=sys.stderr)

    threading.Thread(target=batcher, daemon=True).start()

    def on_button(cq: dict) -> None:
        """「이 작업 중단」 — 주인이 누른 것만 듣는다."""
        who = str((cq.get("from") or {}).get("id", ""))
        _call(token, "answerCallbackQuery", {"callback_query_id": cq.get("id")})
        if not owner or who != owner:
            return
        data = str(cq.get("data") or "")
        if not data.startswith("stop:"):
            return
        try:
            no = int(data[5:])
        except ValueError:
            return
        _CANCEL.add(no)
        if _PROC.get("no") == no and _PROC.get("p"):
            try:
                _PROC["p"].kill()
            except Exception:                                # noqa: BLE001
                pass
        m = cq.get("message") or {}
        old = (m.get("text") or "").split("\n")[0]
        _edit(token, owner, int(m.get("message_id") or 0), f"{old}\n🛑 중단했어요.")
        print(f"[listen] {no}번 작업 중단", flush=True)

    # 새 버전이 내려와 이 파일들이 바뀌면, 쉬는 틈에 스스로 다시 켠다.
    # 안 그러면 컴퓨터를 다시 켜기 전까지 옛 코드로 계속 돈다(2026-09-13 발견).
    mine = [ROOT / "features" / n for n in ("listen.py", "tgbox.py")]

    def stamp() -> list:
        return [f.stat().st_mtime if f.exists() else 0 for f in mine]

    born = stamp()

    def renew() -> None:
        while True:
            time.sleep(60)
            if stamp() == born or busy.is_set() or not jobs.empty():
                continue
            print("[listen] 새 코드가 왔습니다 — 다시 켭니다", flush=True)
            try:
                if _lock_sock:
                    _lock_sock.close()                       # 새로 뜰 쪽이 자리를 잡게
                import guard
                guard._launch()
            finally:
                os._exit(0)

    threading.Thread(target=renew, daemon=True).start()
    started = time.time()

    while True:
        r = _call(token, "getUpdates",
                  {"offset": offset, "timeout": POLL, "allowed_updates": ["message", "callback_query"]},
                  timeout=POLL + 15)
        _beat()                                              # 조용해도 살아있다고 남긴다

        if not r.get("ok"):
            why = r.get("description", "")
            if "409" in str(why) or "Conflict" in str(why):
                if time.time() - started < 90:               # 막 다시 켰으면 옛 것이 아직 안 놓은 것 — 기다린다
                    time.sleep(5)
                    continue
                print("다른 곳에서도 같은 봇을 보고 있습니다 — 끝냅니다.", file=sys.stderr)
                return 1
            print(f"[listen] {why}", file=sys.stderr)
            time.sleep(5)                                    # 인터넷이 끊겼을 수 있다 — 쉬고 다시
            continue

        for up in r.get("result", []):
            offset = max(offset, up.get("update_id", 0) + 1)
            st["offset"] = offset
            _save(st)

            if up.get("callback_query"):
                try:
                    on_button(up["callback_query"])
                except Exception as e:                       # noqa: BLE001
                    print(f"[listen] 단추 처리 실패 — {type(e).__name__}", file=sys.stderr)
                continue
            msg = up.get("message") or {}
            room = msg.get("chat") or {}
            chat = str(room.get("id", ""))
            if room.get("type") != "private":
                # 단체방 — 들인 적이 없다. 한 마디 없이 나간다(내용은 읽지 않는다).
                if chat and chat not in _LEFT:
                    _LEFT.add(chat)
                    _call(token, "leaveChat", {"chat_id": chat})
                    print("[listen] 단체방에 들어와져 있어 나왔습니다", file=sys.stderr)
                continue
            if _BLOCKED.get(chat, 0) > time.time():
                continue
            text = (msg.get("text") or msg.get("caption") or "").strip()
            if not text:
                continue
            if _too_fast(chat):
                continue
            if not owner:
                # 비밀 입장 링크(/start <열쇠>)로 들어온 분만 주인으로 모신다.
                word, _, got = text.partition(" ")
                key = str(_cfg().get("start_key") or "")
                import hmac
                if (not locked and key and word.split("@")[0] == "/start"
                        and hmac.compare_digest(got.strip().encode(), key.encode())):
                    owner, locked = chat, True
                    _remember_owner(chat)
                    _send(token, chat, "반갑습니다. 이제부터 주인으로 모시겠습니다.\n"
                                       "무엇이든 말씀해 주십시오.")
                    print("[listen] 비밀 링크로 주인을 모셨습니다", flush=True)
                else:
                    _bad(chat)                               # 대꾸하지 않는다
                continue
            if chat != owner:                                # 주인 말만 듣는다 — 남에겐 한 마디도 안 한다
                print("[listen] 모르는 사람 — 무시", file=sys.stderr)
                continue

            print(f"[listen] 받음 ({len(text)}자)", flush=True)   # 내용은 적지 않는다
            _call(token, "sendChatAction", {"chat_id": chat, "action": "typing"})

            with pend_lock:                                  # 바로 세우지 않고 잠깐 모은다
                pend.append(text)
                last_in[0] = time.time()
            _beat()


def main() -> int:
    try:
        return run()
    except KeyboardInterrupt:
        return 0
    except Exception as e:                                   # noqa: BLE001
        print(f"[listen] 멈춤 — {type(e).__name__}: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
