# -*- coding: utf-8 -*-
"""아침 업무 시작 브리핑 — 아침 6~10시에 텔레그램을 처음 앞으로 띄우면(=하루 시작) 하루 한 번.

부장님 맥의 workstart.py 를 사명자 배포판으로 옮긴 것(2026-11-22).

  · 텔레그램이 맨 앞 창이 되는 걸 5초마다 본다(윈도우 · 맥).
  · 그 순간 오늘 일정(cal.py — 연결돼 있을 때만)과 날씨(Open-Meteo, 열쇠 없음)를
    data/briefing_today.txt 에 적는다. 숫자는 여기서 받은 값만 쓴다 — 클로드에게 날씨를 짐작시키지 않는다.
  · 터미널(윈도우 터미널 / 파워셸 / 맥 Ghostty·터미널)을 열어 비서 폴더에서 클로드 코드를 켜고
    "그 파일을 읽고 짧게 브리핑해 줘" 라고 시킨다.

listen(24시간 켜두기)이 뒤에서 start() 를 부른다. 봇이 없어도 돈다.
손으로 시험:  python morning.py --brief    브리핑 글만 만든다
             python morning.py --launch   터미널 띄우기까지(오늘 했다는 표시는 안 남긴다)
끄기:        설정에 "morning_brief": false
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import threading
import time
import urllib.request
from datetime import datetime, timedelta, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "features"))

from brain import HOME_DIR                                                 # noqa: E402

KST = timezone(timedelta(hours=9))
WINDOW = (6, 10)                                # 6시 ~ 9시 59분
STAMP = HOME_DIR / "data" / "morning_last.txt"   # 오늘 이미 했는지
OUT = HOME_DIR / "data" / "briefing_today.txt"
LOG = HOME_DIR / "data" / "morning.log"
HANAM = (37.539, 127.214, "하남시")              # 강동교회 근처 — 설정 weather_lat/lon/place 로 바꾼다

WMO = {0: "맑음", 1: "대체로 맑음", 2: "구름 조금", 3: "흐림", 45: "안개", 48: "안개",
       51: "약한 이슬비", 53: "이슬비", 55: "강한 이슬비", 61: "약한 비", 63: "비", 65: "강한 비",
       66: "어는 비", 67: "어는 비", 71: "약한 눈", 73: "눈", 75: "많은 눈", 77: "싸락눈",
       80: "소나기", 81: "소나기", 82: "강한 소나기", 85: "눈 소나기", 86: "눈 소나기",
       95: "뇌우", 96: "우박 뇌우", 99: "우박 뇌우"}


def _log(msg: str) -> None:
    try:
        LOG.parent.mkdir(parents=True, exist_ok=True)
        with LOG.open("a", encoding="utf-8") as f:
            f.write(f"{datetime.now(KST):%m/%d %H:%M:%S} {msg}\n")
    except OSError:
        pass


def _cfg() -> dict:
    try:
        return json.loads((HOME_DIR / "config.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


# ── 날씨 ──────────────────────────────────────────────────────────────
def _get(url: str) -> dict:
    with urllib.request.urlopen(url, timeout=15) as r:
        return json.load(r)


def _grade(v, cuts) -> str:
    for lim, name in cuts:
        if v <= lim:
            return name
    return "매우 나쁨"


def _weather_once() -> str:
    c = _cfg()
    lat = c.get("weather_lat") or HANAM[0]
    lon = c.get("weather_lon") or HANAM[1]
    place = c.get("weather_place") or HANAM[2]
    w = _get("https://api.open-meteo.com/v1/forecast?latitude=%s&longitude=%s"
             "&current=temperature_2m,weather_code"
             "&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max,uv_index_max,weather_code"
             "&hourly=precipitation_probability&timezone=Asia%%2FSeoul&forecast_days=1" % (lat, lon))
    a = _get("https://air-quality-api.open-meteo.com/v1/air-quality?latitude=%s&longitude=%s"
             "&current=pm10,pm2_5&timezone=Asia%%2FSeoul" % (lat, lon))
    cur, day = w["current"], w["daily"]
    now_t = round(cur["temperature_2m"])
    hi, lo = round(day["temperature_2m_max"][0]), round(day["temperature_2m_min"][0])
    sky = WMO.get(day["weather_code"][0], "")
    hour = datetime.now(KST).hour
    left = [(int(t[11:13]), p) for t, p in zip(w["hourly"]["time"], w["hourly"]["precipitation_probability"])
            if p is not None and int(t[11:13]) >= hour]
    rain = max(p for _, p in left) if left else (day["precipitation_probability_max"][0] or 0)
    uv = day["uv_index_max"][0] or 0
    pm10, pm25 = a["current"]["pm10"], a["current"]["pm2_5"]
    order = ["좋음", "보통", "나쁨", "매우 나쁨"]
    dust = max(_grade(pm10, [(30, "좋음"), (80, "보통"), (150, "나쁨")]),
               _grade(pm25, [(15, "좋음"), (35, "보통"), (75, "나쁨")]), key=order.index)
    lines = [f"{place} 지금 {now_t}도, 오늘은 {sky}. 최고 {hi}도 최저 {lo}도입니다."]
    if rain >= 40:
        hrs = [h for h, p in left if p >= 40]
        lines.append(f"비 올 확률 {rain}%" + (f" {hrs[0]}시부터" if hrs else "") + ", 우산 챙기세요.")
    else:
        lines.append(f"비 올 확률은 {rain}%로 낮습니다.")
    lines.append(f"미세먼지는 {dust}" + (", 마스크 챙기세요." if dust in ("나쁨", "매우 나쁨") else "입니다."))
    if uv >= 6:
        lines.append(f"자외선이 높습니다({uv:.0f}).")
    if hi - lo >= 10:
        lines.append(f"일교차가 {hi - lo}도라 겉옷 챙기세요.")
    return " ".join(lines)


def weather_text() -> str:
    err = None
    for _ in range(4):                          # 깨어난 직후 인터넷이 늦게 붙을 수 있다
        try:
            return _weather_once()
        except Exception as e:                  # noqa: BLE001
            err = e
            time.sleep(10)
    return f"날씨를 못 받아 왔습니다({type(err).__name__})."


# ── 일정 ──────────────────────────────────────────────────────────────
def schedule_text() -> str:
    try:
        import cal
        ok, why = cal.ready()
        if not ok:
            return "일정: 캘린더가 연결 안 돼 있습니다."
        items = cal.today()
    except Exception as e:                      # noqa: BLE001
        return f"일정: 캘린더를 못 읽었습니다({type(e).__name__})."
    if not items:
        return "일정: 오늘 잡힌 일정이 없습니다."
    rows = []
    for it in items:
        if it.get("allday"):
            when = "종일"
        else:
            when = it["start"].strftime("%H:%M") + (("~" + it["end"].strftime("%H:%M")) if it.get("end") else "")
        rows.append(f"  {when}  {it['title']}" + (f"  @{it['place']}" if it.get("place") else ""))
    return f"일정 {len(items)}건\n" + "\n".join(rows)


def brief() -> str:
    text = f"{schedule_text()}\n날씨: {weather_text()}"
    try:
        OUT.parent.mkdir(parents=True, exist_ok=True)
        OUT.write_text(datetime.now(KST).strftime("%Y-%m-%d %H:%M\n") + text + "\n", encoding="utf-8")
    except OSError:
        pass
    return text


# ── 맨 앞 창 ──────────────────────────────────────────────────────────
def front_app() -> str:
    """맨 앞 창의 프로그램 이름(소문자). 못 읽으면 ''."""
    if os.name == "nt":
        try:
            import ctypes
            from ctypes import wintypes
            u, k = ctypes.windll.user32, ctypes.windll.kernel32
            hwnd = u.GetForegroundWindow()
            if not hwnd:
                return ""
            pid = wintypes.DWORD()
            u.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
            h = k.OpenProcess(0x1000, False, pid.value)       # PROCESS_QUERY_LIMITED_INFORMATION
            if not h:
                return ""
            try:
                buf = ctypes.create_unicode_buffer(1024)
                n = wintypes.DWORD(1024)
                if k.QueryFullProcessImageNameW(h, 0, buf, ctypes.byref(n)):
                    return Path(buf.value).name.lower()
            finally:
                k.CloseHandle(h)
        except Exception:                       # noqa: BLE001
            return ""
        return ""
    if sys.platform == "darwin":
        try:
            r = subprocess.run(["lsappinfo", "info", "-only", "name", "front"],
                               capture_output=True, text=True, timeout=5)
            return r.stdout.lower()
        except Exception:                       # noqa: BLE001
            return ""
    return ""


def _is_telegram(name: str) -> bool:
    return "telegram" in name


# ── 터미널 띄우기 ─────────────────────────────────────────────────────
def _prompt() -> str:
    # 세미콜론·작은따옴표는 쓰지 않는다 — 윈도우 터미널·파워셸이 명령을 쪼갠다
    return (f"아침 브리핑 — {OUT} 파일을 읽고, 거기 적힌 오늘 일정과 날씨로 짧게 브리핑해 줘. "
            "일정마다 미리 챙길 게 있으면 한 줄씩 덧붙여. 숫자는 파일에 있는 것만 써.")


def launch() -> bool:
    try:
        import brain
        claude = brain.claude_exe(_cfg())
    except Exception:                           # noqa: BLE001
        claude = "claude"
    home = str(HOME_DIR)
    p = _prompt()
    if os.name == "nt":
        ps = f"& '{claude}' '{p}'" if claude != "claude" else f"claude '{p}'"
        cmds = []
        la = os.environ.get("LOCALAPPDATA", "")
        wt = Path(la) / "Microsoft" / "WindowsApps" / "wt.exe"
        if wt.exists():
            cmds.append([str(wt), "-d", home, "powershell", "-NoLogo", "-NoExit", "-Command", ps])
        cmds.append(["powershell", "-NoLogo", "-NoExit", "-Command", f"Set-Location -LiteralPath '{home}'\n{ps}"])
        for c in cmds:
            try:
                subprocess.Popen(c, cwd=home, creationflags=getattr(subprocess, "CREATE_NEW_CONSOLE", 0))
                _log(f"터미널 띄움 — {Path(c[0]).name}")
                return True
            except OSError as e:
                _log(f"터미널 못 띄움({Path(c[0]).name}) — {e}")
        return False
    if sys.platform == "darwin":
        sh = f"cd '{home}' && '{claude}' '{p}'"
        for c in ([["open", "-na", "Ghostty", "--args", "-e", "zsh", "-lic", sh]]
                  if Path("/Applications/Ghostty.app").exists() else []) + \
                 [["osascript", "-e", f'tell application "Terminal" to do script "{sh}"',
                   "-e", 'tell application "Terminal" to activate']]:
            try:
                if subprocess.run(c, timeout=20).returncode == 0:
                    _log(f"터미널 띄움 — {c[0]}")
                    return True
            except Exception as e:              # noqa: BLE001
                _log(f"터미널 못 띄움 — {e}")
    return False


# ── 지켜보기 ──────────────────────────────────────────────────────────
def _done_today() -> bool:
    try:
        return STAMP.read_text(encoding="utf-8").strip() == datetime.now(KST).strftime("%Y-%m-%d")
    except OSError:
        return False


def _mark() -> None:
    try:
        STAMP.parent.mkdir(parents=True, exist_ok=True)
        STAMP.write_text(datetime.now(KST).strftime("%Y-%m-%d"), encoding="utf-8")
    except OSError:
        pass


def _watch() -> None:
    _log("아침 브리핑 감시 시작")
    while True:
        try:
            now = datetime.now(KST)
            if (WINDOW[0] <= now.hour < WINDOW[1] and _cfg().get("morning_brief", True)
                    and not _done_today() and _is_telegram(front_app())):
                _mark()                         # 먼저 찍는다 — 실패해도 하루에 여러 번 띄우지 않게
                _log("텔레그램이 앞에 옴 — 브리핑 준비")
                brief()
                launch()
        except Exception as e:                  # noqa: BLE001
            _log(f"감시 오류 — {type(e).__name__}: {e}")
        time.sleep(5)


_started = False


def start() -> None:
    """listen 이 부른다. 한 번만 뜬다."""
    global _started
    if _started or not (os.name == "nt" or sys.platform == "darwin"):
        return
    _started = True
    threading.Thread(target=_watch, daemon=True, name="morning").start()


if __name__ == "__main__":
    if sys.argv[1:] == ["--brief"]:
        print(brief())
    elif sys.argv[1:] == ["--launch"]:
        brief()
        print("띄움" if launch() else "못 띄움")
    elif sys.argv[1:] == ["--front"]:
        print(front_app())
    else:
        print(__doc__)
