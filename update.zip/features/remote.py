# -*- coding: utf-8 -*-
"""원격으로 대신 해주기 — 사명자 대신 클로드가 그 사람 브라우저를 움직인다.

왜 만들었나:
  업무 레이더 화면을 쓰려면 파이어베이스를 만들어야 하는데, 구글 로그인 →
  프로젝트 만들기 → Firestore 만들기 → 앱 등록 → 설정 코드 복사 다섯 단계다.
  **초심자에게는 사실상 불가능하다.** 여기서 다 포기했다.

  그래서 사람은 **구글 로그인만** 해두고, 나머지는 그 PC 의 클로드 코드가
  크롬을 직접 움직여서 한다. 남의 계정을 우리가 만지는 게 아니라,
  **그 사람 컴퓨터에서 그 사람 계정으로** 도는 것이다.

되는 조건 세 가지 — 하나라도 없으면 그렇다고 말한다(조용히 실패하지 않는다):
  · 클로드 코드가 깔려 있고 로그인돼 있을 것
  · 크롬에 클로드 확장(Claude in Chrome)이 깔려 연결돼 있을 것
  · 그 크롬에 구글 계정이 로그인돼 있을 것
"""
from __future__ import annotations

import json
import os
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
import brain                                                 # noqa: E402
from brain import HOME_DIR                                   # noqa: E402

STORE = "https://chromewebstore.google.com/search/claude"     # 확장 받는 곳
_LAST_ERR = ""                                                # 마지막으로 알아낸 진짜 이유


def _chrome_running() -> str:
    """크롬(또는 엣지·브레이브)이 켜져 있나. 켜져 있는 이름을 돌려준다.

    안 켜져 있으면 확장이 붙을 데가 없다 — 그런데 그냥 시키면 클로드가
    몇 분을 헤매다 '연결 안 됨'만 뱉는다. 먼저 보고 바로 알려 주는 게 낫다.
    """
    names = {"chrome.exe": "크롬", "msedge.exe": "엣지", "brave.exe": "브레이브"} \
        if os.name == "nt" else \
        {"Google Chrome": "크롬", "Microsoft Edge": "엣지", "Brave Browser": "브레이브"}
    try:
        if os.name == "nt":
            out = subprocess.run(["tasklist"], capture_output=True, text=True,
                                 encoding="utf-8", errors="replace", timeout=20).stdout.lower()
            for exe, ko in names.items():
                if exe in out:
                    return ko
        else:
            for exe, ko in names.items():
                if subprocess.run(["pgrep", "-x", exe],
                                  capture_output=True, timeout=20).returncode == 0:
                    return ko
    except (OSError, subprocess.SubprocessError):
        return "확인못함"                                    # 못 보면 그냥 해 본다
    return ""


def ask_chrome(cfg: dict, prompt: str, timeout: int = 900) -> str | None:
    """크롬을 쓸 수 있는 상태로 클로드를 부른다.

    **`--chrome` 을 붙여야 크롬 도구가 붙는다.** 이걸 안 붙이면 확장이
    멀쩡히 깔려 있어도 도구 자체가 없어서 "확장 연결 안 됨" 이 뜬다 —
    사명자가 여기서 막혔다(2026-09-04, 맥에서 두 경우 다 돌려 확인).
        claude -p            → 크롬:안됨
        claude -p --chrome   → 크롬:됨

    brain.ask 를 안 쓰고 여기서 따로 부르는 이유: brain 은 구운 실행파일
    안에 있어 새로 굽지 않으면 못 고친다. 이 파일은 저절로 내려간다.
    """
    global _LAST_ERR
    _LAST_ERR = ""
    exe = brain.claude_exe(cfg)
    mine = brain.my_rules()
    if mine:
        prompt = f"[내 규칙 — 이걸 먼저 따른다]\n{mine}\n\n---\n\n{prompt}"
    cmd = [exe, "-p", "--chrome", "--permission-mode", "bypassPermissions"]
    try:
        # 프롬프트는 stdin 으로 — 윈도우 명령줄은 32,767자가 끝이다
        r = subprocess.run(cmd, cwd=str(HOME_DIR), input=prompt,
                           capture_output=True, encoding="utf-8", errors="replace",
                           timeout=timeout, env=brain.clean_env())
    except subprocess.TimeoutExpired:
        print(f"[remote] 시간 초과({timeout}초)", file=sys.stderr)
        return None
    except (OSError, ValueError) as e:
        print(f"[remote] 실행 실패 — {type(e).__name__}: {e} (CLAUDE_BIN={exe})",
              file=sys.stderr)
        return None
    err = (r.stderr or "").strip()
    if r.returncode != 0:
        print(f"[remote] rc={r.returncode} {err[:300]}", file=sys.stderr)
        # 옛 클로드 코드는 --chrome 을 모른다. 그냥 두면 '확장 문제'로 오해한다.
        if "chrome" in err.lower() and ("unknown" in err.lower() or "option" in err.lower()
                                        or "인식" in err):
            _LAST_ERR = ("클로드 코드가 오래된 것입니다 — 크롬 연결을 아직 모릅니다. "
                         "검은 창에서 `claude update` 를 한 번 돌리신 뒤 다시 눌러 주십시오.")
            return None
    return r.stdout


def chrome_ready(cfg: dict | None = None) -> dict:
    """크롬을 움직일 수 있는 상태인가. 실제로 시켜 보고 판단한다."""
    cfg = cfg or {}
    run = _chrome_running()
    if run == "":
        return {"ok": False,
                "error": "크롬이 꺼져 있습니다. 크롬을 켜 두고 다시 눌러 주십시오.",
                "store": STORE}

    ask = ("크롬 브라우저를 조작할 수 있는 도구가 지금 너에게 있는지 확인해라.\n"
           "탭 목록을 실제로 한 번 읽어 보고 답해라. 추측하지 마라.\n"
           "쓸 수 있으면 첫 줄에 '크롬:됨' 이라고만 써라.\n"
           "못 쓰면 첫 줄에 '크롬:안됨' 이라고 쓰고 둘째 줄에 이유를 한 줄로 써라.")
    out = ask_chrome(cfg, ask, timeout=300)
    if not out:
        return {"ok": False,
                "error": _LAST_ERR or "클로드 코드가 답하지 않습니다. 1번 칸에서 먼저 확인해 주십시오."}
    head = out.strip().splitlines()[0]
    if "됨" in head and "안됨" not in head:
        return {"ok": True, "browser": run}
    return {"ok": False,
            "error": f"{run if run != '확인못함' else '크롬'}은 켜져 있는데 확장이 안 붙습니다. "
                     "크롬을 완전히 껐다 켜 주십시오(확장이 잠들면 그렇습니다). "
                     "그래도 안 되면 확장이 클로드 코드와 같은 계정으로 로그인돼 있는지 봐 주십시오.",
            "detail": out.strip()[:300], "store": STORE}


# 사람 손으로 하던 다섯 단계를, 그 PC 의 클로드에게 그대로 시킨다.
FIREBASE = """크롬을 직접 움직여서 이 사람의 **구글 계정으로** 파이어베이스를 만들어 주십시오.
이 사람은 개발자가 아닙니다. 사람에게 무엇을 시키지 말고 네가 다 하십시오.

순서:
1. 새 탭에서 파이어베이스 콘솔(console.firebase.google.com)을 연다.
   구글 로그인이 안 돼 있으면 거기서 멈추고 '로그인이 필요합니다' 라고만 답한다.
   **비밀번호를 대신 입력하지 마라.** 로그인은 사람이 해야 한다.
2. 프로젝트를 새로 만든다. 이름은 adele-{이름} 으로 하되 이미 있으면 뒤에 숫자를 붙인다.
   애널리틱스(Google Analytics)는 끈다.
3. 왼쪽에서 빌드 → Firestore Database → 데이터베이스 만들기 → **테스트 모드**로 시작한다.
   위치는 기본값(또는 asia-northeast3)으로 둔다.
4. 프로젝트 홈에서 웹앱(</>) 을 등록한다. 별명은 adele 로 한다. 호스팅은 켜지 않는다.
5. 나오는 firebaseConfig 값을 읽는다.

다 됐으면 **마지막 줄에 아래 한 줄만** 이 모양 그대로 출력해라. 다른 말은 그 위에 써라.

RESULT {{"apiKey":"...","authDomain":"...","projectId":"...","storageBucket":"...","messagingSenderId":"...","appId":"..."}}

중간에 막히면 RESULT 를 쓰지 말고, 어느 단계에서 무엇 때문에 막혔는지 한국어로 한 줄 써라.
지어내지 마라 — 화면에서 실제로 읽은 값만 쓴다."""


def _grab(out: str) -> dict | None:
    """답에서 RESULT 한 줄만 뽑는다."""
    m = re.search(r"RESULT\s*(\{.*\})", out or "", re.S)
    if not m:
        return None
    try:
        d = json.loads(m.group(1))
    except ValueError:
        return None
    return d if d.get("apiKey") and d.get("projectId") else None


def make_firebase(cfg: dict | None = None, name: str = "") -> dict:
    """파이어베이스를 대신 만들고, 받은 값을 설정에 적어 준다.

    2026-09-21 부터 막아 두었다. '테스트 모드' 저장소는 주소만 알면 누구나 읽고 써서
    교회 방 요약이 공개된다(정통부 보안지침 C3). 로그인을 붙여 다시 열기 전까지는 안 만든다.
    """
    return {"ok": False, "error": "보안 규정 때문에 막아 두었습니다 — 업무 레이더 화면은 "
                                  "이 컴퓨터 안에서만 볼 수 있습니다. 나머지 기능은 그대로 됩니다."}
    cfg = cfg or {}
    ready = chrome_ready(cfg)
    if not ready["ok"]:
        return ready

    out = ask_chrome(cfg, FIREBASE.replace("{이름}", (name or "user").strip() or "user"))
    if not out:
        return {"ok": False, "error": _LAST_ERR or "클로드 코드가 답하지 않습니다."}

    got = _grab(out)
    if not got:
        tail = out.strip().splitlines()
        why = tail[-1][:200] if tail else ""
        return {"ok": False, "error": "끝까지 못 갔습니다.", "detail": why}

    f = HOME_DIR / "config.json"
    try:
        c = json.loads(f.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        c = {}
    c.update({"fb_api_key": got["apiKey"],
              "fb_project": got["projectId"],
              "fb_auth_domain": got.get("authDomain", ""),
              "fb_bucket": got.get("storageBucket", ""),
              "fb_sender": got.get("messagingSenderId", ""),
              "fb_app_id": got.get("appId", "")})
    try:
        f.write_text(json.dumps(c, ensure_ascii=False, indent=2), encoding="utf-8")
    except OSError as e:
        return {"ok": False, "error": f"설정을 저장하지 못했습니다 — {e}"}
    return {"ok": True, "project": got["projectId"]}
