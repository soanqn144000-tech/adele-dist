# -*- coding: utf-8 -*-
"""차트 — 숫자를 교회 색으로 그린다.

넉 장만 만든다. 이것으로 웬만한 보고는 된다.
  · 막대   무엇이 큰가
  · 꺾은선  어떻게 움직였나
  · 비교   두 시점 사이 늘었나 줄었나
  · 도넛   무엇이 몇 %인가

**없는 숫자를 그리지 않는다.** 점이 모자라면 안 그리고 그렇다고 말한다.
말 속에서 숫자를 주워 그리다 사고가 난 적이 있다(2026-08-22).
"""
from __future__ import annotations

import json
import re
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from brain import HOME_DIR                            # 내 것은 사용자 폴더에 둔다

_v = ROOT / "vendor"
if _v.exists() and str(_v) not in sys.path:
    sys.path.insert(0, str(_v))

KST = timezone(timedelta(hours=9))
OUT = HOME_DIR / "data" / "charts"

# 교회 색 — knowledge/05-ppt-chart-rules 와 같은 값
BG, GREEN, GOLD = "#0e2a20", "#01934E", "#d8b15e"
CORAL, TEAL, RED = "#FD8A69", "#2E7D74", "#D6372B"
CREAM, GRAY, GRID = "#F3F8F4", "#9db3a6", "#1e4034"
CYCLE = [GREEN, GOLD, CORAL, TEAL, "#7ecb9a", "#e7c65a"]


def _plt():
    """matplotlib 준비. 한글 폰트를 못 잡으면 네모로 나오므로 찾아서 물린다."""
    import matplotlib
    matplotlib.use("Agg")                                    # 창 없는 환경에서도 그려야 한다
    import matplotlib.pyplot as plt
    from matplotlib import font_manager as fm

    want = ("Noto Sans CJK JP", "AppleGothic", "Apple SD Gothic Neo",
            "Malgun Gothic", "NanumGothic", "Noto Sans KR")
    have = {f.name for f in fm.fontManager.ttflist}
    for w in want:
        if w in have:
            plt.rcParams["font.family"] = w
            break
    plt.rcParams["axes.unicode_minus"] = False               # 음수 부호가 네모로 안 나오게
    return plt


def _fig(plt, w=11, h=6):
    fig, ax = plt.subplots(figsize=(w, h), dpi=150)
    fig.patch.set_facecolor(BG)
    ax.set_facecolor(BG)
    for sp in ax.spines.values():
        sp.set_color(GRID)
    ax.tick_params(colors=GRAY, labelsize=12)
    ax.grid(True, axis="y", color=GRID, alpha=0.55)
    return fig, ax


def _save(plt, fig, name: str) -> str:
    OUT.mkdir(parents=True, exist_ok=True)
    p = OUT / f"{name}_{datetime.now(KST):%Y%m%d_%H%M%S}.png"
    fig.savefig(p, facecolor=BG, bbox_inches="tight", pad_inches=0.35)
    plt.close(fig)
    return str(p)


def _fmt(v: float, unit: str = "") -> str:
    s = f"{v:,.0f}" if abs(v - round(v)) < 0.05 else f"{v:,.1f}"
    return s + unit


# ── 넉 장 ─────────────────────────────────────────────────────────────
def bar(labels: list, values: list, title: str = "", unit: str = "") -> str | None:
    if len(values) < 2:
        return None
    plt = _plt()
    fig, ax = _fig(plt, max(8, len(labels) * 1.5), 6)
    b = ax.bar(labels, values, color=[CYCLE[i % len(CYCLE)] for i in range(len(values))],
               edgecolor=BG, linewidth=1.2)
    for r, v in zip(b, values):
        ax.annotate(_fmt(v, unit), (r.get_x() + r.get_width() / 2, v),
                    textcoords="offset points", xytext=(0, 7), ha="center",
                    fontsize=13, fontweight="bold", color=CREAM)
    ax.set_ylim(0, max(values) * 1.18)
    ax.set_xticks(range(len(labels)))
    ax.set_xticklabels(labels, color=CREAM, fontsize=13)
    if title:
        ax.set_title(title, color=GOLD, fontsize=20, fontweight="bold", pad=16)
    return _save(plt, fig, "bar")


def line(labels: list, values: list, title: str = "", unit: str = "") -> str | None:
    """점 셋은 있어야 '추이' 다. 둘로 그린 선은 착시다."""
    if len(values) < 3:
        return None
    plt = _plt()
    fig, ax = _fig(plt, max(9, len(labels) * 1.1), 6)
    x = range(len(values))
    ax.plot(x, values, color=GREEN, linewidth=3, marker="o", markersize=9,
            markerfacecolor=BG, markeredgewidth=2.4, markeredgecolor=GREEN, zorder=5)
    for i, v in zip(x, values):
        if i % max(1, len(values) // 8) and i != len(values) - 1:
            continue                                         # 촘촘하면 걸러 — 끝점은 항상
        ax.annotate(_fmt(v, unit), (i, v), textcoords="offset points", xytext=(0, 12),
                    ha="center", fontsize=13, fontweight="bold", color=GOLD)
    lo, hi = min(values), max(values)
    pad = max((hi - lo) * 0.28, abs(hi) * 0.05, 1)
    ax.set_ylim(lo - pad, hi + pad)
    ax.set_xticks(list(x))
    ax.set_xticklabels(labels, color=CREAM, fontsize=12)
    if title:
        ax.set_title(title, color=GOLD, fontsize=20, fontweight="bold", pad=16)
    return _save(plt, fig, "line")


def compare(labels: list, before: list, after: list, title: str = "",
            names=("전", "후"), unit: str = "") -> str | None:
    """두 시점 비교 — 늘면 초록, 줄면 빨강으로 증감을 적는다."""
    if len(before) != len(after) or not before:
        return None
    if isinstance(names, str) or len(names) < 2:             # 문자열로 오면 글자가 하나씩 잘린다
        names = ("전", "후")
    import numpy as np
    plt = _plt()
    fig, ax = _fig(plt, max(9, len(labels) * 1.8), 6)
    x = np.arange(len(labels))
    ax.bar(x - 0.2, before, 0.4, label=names[0], color=TEAL, edgecolor=BG)
    ax.bar(x + 0.2, after, 0.4, label=names[1], color=GOLD, edgecolor=BG)
    for i, (b, a) in enumerate(zip(before, after)):
        d = a - b
        ax.annotate(("▲" if d > 0 else ("▼" if d < 0 else "-")) + _fmt(abs(d), unit),
                    (i, max(b, a)), textcoords="offset points", xytext=(0, 9),
                    ha="center", fontsize=12, fontweight="bold",
                    color=("#7ecb9a" if d > 0 else (CORAL if d < 0 else GRAY)))
    ax.set_ylim(0, max(max(before), max(after)) * 1.2)
    ax.set_xticks(x)
    ax.set_xticklabels(labels, color=CREAM, fontsize=13)
    lg = ax.legend(facecolor=BG, edgecolor=GRID, labelcolor=CREAM, fontsize=12)
    lg.get_frame().set_alpha(0.9)
    if title:
        ax.set_title(title, color=GOLD, fontsize=20, fontweight="bold", pad=16)
    return _save(plt, fig, "compare")


def donut(labels: list, values: list, title: str = "") -> str | None:
    if len(values) < 2 or sum(values) <= 0:
        return None
    plt = _plt()
    fig, ax = plt.subplots(figsize=(8.5, 6.5), dpi=150)
    fig.patch.set_facecolor(BG)
    total = sum(values)
    w, t, at = ax.pie(values, labels=labels, autopct=lambda p: f"{p:.0f}%",
                      startangle=90, counterclock=False, pctdistance=0.78,
                      colors=[CYCLE[i % len(CYCLE)] for i in range(len(values))],
                      wedgeprops={"width": 0.42, "edgecolor": BG, "linewidth": 2})
    for x in t:
        x.set_color(CREAM)
        x.set_fontsize(13)
    for x in at:
        x.set_color(BG)
        x.set_fontweight("bold")
        x.set_fontsize(12)
    ax.text(0, 0, _fmt(total), ha="center", va="center", color=GOLD,
            fontsize=26, fontweight="bold")
    if title:
        ax.set_title(title, color=GOLD, fontsize=20, fontweight="bold", pad=16)
    return _save(plt, fig, "donut")


# ── 말로 그리기 ───────────────────────────────────────────────────────
PROMPT = """아래 말에서 차트 한 장을 뽑아 JSON 으로만 답해라. 설명 없이 JSON 만.

{{"kind":"bar", "title":"부서별 출석", "unit":"명",
  "labels":["자문회","장년회"], "values":[597,484]}}

kind 는 넷 중 하나다:
  bar     무엇이 큰가 (막대)
  line    어떻게 움직였나 (꺾은선) — 점이 3개 이상일 때만
  compare 두 시점 비교 — 이때는 values 말고 before, after 두 줄을 준다
  donut   무엇이 몇 % 인가

지킬 것:
- **말에 있는 숫자만 써라.** 하나라도 지어내면 안 된다.
- 숫자가 모자라거나 뭘 그릴지 모르겠으면 {{"kind":null}} 로 답해라.
- labels 와 values 개수는 반드시 같아야 한다.
- unit 은 "명" "%" 처럼 말에 나온 것만. 없으면 "".

말: {text}"""


def _in_text(vals: list, text: str) -> bool:
    """이 숫자들이 정말 그 말 안에 있었나.

    프롬프트로 '지어내지 마라' 고 못박아도 모델은 앞서 본 숫자를 끌어다 쓴다
    (2026-08-28 실측: 숫자를 하나도 안 줬는데 597·484 를 그렸다).
    그래서 그린 뒤가 아니라 그리기 전에 원문과 대조한다.
    """
    nums = set(re.findall(r"\d+(?:\.\d+)?", text.replace(",", "")))
    if not nums:
        return False
    for v in vals:
        a = f"{float(v):.10g}"                               # 597.0 → 597
        if a not in nums and a.rstrip("0").rstrip(".") not in nums:
            return False
    return True


def from_text(text: str) -> tuple[str | None, str]:
    """말 → 차트. (파일경로, 사람에게 할 말)"""
    import brain
    got = brain.ask(_cfg(), PROMPT.format(text=text))
    if not got:
        return None, "지금은 생각하는 쪽이 답하지 않습니다."
    m = re.search(r"\{.*\}", got, re.S)
    if not m:
        return None, "무엇을 그릴지 못 읽었습니다."
    try:
        d = json.loads(m.group(0))
    except ValueError:
        return None, "무엇을 그릴지 못 읽었습니다."

    kind = d.get("kind")
    if not kind:
        return None, "그릴 숫자가 모자랍니다. 항목과 숫자를 같이 알려 주십시오."

    # 말에 없던 숫자는 그리지 않는다 — 여기가 마지막 방어선이다
    got = list(d.get("values") or []) + list(d.get("before") or []) + list(d.get("after") or [])
    try:
        got = [float(x) for x in got]
    except (TypeError, ValueError):
        return None, "숫자를 못 읽었습니다."
    if not _in_text(got, text):
        return None, ("말씀에 없는 숫자라 그리지 않았습니다.\n"
                      "항목과 숫자를 같이 적어 주십시오 — 예: 자문회 597 장년회 484 막대로")
    labels = d.get("labels") or []
    title, unit = d.get("title") or "", d.get("unit") or ""

    try:
        if kind == "compare":
            b, a = d.get("before") or [], d.get("after") or []
            if not (len(labels) == len(b) == len(a) and b):
                return None, "비교하려면 항목마다 두 숫자가 다 있어야 합니다."
            p = compare(labels, b, a, title, unit=unit)
        else:
            vals = d.get("values") or []
            if len(labels) != len(vals) or not vals:
                return None, "항목 수와 숫자 수가 안 맞습니다."
            p = {"bar": bar, "line": line, "donut": donut}.get(kind, bar)(
                labels, vals, title, **({} if kind == "donut" else {"unit": unit}))
    except Exception as e:                                   # noqa: BLE001
        return None, f"그리지 못했습니다 — {type(e).__name__}"

    if not p:
        return None, ("숫자가 모자랍니다 — 꺾은선은 3개 이상, 막대는 2개 이상 필요합니다."
                      if kind in ("line", "bar") else "그릴 수 없습니다.")
    return p, title or "차트"


def _cfg() -> dict:
    try:
        return json.loads((HOME_DIR / "config.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def main_argv(argv: list | None = None) -> int:
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("text", nargs="*", help="그릴 내용을 말로")
    a = ap.parse_args(argv)
    if not a.text:
        print("예: 자문회 597 장년회 484 부녀회 1204 청년회 832 막대로 그려줘")
        return 1
    p, msg = from_text(" ".join(a.text))
    print(msg + (f"\n{p}" if p else ""))
    return 0 if p else 1


if __name__ == "__main__":
    raise SystemExit(main_argv())
