# -*- coding: utf-8 -*-
"""일정 — 캘린더를 읽고 넣는다. 아이클라우드와 구글 둘 다.

  · 오늘·이번주 일정 보기
  · 말로 넣기 — "9월 3일 오후 2시 중진회의 회의실에서"

둘 다 CalDAV 라는 같은 통로를 쓴다. 주소와 로그인만 다르다.

  아이폰   아이클라우드 — 애플 ID + 앱 전용 암호
  갤럭시   구글        — 지메일 + 앱 비밀번호

삼성 클라우드 캘린더는 못 붙는다(삼성이 통로를 안 열어놨다).
다만 갤럭시 기본 캘린더 앱은 구글 계정 캘린더를 같이 보여주므로,
폰에 구글 계정이 붙어 있으면 대개 구글 쪽으로 된다.

**둘 다 앱 전용 암호가 필요하다. 계정 비밀번호로는 안 된다** —
여기서 제일 많이 막히므로 설치 화면에 받는 방법을 적어 뒀다.

날짜·시각을 뽑는 건 클로드가 하고, **계산은 여기서 한다.**
모델에게 '다음주 화요일이 며칠이냐' 를 시키면 자주 틀린다.
"""
from __future__ import annotations

import json
import re
import sys
from datetime import date, datetime, time, timedelta, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
_v = ROOT / "vendor"
if _v.exists() and str(_v) not in sys.path:
    sys.path.insert(0, str(_v))

import brain
from brain import HOME_DIR                                                 # noqa: E402

KST = timezone(timedelta(hours=9))
SERVERS = {"icloud": "https://caldav.icloud.com",
           "google": "https://apidata.googleusercontent.com/caldav/v2/"}
WEEK = "월화수목금토일"


def _cfg() -> dict:
    try:
        return json.loads((HOME_DIR / "config.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def which() -> str:
    """무엇을 쓰나 — icloud / google / 빈 값(안 씀).

    옛 설정(icloud_id 만 있던 때)도 그대로 읽는다.
    """
    c = _cfg()
    k = (c.get("cal_kind") or "").strip().lower()
    if k in SERVERS:
        return k
    return "icloud" if c.get("icloud_id") else ""


def _login() -> tuple[str, str, str]:
    """(주소, 아이디, 비밀번호)"""
    c, k = _cfg(), which()
    if k == "google":
        return SERVERS["google"], c.get("cal_id", ""), c.get("cal_pw", "")
    return (SERVERS["icloud"],
            c.get("cal_id") or c.get("icloud_id", ""),
            c.get("cal_pw") or c.get("icloud_pw", ""))


def ready() -> tuple[bool, str]:
    k = which()
    if not k:
        return False, "캘린더가 연결 안 돼 있습니다 — 설치 화면에서 넣어 주십시오."
    _, uid, pw = _login()
    if not (uid and pw):
        return False, "캘린더 로그인 정보가 비어 있습니다 — 설치 화면에서 넣어 주십시오."
    try:
        import caldav                                        # noqa: F401
    except ImportError:
        return False, "caldav 가 없습니다 — 프로그램을 다시 받아 주십시오."
    return True, ""


# ── 접속 ──────────────────────────────────────────────────────────────
_client = None


def _cal():
    """쓸 달력 하나. 설정에 이름이 있으면 그것, 없으면 기본 달력."""
    global _client
    import caldav
    c = _cfg()
    if _client is None:
        url, uid, pw = _login()
        _client = caldav.DAVClient(url=url, username=uid, password=pw)
    cals = _client.principal().calendars()
    if not cals:
        raise RuntimeError("달력을 하나도 못 찾았습니다.")
    want = (c.get("cal_name") or c.get("icloud_calendar") or "").strip()
    if want:
        for cal in cals:
            if want in str(cal.name or ""):
                return cal
    return cals[0]


def calendars(kind: str = "", uid: str = "", pw: str = "") -> list:
    """달력 이름 목록 — 설치 화면에서 고르게. 아직 저장 전이라 값을 직접 받는다."""
    import caldav
    if kind:
        url = SERVERS.get(kind, SERVERS["icloud"])
    else:
        url, uid, pw = _login()
    cl = caldav.DAVClient(url=url, username=uid, password=pw)
    return [str(x.name or "(이름없음)") for x in cl.principal().calendars()]


def check(kind: str, uid: str, pw: str) -> dict:
    """넣자마자 진짜 되는지 확인해 준다 — 나중에 '왜 안 되지' 가 안 생기게."""
    if not (uid and pw):
        return {"ok": False, "error": "아이디와 앱 비밀번호를 넣어 주십시오."}
    try:
        names = calendars(kind, uid, pw)
    except Exception as e:                                   # noqa: BLE001
        why = str(e)
        if "401" in why or "Unauthorized" in why:
            return {"ok": False, "error": ("로그인이 안 됩니다 — **앱 전용 암호**가 맞는지 "
                                           "봐 주십시오. 계정 비밀번호로는 안 됩니다.")}
        return {"ok": False, "error": f"연결 실패 — {type(e).__name__}"}
    if not names:
        return {"ok": False, "error": "달력을 하나도 못 찾았습니다."}
    return {"ok": True, "calendars": names}


# ── 읽기 ──────────────────────────────────────────────────────────────
def _one(ev) -> dict | None:
    """캘린더 한 건을 우리 모양으로. 못 읽으면 버린다(지어내지 않는다)."""
    try:
        v = ev.icalendar_component
        s, e = v.get("dtstart"), v.get("dtend")
        s = s.dt if s else None
        if s is None:
            return None
        allday = not isinstance(s, datetime)
        if allday:
            start = datetime.combine(s, time(0, 0), tzinfo=KST)
        else:
            start = s.astimezone(KST) if s.tzinfo else s.replace(tzinfo=KST)
        return {"title": str(v.get("summary") or "(제목없음)"),
                "start": start, "allday": allday,
                "place": str(v.get("location") or "") or None,
                "end": (e.dt.astimezone(KST) if e and isinstance(e.dt, datetime)
                        and e.dt.tzinfo else None)}
    except Exception:                                        # noqa: BLE001
        return None


def between(a: date, b: date) -> list:
    """a~b 일정. 시간 순."""
    ok, why = ready()
    if not ok:
        raise RuntimeError(why)
    cal = _cal()
    got = cal.search(start=datetime.combine(a, time(0, 0), tzinfo=KST),
                     end=datetime.combine(b, time(23, 59), tzinfo=KST),
                     event=True, expand=True)
    out = [x for x in (_one(e) for e in got) if x]
    return sorted(out, key=lambda x: x["start"])


def today() -> list:
    d = datetime.now(KST).date()
    return between(d, d)


def this_week() -> list:
    d = datetime.now(KST).date()
    mon = d - timedelta(days=d.weekday())
    return between(mon, mon + timedelta(days=6))


def render(items: list, title: str) -> str:
    """텔레그램으로 보낼 글. 마크다운 표는 안 쓴다(깨진다)."""
    if not items:
        return f"📅 {title}\n\n비어 있습니다."
    lines, day = [f"📅 {title}", ""], None
    for it in items:
        d = it["start"].date()
        if d != day:
            day = d
            lines.append(f"— {d.month}/{d.day}({WEEK[d.weekday()]})")
        when = "종일" if it["allday"] else it["start"].strftime("%H:%M")
        row = f"  · {when}  {it['title']}"
        if it.get("place"):
            row += f"  @{it['place']}"
        lines.append(row)
    return "\n".join(lines)


# ── 말로 넣기 ─────────────────────────────────────────────────────────
PROMPT = """아래 말에서 일정 하나를 뽑아 JSON 으로만 답해라. 설명 없이 JSON 만.

오늘은 {today}({wd}) 이다. 지금은 {now} 이다.

{{"date":"2026-09-03", "time":"14:00", "title":"중진회의", "place":"회의실"}}

지킬 것:
- **말에 없는 것은 넣지 마라.** 없으면 null 이다. 그럴듯하게 지어내면 안 된다.
- time 은 24시간 형식. 시각이 없으면 null (종일 일정이 된다).
- place 는 "~에서" "~에" 로 말한 장소만. 없으면 null.
- title 에는 날짜·시각·장소를 넣지 마라. 무슨 일인지만.
- 상대적인 날("내일", "다음주 화요일")은 오늘을 기준으로 실제 날짜로 바꿔라.

말: {text}"""


def parse(text: str) -> dict | None:
    now = datetime.now(KST)
    got = brain.ask(_cfg(), PROMPT.format(
        today=now.strftime("%Y-%m-%d"), wd=WEEK[now.weekday()],
        now=now.strftime("%H:%M"), text=text))
    if not got:
        return None
    m = re.search(r"\{.*\}", got, re.S)
    if not m:
        return None
    try:
        d = json.loads(m.group(0))
    except ValueError:
        return None
    if not d.get("date") or not d.get("title"):
        return None
    try:                                                     # 날짜 형식은 여기서 검사한다
        datetime.strptime(str(d["date"])[:10], "%Y-%m-%d")
    except ValueError:
        return None
    return d


def add(d: dict) -> tuple[bool, str]:
    """일정을 넣는다. 같은 날 같은 제목이 있으면 안 넣는다(두 번 눌러도 하나)."""
    ok, why = ready()
    if not ok:
        return False, why
    day = datetime.strptime(str(d["date"])[:10], "%Y-%m-%d").date()
    for x in between(day, day):
        if x["title"].strip() == str(d["title"]).strip():
            return False, f"이미 있습니다 — {d['title']}"

    cal = _cal()
    kw = {"summary": str(d["title"])}
    if d.get("place"):
        kw["location"] = str(d["place"])
    if d.get("time"):
        try:
            hh, mm = str(d["time"]).split(":")[:2]
            s = datetime.combine(day, time(int(hh), int(mm)), tzinfo=KST)
            kw["dtstart"], kw["dtend"] = s, s + timedelta(hours=1)
        except ValueError:
            kw["dtstart"], kw["dtend"] = day, day + timedelta(days=1)
    else:
        kw["dtstart"], kw["dtend"] = day, day + timedelta(days=1)
    try:
        cal.save_event(**kw)
    except Exception as e:                                   # noqa: BLE001
        return False, f"넣지 못했습니다 — {type(e).__name__}: {e}"

    when = f"{day.month}/{day.day}({WEEK[day.weekday()]})"
    if d.get("time"):
        when += f" {d['time']}"
    where = f" @{d['place']}" if d.get("place") else ""
    return True, f"📅 넣었습니다 — {when} {d['title']}{where}"


def main_argv(argv: list | None = None) -> int:
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--week", action="store_true", help="이번주")
    ap.add_argument("--add", help="말로 일정 넣기")
    a = ap.parse_args(argv)
    try:
        if a.add:
            d = parse(a.add)
            if not d:
                print("무슨 일정인지 못 읽었습니다. 날짜와 할 일을 같이 말해 주십시오.")
                return 1
            ok, msg = add(d)
            print(msg)
            return 0 if ok else 1
        items = this_week() if a.week else today()
        print(render(items, "이번주 일정" if a.week else "오늘 일정"))
    except Exception as e:                                   # noqa: BLE001
        print(f"{type(e).__name__}: {e}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main_argv())
