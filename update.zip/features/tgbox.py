# -*- coding: utf-8 -*-
"""텔레그램 창고 — 내 텔레그램을 통째로 모아 두고 찾는다. 예약 메시지도 여기서 보낸다.

부장님 아델의 가장 핵심 기능이다(뇌의 telegram_sync · telegram_search · telegram_post).
배포판에는 처음부터 빠져 있었다 — 2026-09-13 에야 알았다. "아델을 복제하는 건데 핵심기능인데."

할 수 있게 되는 것:
  · 띄어쓰기가 달라도 찾는다 — 텔레그램 자체 검색은 '출결보고' 로 '출결 보고' 를 못 찾는다
  · 어느 방에서 말했는지 몰라도 찾는다 — 방·날짜·보낸 사람까지 알려준다
  · 매일 보낼 메시지를 정한 시각에 내 계정으로 보낸다

돌아가는 모양 (listen.py 가 켤 때 start() 를 부른다 — 24시간 떠 있는 쪽에 얹혀 산다):
  ① 모으기  1시간마다, 최근 30일 안에 말이 오간 방을 1년치까지 data/tg_box.db 에 쌓는다.
            처음 한 번만 오래 걸리고, 그다음부터는 새 글만 받는다.
  ② 창구    127.0.0.1:47633 — 클로드가 curl 로 찾고·보내고·예약한다.
            밖에서는 못 들어온다. 열쇠(data/tgbox.key)가 없으면 이 컴퓨터 안에서도 거절한다 —
            아무 웹페이지가 몰래 '보내기' 를 두드리는 것을 막으려는 것이다.
  ③ 예약    30초마다 data/예약메시지.json 을 보고, 때가 된 것을 보낸다.

실행파일을 새로 굽지 않아도 되게 **이 파일 하나에 다 둔다.** 실행파일 안에 이미 있는 것
(telethon · sqlite3 · http.server · asyncio)만 쓴다. 새 라이브러리를 부르면 구운 쪽에서 터진다.

모은 대화는 이 컴퓨터 안(사용자 폴더)에만 있다. 어디에도 올리지 않는다.
"""
from __future__ import annotations

import asyncio
import json
import os
import re
import shutil
import sqlite3
import sys
import threading
import time
import uuid
from datetime import date, datetime, timedelta, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
_v = ROOT / "vendor"
if _v.exists() and str(_v) not in sys.path:
    sys.path.insert(0, str(_v))

from brain import HOME_DIR                                                 # noqa: E402

KST = timezone(timedelta(hours=9))
DATA = HOME_DIR / "data"
DB = DATA / "tg_box.db"
KEY = DATA / "tgbox.key"
PLAN = DATA / "예약메시지.json"
PORT = int(os.environ.get("ADELE_TGBOX_PORT", "47633"))

ACTIVE_DAYS = 30          # 이 안에 말이 오간 방만 모은다
HISTORY_DAYS = 365        # 처음 모을 때 거슬러 올라가는 기간
FIRST_CAP = 20000         # 한 방에서 처음에 받는 최대 건수 — 뉴스 채널 같은 데서 끝없이 받지 않게
EVERY = 3600              # 모으기 간격(초)
GRACE_MIN = 30            # 예약 시각을 이만큼 넘겨서 켜졌으면 늦게라도 보낸다. 더 지나면 안 보내고 알린다

_notify = None            # 주인에게 알리는 길 — listen 이 넣어준다
_loop: asyncio.AbstractEventLoop | None = None
_client = None
_sync_lock = threading.Lock()
_plan_lock = threading.Lock()
_state = {"syncing": False, "done": 0, "total": 0, "last": "", "error": "", "room": ""}


# ── 공통 ──────────────────────────────────────────────────────────────
def _log(msg: str) -> None:
    print(f"[tgbox] {msg}", file=sys.stderr, flush=True)


def _cfg() -> dict:
    try:
        return json.loads((HOME_DIR / "config.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def nosp(s: str) -> str:
    """띄어쓰기·줄바꿈을 다 뺀다. '출결 보고' 와 '출결보고' 를 같게 본다."""
    return re.sub("[\\s\u200b\u200c\u200d\ufeff]+", "", (s or "").lower())


def _db() -> sqlite3.Connection:
    DATA.mkdir(parents=True, exist_ok=True)
    c = sqlite3.connect(str(DB), timeout=30)
    c.execute("PRAGMA journal_mode=WAL")
    c.executescript("""
        CREATE TABLE IF NOT EXISTS rooms (
            id INTEGER PRIMARY KEY, name TEXT, kind TEXT,
            top_id INTEGER DEFAULT 0, last_ts REAL DEFAULT 0, synced TEXT DEFAULT '');
        CREATE TABLE IF NOT EXISTS msg (
            room INTEGER, mid INTEGER, ts REAL, who TEXT, text TEXT, low TEXT, nosp TEXT,
            PRIMARY KEY (room, mid));
        CREATE INDEX IF NOT EXISTS msg_ts ON msg(ts);
    """)
    return c


def _key() -> str:
    """창구 열쇠. 없으면 만든다. 클로드는 이 파일을 읽어 머리에 붙인다."""
    try:
        k = KEY.read_text(encoding="utf-8").strip()
        if k:
            return k
    except OSError:
        pass
    DATA.mkdir(parents=True, exist_ok=True)
    k = uuid.uuid4().hex
    KEY.write_text(k, encoding="utf-8")
    return k


def _day(s: str | None, end: bool = False) -> float | None:
    """'2026-09-01' → 그날 0시(KST)의 타임스탬프. end 면 그날 끝."""
    if not s:
        return None
    try:
        d = datetime.strptime(str(s).strip()[:10], "%Y-%m-%d").replace(tzinfo=KST)
    except ValueError:
        return None
    if end:
        d += timedelta(days=1)
    return d.timestamp()


def _when(ts: float) -> str:
    d = datetime.fromtimestamp(ts, KST)
    return d.strftime("%m/%d %H:%M") if d.year == datetime.now(KST).year else d.strftime("%Y-%m-%d %H:%M")


def _link(room: int, mid: int) -> str:
    """원문 바로가기. 슈퍼그룹·채널만 된다(-100 으로 시작하는 방). 나머지는 빈 값."""
    s = str(room)
    return f"https://t.me/c/{s[4:]}/{mid}" if s.startswith("-100") else ""


# ── 텔레그램 접속 (전용 루프 하나) ─────────────────────────────────────
def _ensure_loop() -> asyncio.AbstractEventLoop:
    global _loop
    if _loop and not _loop.is_closed():
        return _loop
    _loop = asyncio.new_event_loop()
    threading.Thread(target=_loop.run_forever, daemon=True, name="tgbox-loop").start()
    return _loop


def _go(coro, timeout: float = 600):
    return asyncio.run_coroutine_threadsafe(coro, _ensure_loop()).result(timeout=timeout)


def _session() -> str:
    """창고 전용 로그인 파일 — 원본을 복사해 쓴다.

    레이더(하루 세 번)와 같은 파일을 동시에 열면 'database is locked' 가 난다.
    레이더도 같은 까닭으로 복사본을 쓴다(radar._reading_session).
    """
    src = DATA / "telegram_user.session"
    dup = DATA / "telegram_box.session"
    if src.exists() and (not dup.exists() or src.stat().st_mtime > dup.stat().st_mtime):
        try:
            shutil.copyfile(src, dup)
        except OSError as e:
            _log(f"로그인 파일 복사 실패 — {e}")
    return str(dup.with_suffix("")) if dup.exists() else str(src.with_suffix(""))


async def _connect():
    global _client
    if _client is not None:
        try:
            if _client.is_connected():
                return _client
            await _client.connect()
            return _client
        except Exception:                                    # noqa: BLE001
            _client = None
    cfg = _cfg()
    api_id, api_hash = str(cfg.get("tg_api_id") or ""), str(cfg.get("tg_api_hash") or "")
    if not (api_id and api_hash):
        raise RuntimeError("텔레그램 연결이 안 돼 있습니다 — 설치(텔레그램 로그인)를 먼저 마쳐 주십시오.")
    from telethon import TelegramClient
    c = TelegramClient(_session(), int(api_id), api_hash)
    c.flood_sleep_threshold = 120                            # 잠깐 막히면 기다렸다 이어간다
    await c.connect()
    if not await c.is_user_authorized():
        await c.disconnect()
        raise RuntimeError("텔레그램 로그인이 풀려 있습니다 — 설치에서 텔레그램 로그인을 다시 해 주십시오.")
    _client = c
    return c


def my_id() -> str:
    """이 PC 에 로그인한 텔레그램 **본인 계정 번호**. 못 읽으면 빈 값.

    말 걸기(listen)가 주인을 이 번호로만 정한다. 봇은 텔레그램에서 검색되므로
    '먼저 말 거는 사람' 을 믿으면 남이 이 PC 를 부리게 된다(2026-09-21 보안지침).
    """
    async def _me() -> str:
        c = await _connect()
        me = await c.get_me()
        return str(me.id) if me else ""
    try:
        return _go(_me(), timeout=60) or ""
    except Exception as e:                                   # noqa: BLE001
        _log(f"본인 계정 번호를 못 읽음 — {type(e).__name__}")
        return ""


def _who(m) -> str:
    if getattr(m, "out", False):
        return "나"
    s = getattr(m, "sender", None)
    if s is not None:
        if getattr(s, "title", None):
            return s.title
        name = " ".join(x for x in (getattr(s, "last_name", None), getattr(s, "first_name", None)) if x)
        if name:
            return name
        if getattr(s, "username", None):
            return s.username
    return getattr(m, "post_author", None) or str(getattr(m, "sender_id", "") or "")


def _body(m) -> str:
    """본문. 사진·파일은 무엇이 붙었는지 적고, 설명글이 있으면 같이."""
    text = (getattr(m, "message", None) or "").strip()
    if getattr(m, "media", None) is not None:
        tag = "[첨부]"
        if getattr(m, "photo", None) is not None:
            tag = "[사진]"
        else:
            f = getattr(m, "file", None)
            name = getattr(f, "name", None) if f is not None else None
            if name:
                tag = f"[파일 {name}]"
            elif getattr(m, "video", None) is not None:
                tag = "[동영상]"
            elif getattr(m, "voice", None) is not None:
                tag = "[음성]"
        text = f"{tag} {text}".strip()
    return text


# ── ① 모으기 ──────────────────────────────────────────────────────────
async def _sync_async(quick: bool = False) -> str:
    c = await _connect()
    now = datetime.now(timezone.utc)
    active_since = now - timedelta(days=ACTIVE_DAYS)
    hist_since = now - timedelta(days=HISTORY_DAYS)
    db = _db()
    try:
        known = {r[0]: (r[1], r[2]) for r in db.execute("SELECT id, top_id, last_ts FROM rooms")}
        dialogs = []
        async for d in c.iter_dialogs():
            ent = d.entity
            if getattr(ent, "bot", False) or d.id == 777000:  # 봇·텔레그램 공지는 뺀다
                continue
            if not d.date or d.date < active_since:
                continue
            top, last_ts = known.get(d.id, (0, 0))
            if quick and top and d.date.timestamp() <= (last_ts or 0):
                continue                                     # 새 글이 없는 방
            dialogs.append(d)

        _state.update(total=len(dialogs), done=0)
        added = 0
        for d in dialogs:
            kind = "개인" if d.is_user else ("채널" if d.is_channel and not d.is_group else "그룹")
            name = (d.name or "(이름없음)").strip()
            _state["room"] = name
            top = known.get(d.id, (0, 0))[0]
            rows, hi, n = [], top, 0
            try:
                if top:
                    it = c.iter_messages(d.entity, min_id=top)          # 새 글만
                else:
                    it = c.iter_messages(d.entity, limit=FIRST_CAP)    # 처음 — 1년치까지
                async for m in it:
                    if not top and m.date < hist_since:
                        break
                    hi = max(hi, m.id)
                    body = _body(m)
                    if not body:
                        continue
                    rows.append((d.id, m.id, m.date.timestamp(), _who(m), body,
                                 body.lower(), nosp(body)))
                    n += 1
                    if len(rows) >= 500:
                        db.executemany("INSERT OR REPLACE INTO msg VALUES (?,?,?,?,?,?,?)", rows)
                        db.commit()
                        rows = []
            except Exception as e:                           # noqa: BLE001 — 방 하나 실패해도 나머지는 계속
                _log(f"{name} 읽기 실패 — {type(e).__name__}: {e}")
            if rows:
                db.executemany("INSERT OR REPLACE INTO msg VALUES (?,?,?,?,?,?,?)", rows)
            db.execute("INSERT INTO rooms(id, name, kind, top_id, last_ts, synced) VALUES (?,?,?,?,?,?) "
                       "ON CONFLICT(id) DO UPDATE SET name=excluded.name, kind=excluded.kind, "
                       "top_id=MAX(rooms.top_id, excluded.top_id), last_ts=excluded.last_ts, "
                       "synced=excluded.synced",
                       (d.id, name, kind, hi, d.date.timestamp(),
                        datetime.now(KST).isoformat(timespec="seconds")))
            db.commit()
            added += n
            _state["done"] += 1
        return f"{len(dialogs)}개 방에서 새 글 {added:,}건을 모았습니다."
    finally:
        db.close()


def sync(quick: bool = False) -> str:
    """한 번 모은다. 이미 모으는 중이면 기다리지 않고 그렇다고만 한다."""
    if not _sync_lock.acquire(blocking=False):
        return f"이미 모으는 중입니다 ({_state['done']}/{_state['total']}방)."
    _state.update(syncing=True, error="")
    try:
        msg = _go(_sync_async(quick), timeout=6 * 3600)
        _state["last"] = datetime.now(KST).strftime("%m/%d %H:%M")
        return msg
    except Exception as e:                                   # noqa: BLE001
        _state["error"] = str(e)
        return f"모으지 못했습니다 — {e}"
    finally:
        _state.update(syncing=False, room="")
        _sync_lock.release()


def _sync_forever() -> None:
    time.sleep(20)                                           # 켜자마자 몰아치지 않게
    while True:
        r = sync()
        _log(r)
        time.sleep(EVERY)


def status() -> str:
    try:
        db = _db()
        rooms, msgs = db.execute("SELECT (SELECT COUNT(*) FROM rooms), (SELECT COUNT(*) FROM msg)").fetchone()
        old = db.execute("SELECT MIN(ts) FROM msg").fetchone()[0]
        db.close()
    except sqlite3.Error as e:
        return f"창고를 못 열었습니다 — {e}"
    lines = [f"모은 방 {rooms}개 · 메시지 {msgs:,}건"
             + (f" · 가장 오래된 글 {_when(old)}" if old else "")]
    if _state["syncing"]:
        lines.append(f"지금 모으는 중 — {_state['done']}/{_state['total']}방 ({_state['room']})")
    if _state["last"]:
        lines.append(f"마지막으로 다 모은 때 {_state['last']}")
    if _state["error"]:
        lines.append(f"문제: {_state['error']}")
    if not msgs and not _state["syncing"]:
        lines.append("아직 모은 게 없습니다. 처음 모으는 데는 방이 많으면 수십 분 걸립니다.")
    return "\n".join(lines)


# ── 찾기 ──────────────────────────────────────────────────────────────
def search(q: str = "", room: str = "", sender: str = "", since: str = "", until: str = "",
           any_: bool = False, oldest: bool = False, limit: int = 30, full: bool = False) -> str:
    """창고에서 찾는다. 결과는 사람이 읽는 줄글로 돌려준다.

    한 낱말마다 '그대로' 와 '띄어쓰기 뺀 것' 둘 다 대 본다. 그래서 '출결보고' 로 '출결 보고' 가,
    '출결 보고' 로 '출결보고' 가 잡힌다. 여러 낱말이면 기본은 전부 들어간 것(AND), any 면 하나라도.
    """
    terms = [t for t in re.split(r"\s+", (q or "").strip().lower()) if t]
    where, args = [], []
    conds = []
    for t in terms:
        conds.append("(instr(low, ?) > 0 OR instr(nosp, ?) > 0)")
        args += [t, nosp(t)]
    if conds:
        joined = (" OR " if any_ else " AND ").join(conds)
        if len(terms) > 1 and not any_:                      # '출결 보고' 전체를 붙여서도 본다
            joined = f"({joined}) OR instr(nosp, ?) > 0"
            args.append(nosp(q))
        where.append(f"({joined})")
    if room:
        where.append("room IN (SELECT id FROM rooms WHERE instr(lower(name), ?) > 0 "
                     "OR instr(replace(lower(name), ' ', ''), ?) > 0)")
        args += [room.lower(), nosp(room)]
    if sender:
        where.append("(instr(lower(who), ?) > 0 OR instr(replace(lower(who), ' ', ''), ?) > 0)")
        args += [sender.lower(), nosp(sender)]
    a, b = _day(since), _day(until, end=True)
    if a:
        where.append("ts >= ?")
        args.append(a)
    if b:
        where.append("ts < ?")
        args.append(b)
    if not where:
        return "무엇을 찾을지 주십시오 — 낱말(q), 방(room), 기간(since) 중 하나는 있어야 합니다."

    try:
        limit = max(1, min(int(limit or 30), 300))
    except (TypeError, ValueError):
        limit = 30
    sql_where = " AND ".join(where)
    try:
        db = _db()
        total = db.execute(f"SELECT COUNT(*) FROM msg WHERE {sql_where}", args).fetchone()[0]
        rows = db.execute(
            f"SELECT m.room, m.mid, m.ts, m.who, m.text, r.name FROM msg m "
            f"LEFT JOIN rooms r ON r.id = m.room WHERE {sql_where} "
            f"ORDER BY m.ts {'ASC' if oldest else 'DESC'} LIMIT ?", args + [limit]).fetchall()
        empty = db.execute("SELECT COUNT(*) FROM msg").fetchone()[0] == 0
        db.close()
    except sqlite3.Error as e:
        return f"창고를 못 열었습니다 — {e}"

    if empty:
        return "창고가 아직 비어 있습니다. " + (
            f"지금 처음 모으는 중입니다({_state['done']}/{_state['total']}방)." if _state["syncing"]
            else "모으기가 한 번도 안 돌았습니다 — 텔레그램 로그인을 확인해 주십시오.")
    if not rows:
        return (f"못 찾았습니다 — 조건: {q or '(낱말 없음)'}"
                + (f" · 방 '{room}'" if room else "") + (f" · {since}~{until}" if since or until else "")
                + "\n낱말을 줄이거나 바꿔 보십시오.")

    out = [f"{total:,}건 중 {len(rows)}건 ({'오래된' if oldest else '최신'} 순)"]
    for rid, mid, ts, who, text, name in rows:
        body = text if full else _snip(text, terms)
        link = _link(rid, mid)
        out.append(f"[{_when(ts)}] {name or rid} · {who}: {body}" + (f"  {link}" if link else ""))
    if _state["syncing"]:
        out.append(f"(아직 모으는 중이라 빠진 방이 있을 수 있습니다 — {_state['done']}/{_state['total']}방)")
    return "\n".join(out)


def _snip(text: str, terms: list[str], width: int = 160) -> str:
    """찾은 낱말 둘레만 잘라 보여준다. 전부 보려면 full."""
    flat = " ".join((text or "").split())
    if len(flat) <= width:
        return flat
    low = flat.lower()
    at = min([i for i in (low.find(t) for t in terms) if i >= 0] or [0])
    start = max(0, at - width // 3)
    part = flat[start:start + width]
    return ("…" if start else "") + part + ("…" if start + width < len(flat) else "")


def rooms_list(q: str = "") -> str:
    try:
        db = _db()
        rows = db.execute("SELECT name, kind, last_ts, (SELECT COUNT(*) FROM msg WHERE room = rooms.id) "
                          "FROM rooms ORDER BY last_ts DESC").fetchall()
        db.close()
    except sqlite3.Error as e:
        return f"창고를 못 열었습니다 — {e}"
    if q:
        rows = [r for r in rows if nosp(q) in nosp(r[0])]
    if not rows:
        return "해당하는 방이 없습니다."
    return "\n".join(f"{name} · {kind} · 마지막 {_when(ts) if ts else '-'} · {n:,}건"
                     for name, kind, ts, n in rows[:200])


# ── 보내기 ────────────────────────────────────────────────────────────
async def _find_room(c, room: str):
    """방 이름 일부로 찾는다. (찾은 방, 후보들) — 하나로 안 좁혀지면 찾은 방은 None."""
    if nosp(room) in ("나", "me", "저장한메시지", "내게", "나에게"):
        return "me", ["저장한 메시지"]
    want, hits, exact = nosp(room), [], []
    async for d in c.iter_dialogs():
        name = (d.name or "").strip()
        if want and want in nosp(name):
            hits.append(d)
            if nosp(name) == want:
                exact.append(d)
    pick = exact if len(exact) == 1 else hits
    if len(pick) == 1:
        return pick[0], [pick[0].name]
    return None, [h.name for h in hits[:15]]


async def _send_async(room: str, text: str, really: bool) -> str:
    c = await _connect()
    target, names = await _find_room(c, room)
    if target is None:
        if not names:
            return f"'{room}' 이라는 방을 못 찾았습니다. 보내지 않았습니다."
        return (f"'{room}' 에 해당하는 방이 {len(names)}개라 보내지 않았습니다. 어느 방인지 정확히 주십시오:\n"
                + "\n".join(f"· {n}" for n in names))
    label = names[0]
    if not really:
        return f"[미리보기 — 아직 안 보냈습니다]\n받는 방: {label}\n내용:\n{text}"
    ent = target if target == "me" else target.entity
    for i in range(0, len(text), 3900):
        await c.send_message(ent, text[i:i + 3900])
    return f"✅ 「{label}」에 보냈습니다."


def send(room: str, text: str, really: bool = False) -> str:
    """내 계정으로 방에 글을 보낸다. really 가 아니면 미리보기만 — 실수로 나가면 되돌릴 수 없다."""
    if not (room and (text or "").strip()):
        return "방(room)과 내용(text)이 둘 다 있어야 합니다."
    try:
        return _go(_send_async(room, text.strip(), really), timeout=180)
    except Exception as e:                                   # noqa: BLE001
        return f"보내지 못했습니다 — {type(e).__name__}: {e}"


# ── ③ 예약 메시지 ─────────────────────────────────────────────────────
_WD = "월화수목금토일"


def _days_of(repeat: str) -> set[int] | None:
    """'매일' '평일' '주말' '월,수,금' → 요일 번호. '한번' 이면 None."""
    r = nosp(repeat or "매일")
    if r in ("한번", "1회", "once"):
        return None
    if r in ("매일", "daily", ""):
        return set(range(7))
    if r == "평일":
        return {0, 1, 2, 3, 4}
    if r == "주말":
        return {5, 6}
    got = {_WD.index(ch) for ch in r if ch in _WD}
    return got or set(range(7))


def _next_time(item: dict, after: datetime) -> datetime | None:
    """이 예약이 다음에 나갈 때. 날짜 계산은 여기서만 한다 — 클로드에게 안 시킨다."""
    try:
        hh, mm = (int(x) for x in item["time"].split(":"))
    except (KeyError, ValueError):
        return None
    days = _days_of(item.get("repeat", "매일"))
    if days is None:
        try:
            d = datetime.strptime(item.get("date", ""), "%Y-%m-%d").replace(hour=hh, minute=mm, tzinfo=KST)
        except ValueError:
            return None
        return d if d > after and not item.get("last") else None
    for k in range(8):
        d = (after + timedelta(days=k)).replace(hour=hh, minute=mm, second=0, microsecond=0)
        if d.weekday() in days and d > after and item.get("last") != d.strftime("%Y-%m-%d"):
            return d
    return None


def _plans() -> list[dict]:
    try:
        return json.loads(PLAN.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return []


def _save_plans(items: list[dict]) -> None:
    DATA.mkdir(parents=True, exist_ok=True)
    PLAN.write_text(json.dumps(items, ensure_ascii=False, indent=2), encoding="utf-8")


def _describe(it: dict) -> str:
    rep = it.get("repeat", "매일")
    when = f"{it.get('date')} {it['time']}" if _days_of(rep) is None else f"{rep} {it['time']}"
    nxt = _next_time(it, datetime.now(KST))
    tail = f" (다음: {nxt.month}/{nxt.day}({_WD[nxt.weekday()]}) {nxt:%H:%M})" if nxt else " (끝남)"
    text = it["text"].replace("\n", " ")
    return f"[{it['id']}] {when} → 「{it['room_name']}」 {text[:60]}{'…' if len(text) > 60 else ''}{tail}"


def plan_add(room: str, text: str, at: str, repeat: str = "매일", on: str = "") -> str:
    """예약을 건다. 방은 지금 하나로 확정한다 — 보낼 때 가서 헷갈리면 안 된다."""
    if not re.fullmatch(r"\d{1,2}:\d{2}", (at or "").strip()):
        return "시각(time)은 '07:30' 처럼 주십시오."
    hh, mm = (int(x) for x in at.split(":"))
    if hh > 23 or mm > 59:
        return "시각이 이상합니다."
    if _days_of(repeat) is None and not re.fullmatch(r"\d{4}-\d{2}-\d{2}", on or ""):
        return "한 번만 보낼 거면 날짜(date)를 '2026-09-20' 처럼 주십시오."
    if not (text or "").strip():
        return "보낼 내용(text)이 없습니다."

    async def pick():
        c = await _connect()
        return await _find_room(c, room)
    try:
        target, names = _go(pick(), timeout=120)
    except Exception as e:                                   # noqa: BLE001
        return f"방을 확인하지 못했습니다 — {e}"
    if target is None:
        return (f"'{room}' 방을 하나로 못 정했습니다 — 예약하지 않았습니다.\n"
                + "\n".join(f"· {n}" for n in names) if names else f"'{room}' 방을 못 찾았습니다.")
    item = {"id": uuid.uuid4().hex[:6], "room": "me" if target == "me" else target.id,
            "room_name": names[0], "text": text.strip(), "time": f"{hh:02d}:{mm:02d}",
            "repeat": repeat or "매일", "date": on or "", "last": "",
            "made": datetime.now(KST).isoformat(timespec="seconds")}
    with _plan_lock:
        items = _plans()
        items.append(item)
        _save_plans(items)
    return "✅ 예약했습니다.\n" + _describe(item)


def plan_list() -> str:
    items = _plans()
    if not items:
        return "걸어 둔 예약 메시지가 없습니다."
    return "\n".join(_describe(it) for it in items)


def plan_remove(pid: str) -> str:
    with _plan_lock:
        items = _plans()
        keep = [it for it in items if it.get("id") != pid]
        if len(keep) == len(items):
            return f"[{pid}] 예약이 없습니다."
        _save_plans(keep)
    return f"[{pid}] 예약을 지웠습니다."


async def _send_to_id(room, text: str) -> None:
    c = await _connect()
    if room == "me":
        ent = "me"
    else:
        ent = None
        async for d in c.iter_dialogs():
            if d.id == room:
                ent = d.entity
                break
        if ent is None:
            raise RuntimeError("그 방이 더는 목록에 없습니다(나갔거나 없어짐)")
    for i in range(0, len(text), 3900):
        await c.send_message(ent, text[i:i + 3900])


def _due(item: dict, now: datetime) -> datetime | None:
    """지금 나가야 할 예약이면 그 예정 시각을 돌려준다."""
    try:
        hh, mm = (int(x) for x in item["time"].split(":"))
    except (KeyError, ValueError):
        return None
    today = now.strftime("%Y-%m-%d")
    days = _days_of(item.get("repeat", "매일"))
    if days is None:
        if item.get("date") != today or item.get("last"):
            return None
    elif now.weekday() not in days or item.get("last") == today:
        return None
    at = now.replace(hour=hh, minute=mm, second=0, microsecond=0)
    return at if now >= at else None


def tick(now: datetime | None = None) -> list[str]:
    """때가 된 예약을 보낸다. 무엇을 했는지 줄로 돌려준다(주인에게 알릴 말)."""
    now = now or datetime.now(KST)
    said = []
    with _plan_lock:
        items = _plans()
        changed = False
        for it in items:
            at = _due(it, now)
            if not at:
                continue
            it["last"] = now.strftime("%Y-%m-%d")             # 먼저 적는다 — 두 번 나가는 것보다 한 번 빠지는 게 낫다
            changed = True
            late = (now - at).total_seconds() / 60
            if late > GRACE_MIN:
                said.append(f"⚠️ 예약 메시지를 못 보냈습니다 — 「{it['room_name']}」 {it['time']}\n"
                            f"그 시각에 컴퓨터(또는 비서)가 꺼져 있었습니다. 지금이라도 보낼지 말씀해 주십시오.")
                continue
            try:
                _go(_send_to_id(it["room"], it["text"]), timeout=180)
                said.append(f"📨 예약 메시지를 보냈습니다 — 「{it['room_name']}」 {it['time']}")
            except Exception as e:                           # noqa: BLE001
                said.append(f"⚠️ 예약 메시지를 못 보냈습니다 — 「{it['room_name']}」 {it['time']}\n{e}")
        if changed:
            _save_plans(items)
    return said


def _tick_forever() -> None:
    while True:
        try:
            for line in tick():
                _log(line)
                if _notify:
                    _notify(line)
        except Exception as e:                               # noqa: BLE001
            _log(f"예약 확인 실패 — {type(e).__name__}: {e}")
        time.sleep(30)


# ── 새 코드로 갈아타기 ────────────────────────────────────────────────
LISTEN_PORT = int(os.environ.get("ADELE_LISTEN_LOCK_PORT", "47632"))
KICK = DATA / "listen_kick.json"


def _open(port: int) -> bool:
    """창고 창구가 떠 있나. (창고는 두드리면 받아준다 — 말 걸기 자리에는 쓰지 마라)"""
    import socket
    try:
        with socket.create_connection(("127.0.0.1", port), timeout=1):
            return True
    except OSError:
        return False


def _pid_on(port: int) -> int:
    """그 포트를 잡고 있는 프로그램 번호. 못 찾으면 0."""
    import subprocess
    try:
        if sys.platform == "win32":
            out = subprocess.run(["netstat", "-ano", "-p", "TCP"], capture_output=True, text=True,
                                 errors="replace", timeout=20, creationflags=0x08000000).stdout
            for ln in out.splitlines():
                parts = ln.split()
                if len(parts) >= 5 and parts[1] == f"127.0.0.1:{port}" and parts[2].endswith(":0"):
                    return int(parts[-1])
        else:
            out = subprocess.run(["lsof", "-nP", f"-tiTCP:{port}", "-sTCP:LISTEN"],
                                 capture_output=True, text=True, timeout=20).stdout
            return int(out.split()[0]) if out.split() else 0
    except Exception as e:                                   # noqa: BLE001
        _log(f"말 걸기 번호를 못 찾음 — {type(e).__name__}: {e}")
    return 0


def refresh_listen() -> str:
    """말 걸기가 옛 코드로 떠 있으면 끄고 새로 켠다. 레이더가 돌 때 부른다.

    업데이트는 파일만 갈아 준다. 24시간 떠 있는 말 걸기는 컴퓨터를 다시 켜기 전까지
    옛 코드를 붙들고 있어서, 창고가 영영 안 켜진다(2026-09-13 발견).
    말 걸기는 떠 있는데(47632) 창고(47633)가 없으면 = 옛 것이다. 하루 한 번까지만.
    """
    # 말 걸기가 떠 있나는 '살아있음' 시각으로 본다(guard 와 같은 방법).
    # 말 걸기의 자리(47632)는 문을 두드려도 받아주지 않아서, 두드려 보는 식으로는 헛짚는다.
    try:
        beat = datetime.fromisoformat((DATA / "listen_alive.txt").read_text(encoding="utf-8").strip())
        alive = (datetime.now(KST) - beat).total_seconds() < 180
    except (OSError, ValueError):
        alive = False
    if not alive or _open(PORT):                              # 안 떠 있거나, 이미 창고가 있는 새 것
        return ""
    today = datetime.now(KST).strftime("%Y-%m-%d")
    try:
        if json.loads(KICK.read_text(encoding="utf-8")).get("day") == today:
            return ""
    except (OSError, ValueError):
        pass
    DATA.mkdir(parents=True, exist_ok=True)
    KICK.write_text(json.dumps({"day": today}), encoding="utf-8")
    pid = _pid_on(LISTEN_PORT)
    if not pid:
        return "옛 말 걸기를 못 찾았습니다"
    import subprocess
    try:
        if sys.platform == "win32":
            subprocess.run(["taskkill", "/PID", str(pid), "/F"], capture_output=True,
                           timeout=20, creationflags=0x08000000)
        else:
            import signal
            os.kill(pid, signal.SIGTERM)
    except Exception as e:                                   # noqa: BLE001
        return f"옛 말 걸기를 못 껐습니다 — {type(e).__name__}: {e}"
    for _ in range(20):                                      # 완전히 꺼질 때까지
        if _pid_on(LISTEN_PORT) != pid:
            break
        time.sleep(0.5)
    try:
        import guard
        guard._launch()
    except Exception as e:                                   # noqa: BLE001
        return f"끄고 나서 다시 켜지 못했습니다(감시가 곧 켭니다) — {type(e).__name__}: {e}"
    return "말 걸기를 새 코드로 다시 켰습니다"


# ── ② 창구 ────────────────────────────────────────────────────────────
class _Handler(BaseHTTPRequestHandler):
    def log_message(self, *a) -> None:                       # 조용히
        pass

    def _reply(self, text: str, code: int = 200) -> None:
        body = (text or "").encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _args(self) -> dict:
        got = {k: v[-1] for k, v in parse_qs(urlparse(self.path).query).items()}
        n = int(self.headers.get("Content-Length") or 0)
        if n:
            raw = self.rfile.read(n).decode("utf-8", errors="replace").strip()
            if raw:
                try:
                    got.update(json.loads(raw))
                except ValueError:
                    got["_bad"] = raw[:80]
        return got

    def _go(self) -> None:
        if self.headers.get("X-Adele", "") != _key():
            return self._reply("열쇠가 없습니다 — 머리에 X-Adele: $(cat data/tgbox.key) 를 붙이십시오.", 403)
        path = urlparse(self.path).path.rstrip("/")
        a = self._args()
        if "_bad" in a:
            return self._reply(f"JSON 을 못 읽었습니다: {a['_bad']}", 400)
        yes = lambda k: str(a.get(k, "")).lower() in ("1", "true", "yes", "y")   # noqa: E731
        if path == "/tg/search":
            return self._reply(search(a.get("q", ""), a.get("room", ""), a.get("sender", ""),
                                      a.get("since", ""), a.get("until", ""), yes("any"),
                                      yes("oldest"), a.get("limit", 30), yes("full")))
        if path == "/tg/rooms":
            return self._reply(rooms_list(a.get("q", "")))
        if path == "/tg/status":
            return self._reply(status())
        if path == "/tg/sync":
            return self._reply(sync(quick=True))
        if path == "/tg/send":
            return self._reply(send(a.get("room", ""), a.get("text", ""), yes("send")))
        if path == "/tg/plan/add":
            return self._reply(plan_add(a.get("room", ""), a.get("text", ""), a.get("time", ""),
                                        a.get("repeat", "매일"), a.get("date", "")))
        if path == "/tg/plan/list":
            return self._reply(plan_list())
        if path == "/tg/plan/remove":
            return self._reply(plan_remove(str(a.get("id", ""))))
        return self._reply("그런 창구는 없습니다: search · rooms · status · sync · send · plan/add · plan/list · plan/remove", 404)

    def do_GET(self) -> None:
        self._go()

    def do_POST(self) -> None:
        self._go()


def start(notify=None) -> bool:
    """listen 이 켤 때 부른다. 창구·모으기·예약이 뒤에서 돈다. 이미 떠 있으면 아무것도 안 한다."""
    global _notify
    _notify = notify
    _key()
    try:
        srv = ThreadingHTTPServer(("127.0.0.1", PORT), _Handler)
    except OSError as e:
        _log(f"창구를 못 열었습니다(포트 {PORT}) — {e}")
        return False
    threading.Thread(target=srv.serve_forever, daemon=True, name="tgbox-http").start()
    threading.Thread(target=_sync_forever, daemon=True, name="tgbox-sync").start()
    threading.Thread(target=_tick_forever, daemon=True, name="tgbox-plan").start()
    _log(f"텔레그램 창고 켬 — 127.0.0.1:{PORT}")
    return True


if __name__ == "__main__":                                   # 손으로 시험할 때
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument("cmd", choices=["sync", "status", "search", "rooms", "plans"])
    p.add_argument("q", nargs="?", default="")
    p.add_argument("--room", default="")
    p.add_argument("--since", default="")
    ns = p.parse_args()
    if ns.cmd == "sync":
        print(sync())
    elif ns.cmd == "status":
        print(status())
    elif ns.cmd == "search":
        print(search(ns.q, room=ns.room, since=ns.since))
    elif ns.cmd == "rooms":
        print(rooms_list(ns.q))
    else:
        print(plan_list())
