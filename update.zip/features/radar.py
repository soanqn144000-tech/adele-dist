# -*- coding: utf-8 -*-
"""내무부 업무현황 브리핑 — 텔레그램을 훑어 '무슨 일이 어디까지 왔나'를 정리해 보낸다.

왜 만들었나:
  업무가 부장·서무·부과장 셋에게 흩어져 있고, 텔레그램은 직렬로 흘러가서
  '어느 일정에 무슨 업무를 마감해야 하는가'가 안 보인다. 대시보드에 손으로
  입력하는 건 더 번거로우니, 이미 오간 대화에서 자동으로 뽑는다.

역할 분담(아델 구조 그대로):
  · 이 스크립트   = 수집 + 내무부 관련만 걸러내기 (판단 안 함) + 날짜계산 + 렌더 + 전송
  · claude -p    = 읽고 판단해서 **업무 목록 JSON** 을 만든다 (뇌)
  · 나가는 곳 두 군데 — 텔레그램 글 / 업무보드(본인 Firebase 프로젝트 · workboard_auto)

JSON 하나가 원본이다:
  텔레그램 글도 대시보드도 같은 JSON 에서 나온다. 전에는 모델에게 글을 쓰게 했는데,
  그러면 대시보드용으로 또 시켜야 하고 둘이 어긋난다.
  D-day 계산과 '마감임박' 판정은 파이썬이 한다 — 모델에게 날짜 계산을 시키면 자주 틀린다.

지어내지 않는다:
  마감·상태는 원문에 있는 말에서만 뽑게 프롬프트로 못박는다.
  없으면 '없음'이라고 쓰게 하고, 추측한 날짜를 만들지 않게 한다.

실행 (⚠️ 시스템 python 말고 venv — telethon 이 거기 있다):
  venv\\Scripts\\python.exe scripts/worklog_brief.py            # 지금 1회 수집→판단→전송
  venv\\Scripts\\python.exe scripts/worklog_brief.py --dry      # 전송 안 함(화면 출력)
  venv\\Scripts\\python.exe scripts/worklog_brief.py --days 7   # 훑는 기간(기본 7일)
  venv\\Scripts\\python.exe scripts/worklog_brief.py --collect-only   # 다이제스트만 만들고 끝
  venv\\Scripts\\python.exe scripts/worklog_brief.py --no-telegram     # 업무보드만 갱신
  venv\\Scripts\\python.exe scripts/worklog_brief.py --no-dashboard    # 텔레그램만

작업스케줄러: 매일 13:00, 17:00, 21:00 각 1회.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent    # 기능은 features/ 안에 있다
sys.path.insert(0, str(PROJECT_ROOT))                    # brain·tg 를 쓰려고
from brain import HOME_DIR                                # 내 것은 사용자 폴더에

_v = PROJECT_ROOT / "vendor"                             # 딸려온 라이브러리 먼저
if _v.exists() and str(_v) not in sys.path:
    sys.path.insert(0, str(_v))


# ── 설정 읽기 / 텔레그램 보내기 ───────────────────────────────────────
# 원래는 저장소의 다른 스크립트를 끌어 썼다. 이 꾸러미는 혼자 돌아야 하므로 여기 둔다.

CONFIG_FILE = HOME_DIR / "config.json"


def load_config() -> dict:
    """마법사가 써 둔 설정. 이게 기본이고 .env 는 옛 방식(직접 편집)용이다."""
    try:
        return json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def save_config(cfg: dict) -> None:
    CONFIG_FILE.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")


def load_env() -> dict:
    """설정값 한 뭉치. config.json 이 우선, 없으면 .env.

    cp949 로 읽으면 한글이 든 .env 가 깨진다 — UTF-8 로 강제한다."""
    env = {k.upper(): str(v) for k, v in load_config().items() if not isinstance(v, (dict, list))}
    p = HOME_DIR / ".env"
    if p.exists():
        for line in p.read_text(encoding="utf-8-sig", errors="replace").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                env.setdefault(k.strip(), v.strip().strip('"').strip("'"))
    return env


def send_message(text: str, chat_id: str = "") -> bool:
    """브리핑을 나에게 보낸다.

    기본은 봇 — 알림이 따로 떠서 놓치지 않는다.
    봇을 안 만들었으면 내 계정으로 '저장한 메시지' 에 보낸다(설치가 그만큼 짧아진다).
    """
    cfg = load_config()
    token = (cfg.get("telegram_bot_token") or "").strip()
    target = chat_id or str(cfg.get("admin_telegram_id") or "").strip()
    if token and target:
        try:
            import bot
            return bot.send(token, target, text)
        except Exception as e:                               # noqa: BLE001
            print(f"[send] 봇 실패 — {type(e).__name__}: {e}", file=sys.stderr)
            return False
    try:                                                     # 봇이 없으면 저장한 메시지
        import tg
        aid, ah = tg.app_keys(cfg)
        if aid and ah:
            return tg.send_saved(aid, ah, text)
    except Exception as e:                                   # noqa: BLE001
        print(f"[send] 저장한 메시지 실패 — {type(e).__name__}: {e}", file=sys.stderr)
    print("[send] 보낼 곳이 없습니다 — 설정을 확인하십시오.", file=sys.stderr)
    return False


def _send_via_bot(text: str, chat_id: str = "") -> bool:
    """봇으로 보내기(설정에 토큰이 있을 때). 4096자 한도라 줄 단위로 끊는다."""
    import urllib.request
    env = load_env()
    cfg = load_config()                                      # 마법사가 저장한 곳이 먼저다
    token = cfg.get("telegram_bot_token") or env.get("TELEGRAM_BOT_TOKEN")
    target = (chat_id or cfg.get("admin_telegram_id")
              or env.get("ADMIN_TELEGRAM_ID"))
    if not (token and target):
        print("[send] 보낼 곳이 없습니다 — 설치 화면(2단계)에서 봇을 먼저 만들어 주십시오.",
              file=sys.stderr)
        return False
    chunks, buf = [], ""
    for line in (text or "(내용 없음)").split("\n"):
        if len(buf) + len(line) + 1 > 3900:
            chunks.append(buf)
            buf = ""
        buf += line + "\n"
    if buf:
        chunks.append(buf)
    ok = True
    for chunk in chunks:
        body = json.dumps({"chat_id": target, "text": chunk,
                           "disable_web_page_preview": True}).encode()
        req = urllib.request.Request(
            f"https://api.telegram.org/bot{token}/sendMessage",
            data=body, headers={"Content-Type": "application/json"})
        try:
            urllib.request.urlopen(req, timeout=30)
        except Exception as e:                               # noqa: BLE001
            print(f"[send] 실패: {e}", file=sys.stderr)
            ok = False
    return ok


for _s in (sys.stdout, sys.stderr):
    try:
        _s.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, ValueError):
        pass

KST = timezone(timedelta(hours=9))
ROOMS_FILE = HOME_DIR / "data" / "worklog_rooms.json"
DIGEST_FILE = HOME_DIR / "data" / "worklog_digest.txt"
BOARD_FILE = HOME_DIR / "data" / "worklog_board.json"      # 업무보드에 올라가는 것과 같은 내용
STAMP_FILE = HOME_DIR / "data" / "worklog_last_sent.txt"     # 마지막 브리핑 시각(=이후 새 글 표시용)

# 내무부 일로 볼 말들 — mixed 방에서 이 말이 없으면 타부서 일로 보고 버린다.
NAEMU = re.compile(
    load_env().get("MY_KEYWORDS", "").strip() or r"보고|취합|마감|제출|공지|확인|요청|점검"
    r"|심방|신앙관리|단계향상|전입|전출|부구역장|구역모임|구역예배|치리|사명자|월례회|릴레이\s*기도"
    r"|성도\s*단계|환자증|좌식|QR|인증|미담|열매|활동자")

# 내용 없는 반응 — 업무 진척으로 보지 않는다.
ACK = re.compile(
    r"^(아멘+|넵+|네+|예+|옙|감사(합니다|해요|드립니다)?|고생(하셨|많으)|수고(하셨|하세요)?"
    r"|확인(했습니다|하겠습니다|했어요)?|알겠습니다|알겠어요|ㅇㅇ|ㅋ+|ㅎ+|👍|🙏|❤|~+|\.+"
    r"|\[첨부\]|화이팅|파이팅|좋습니다|좋아요|굿|오케이|ok|okay)[\s!.~♡❤🙏👍👏😊😂ㅋㅎ]*$", re.I)

# 방은 내무부인데 내용은 일이 아닌 것 — 훑을 가치가 없다.
JUNK = re.compile(r"막국수|메뉴\s*주문|점심|저녁\s*뭐|밥은|맥날|커피|팥빙수|축구|농구|훈련일정|생일|반지")


# 훑을 방 — 부장님이 직접 지정한 목록(2026-08-15).
# core  = 내무부 전용 방. 전부 읽는다.
# mixed = 타부서가 섞인 방. 내가 쓴 글 + 내무부 관련 글만 읽는다.
# data/worklog_rooms.json 을 두면 그게 우선한다(방이 새로 생기면 거기서 고친다).
# 내 부서 전용 — 통째로 읽는다.
# 여긴 비워 둔다 — worklog_rooms.json 에 본인 방을 적어라(list_rooms.py 로 ID 를 뽑는다).
ROOMS_CORE: dict[str, int] = {}
# 타부서 섞임 — 내 것만 골라 읽는다.
# 여긴 비워 둔다 — worklog_rooms.json 에 본인 방을 적어라(list_rooms.py 로 ID 를 뽑는다).
ROOMS_MIXED: dict[str, int] = {}


BRIEF_MARK = "📋"                                             # 브리핑 첫 글자 — 이걸로 내 글을 알아본다


def _load_rooms() -> tuple[dict, dict]:
    cfg = load_config()                                      # 마법사가 고른 방
    if cfg.get("rooms"):
        r = cfg["rooms"]
        return r.get("core", {}), r.get("mixed", {})
    if ROOMS_FILE.exists():
        cfg = json.loads(ROOMS_FILE.read_text(encoding="utf-8"))
        return cfg.get("core", ROOMS_CORE), cfg.get("mixed", ROOMS_MIXED)
    return ROOMS_CORE, ROOMS_MIXED


def _last_sent() -> datetime | None:
    try:
        return datetime.fromisoformat(STAMP_FILE.read_text(encoding="utf-8").strip())
    except (OSError, ValueError):
        return None


def _stamp_now() -> None:
    try:
        STAMP_FILE.parent.mkdir(parents=True, exist_ok=True)
        STAMP_FILE.write_text(datetime.now(KST).isoformat(timespec="seconds"), encoding="utf-8")
    except OSError:
        pass


# ------------------------------------------------------------------ 수집
def collect(days: int) -> str:
    """지정한 방들에서 최근 days일 메시지를 읽어 다이제스트 텍스트로. 요약하지 않는다(원문 보존)."""
    try:
        from telethon.sync import TelegramClient
    except ImportError:
        raise SystemExit("telethon 이 없습니다 — pip install telethon")

    env = load_env()
    cfg = load_config()                                      # 마법사가 저장한 곳이 먼저다
    api_id = (cfg.get("tg_api_id") or env.get("TELEGRAM_API_ID")
              or os.environ.get("TELEGRAM_API_ID"))
    api_hash = (cfg.get("tg_api_hash") or env.get("TELEGRAM_API_HASH")
                or os.environ.get("TELEGRAM_API_HASH"))
    if not (api_id and api_hash):
        raise SystemExit("텔레그램 연결이 안 돼 있습니다 — 설치 화면(1단계)을 먼저 마쳐 주십시오.")

    core, mixed = _load_rooms()
    since = datetime.now(timezone.utc) - timedelta(days=days)
    mark_after = _last_sent()
    session = str(HOME_DIR / "data" / "telegram_user")

    rows, stat = [], []
    with TelegramClient(session, int(api_id), api_hash) as c:
        me = c.get_me()
        for kind, rooms in (("core", core), ("mixed", mixed)):
            for name, cid in rooms.items():
                n = 0
                try:
                    for m in c.iter_messages(cid, limit=None):
                        if m.date < since:
                            break
                        txt = (m.text or "").strip()
                        if not txt:
                            txt = "[첨부]" if m.media else ""
                        if not txt:
                            continue
                        if len(txt) <= 20 and ACK.match(txt):
                            continue
                        if JUNK.search(txt[:60]):
                            continue
                        # 타부서 섞인 방은 '내무부 일'로 보이는 것만 — 내가 쓴 글은 무조건 포함.
                        mine = (m.sender_id == me.id)
                        if kind == "mixed" and not mine and not NAEMU.search(txt):
                            continue
                        s = m.sender
                        who = "나" if mine else (getattr(s, "first_name", None)
                                                 or getattr(s, "title", None) or str(m.sender_id))
                        # 내가 보낸 브리핑은 재료가 아니다. 저장한 메시지로 보내면
                        # 그게 다음 회차의 입력이 되어 눈덩이처럼 부푼다(2026-08-27).
                        if (m.text or "").lstrip().startswith(BRIEF_MARK):
                            continue
                        new = bool(mark_after and m.date.astimezone(KST) > mark_after)
                        rows.append({"room": name, "ts": m.date.timestamp(), "new": new,
                                     "when": m.date.astimezone(KST).strftime("%m/%d %H:%M"),
                                     "who": who, "text": txt.replace("\n", " ⏎ ")})
                        n += 1
                except Exception as ex:                      # 방 하나 실패해도 나머지는 계속
                    stat.append(f"{name}: 읽기 실패({type(ex).__name__})")
                    continue
                stat.append(f"{name}: {n}건")

    rows.sort(key=lambda r: r["ts"])
    by: dict[str, list] = {}
    for r in rows:
        by.setdefault(r["room"], []).append(r)

    out = [f"# 수집 시각: {datetime.now(KST):%Y-%m-%d %H:%M} (최근 {days}일)",
           f"# 마지막 브리핑: {mark_after:%m/%d %H:%M}" if mark_after else "# 마지막 브리핑: 없음(첫 실행)",
           "# ★ 표시 = 마지막 브리핑 이후 올라온 글", ""]
    for room, ms in by.items():
        out.append(f"\n{'='*60}\n### {room} ({len(ms)}건)\n{'='*60}")
        for m in ms:
            out.append(f"{'★' if m['new'] else ' '}[{m['when']}] {m['who']}: {m['text']}")
    out.append("\n\n# 방별 수집량\n" + "\n".join(stat))
    return "\n".join(out)


# ------------------------------------------------------------------ 판단(뇌)
# 클로드는 **JSON 만** 만든다. 텔레그램 글도, 대시보드도 이 JSON 하나에서 나온다.
# (전에는 글을 만들게 했는데, 그러면 대시보드용으로 또 시켜야 하고 둘이 어긋난다.)
PROMPT = """아래는 {dept} {me} 의 텔레그램 방 {ndays}일치 원문이다.
함께 일하는 사람들과 나눈 업무 대화가 대부분이다. 지금은 {now} 이다.

이걸 읽고 **{dept} 업무 목록**을 JSON 으로만 출력해라. 설명·인사말·```표시 없이 JSON 만.

■ 반드시 지킬 것
- 마감일은 **원문에 적힌 말에서만** 뽑아라. 없으면 due 를 null 로 둬라. 날짜를 추측해서 만들지 마라.
- D-day 는 계산하지 마라. due 만 정확히 적으면 날짜 계산은 프로그램이 한다.
- state 가 "완료"인 것은 실제로 일이 끝났다는 말이 있을 때만. 인사말("~드렸습니다")을 완료로 세지 마라.
- 다른 부서 일, 잡담·식사·개인사는 넣지 마라. {dept} 일만.
- '이탈'이라는 말은 쓰지 마라. 사고처리·탈락이라고 써라.
- 근거(source)는 반드시 원문에 있는 실제 발언으로 채워라. 없으면 그 항목을 아예 만들지 마라.

■ 출력 형식 (이 스키마 그대로)
{{"items": [
  {{
    "title":  "일 이름 (짧게)",
    "state":  "미회신" | "진행중" | "완료",
    "due":    "2026-08-17" 또는 null,
    "detail": "지금 어디까지 왔는지 한 줄",
    "owner":  ["{me}"] 또는 함께 일하는 사람 이름, 또는 여럿,
    "waiting_on": "미회신일 때만 — 답을 기다리는 **사람 이름 하나**. 방 이름·직책설명 금지. 모르면 null",
    "source": {{"room": "방 이름", "who": "발언자", "when": "08/14 21:03"}}
  }}
]}}

state 설명:
- "미회신" = 지시하거나 물었는데 그 뒤로 답이 없는 것. 원문을 앞으로 읽어봐도 회신이 안 보이는 경우.
- "진행중" = 오가고 있으나 아직 안 끝난 것
- "완료"   = 끝났다는 말이 원문에 있는 것

■ 원문
{digest}
"""


def _parse_board(raw: str) -> dict | None:
    """클로드 출력에서 JSON 만 건져낸다. 못 건지면 None — 지어내지 않는다."""
    t = (raw or "").strip()
    if t.startswith("```"):                                   # ```json … ``` 방어
        t = re.sub(r"^```[a-zA-Z]*\n?", "", t)
        t = re.sub(r"\n?```\s*$", "", t)
    i, j = t.find("{"), t.rfind("}")
    if i < 0 or j <= i:
        return None
    try:
        obj = json.loads(t[i:j + 1])
    except json.JSONDecodeError:
        return None
    return obj if isinstance(obj.get("items"), list) else None


def think(digest: str, days: int) -> dict | None:
    """읽히고 업무 목록(JSON)을 받는다. 판단은 brain.py 가 한다."""
    now = datetime.now(KST).strftime("%m/%d %H:%M")
    prompt = PROMPT.format(ndays=days, now=now, digest=digest, me=ME, dept=DEPT)
    import brain
    out = brain.ask(load_config(), prompt)
    if out is None:
        return None
    board = _parse_board(out or "")
    if board is None:
        print(f"[think] JSON 을 못 받음 — 받은 글 {len((out or '').strip())}자",
              file=sys.stderr)
    return board


# ------------------------------------------------------------------ 날짜·정렬 (프로그램이 계산)
def _clean_who(v) -> str | None:
    """'누구를 기다리나' 는 사람 이름 하나여야 한다.

    프롬프트로 못박아도 방 이름표([core] …)나 '~ 담당자' 같은 설명이
    새어 나올 때가 있다(2026-08-27 실측). 화면에 그대로 뜨면 읽기 나쁘다.
    """
    if not isinstance(v, str):
        return None
    v = re.sub(r"\[[^\]]*\]", " ", v)                        # [core] 같은 이름표
    v = re.split(r"\s+등\s+|\s*[·,/]\s*", v)[0]              # '김서무 등 …' → 김서무
    v = re.sub(r"\s*(담당자|담당|측|쪽|님들)\s*$", "", v.strip())
    v = " ".join(v.split())
    return v[:20] or None


def enrich(board: dict) -> dict:
    """D-day·마감임박 판정은 여기서 한다 — 모델에게 날짜 계산을 시키지 않는다(자주 틀린다)."""
    today = datetime.now(KST).date()
    items = []
    for it in board.get("items", []):
        if not isinstance(it, dict) or not it.get("title"):
            continue
        it["waiting_on"] = _clean_who(it.get("waiting_on"))
        due, dday = it.get("due"), None
        if due:
            try:
                dday = (datetime.strptime(str(due)[:10], "%Y-%m-%d").date() - today).days
            except ValueError:
                due, dday = None, None                        # 형식이 이상하면 마감 없음으로
        state = it.get("state") if it.get("state") in ("미회신", "진행중", "완료") else "진행중"
        # 칸 배정: 마감이 3일 안이면(완료 아닌 한) 마감임박으로 끌어올린다.
        if state != "완료" and dday is not None and dday <= 3:
            bucket = "마감임박"
        else:
            bucket = {"미회신": "미회신", "완료": "완료"}.get(state, "진행중")
        items.append({**it, "due": due, "dday": dday, "state": state, "bucket": bucket})

    order = {"마감임박": 0, "미회신": 1, "진행중": 2, "완료": 3}
    items.sort(key=lambda x: (order[x["bucket"]],
                              x["dday"] if x["dday"] is not None else 999,
                              x["title"]))
    return {"as_of": datetime.now(KST).isoformat(timespec="seconds"),
            "days": None, "items": items,
            "counts": {b: sum(1 for i in items if i["bucket"] == b)
                       for b in ("마감임박", "미회신", "진행중", "완료")}}


# ------------------------------------------------------------------ 글로 뽑기
# 내 이름·부서는 설정에서 읽는다 — 코드에 박아두면 남이 그대로 쓸 수 없다.
ME = load_config().get("my_name", "").strip() or "나"
DEPT = load_config().get("my_dept", "").strip() or "내 업무"
WEEKDAY = "월화수목금토일"


def _who(item: dict) -> str:
    """담당자 표기. 본인은 '나', 그 밖은 이름. (본인이 없을 때 앞에 점이 붙지 않게)"""
    owners = item.get("owner") or []
    names = (["나"] if ME in owners else []) + [x for x in owners if x != ME]
    return "·".join(names)


def _mmdd(due: str) -> str:
    return str(due)[5:10].replace("-", "/")


def render_text(board: dict) -> str:
    """텔레그램은 '내가 뭘 해야 하나'만 간단히 — 전체 목록은 업무보드에 있다.

    한 업무는 한 칸에만 들어간다(위에서부터 먼저 잡힌 곳). 겹쳐 보이면 뭐가 급한지 흐려진다.
      1) 기한 지난 것    — 마감 지났는데 안 끝남
      2) 내 답을 기다리는 것 — waiting_on 이 나
      3) 마감 임박       — 마감 오늘~3일
      4) 답 기다리는 것  — 내가 물어놓고 회신 없는 것
    D-day 는 enrich() 가 오늘 기준으로 계산해 둔 값을 그대로 쓴다.
    """
    now = datetime.fromisoformat(board["as_of"])
    overdue, answer, soon, waiting, rest, done = [], [], [], [], [], []
    for it in board["items"]:
        if it.get("state") == "완료":
            done.append(it)
            continue
        d = it.get("dday")
        if d is not None and d < 0:
            overdue.append(it)
        elif it.get("waiting_on") == ME:
            answer.append(it)
        elif d is not None and d <= 3:
            soon.append(it)
        elif it.get("waiting_on"):
            waiting.append(it)
        else:
            rest.append(it)
    overdue.sort(key=lambda x: x["dday"])                    # 많이 지난 것부터
    soon.sort(key=lambda x: x["dday"])                       # 급한 것부터

    out = [f"📋 {DEPT} 업무요약 — {now.month}/{now.day}({WEEKDAY[now.weekday()]})"]

    if overdue:
        out.append(f"\n🔴 기한 지난 것 ({len(overdue)})")
        for i in overdue:
            out.append(f"· {i['title']} — D+{-i['dday']} (마감 {_mmdd(i['due'])})")

    if answer:
        out.append(f"\n🟠 내 답을 기다리는 것 ({len(answer)})")
        for i in answer:
            room = (i.get("source") or {}).get("room", "")
            out.append(f"· {i['title']}" + (f" — {room}" if room else ""))

    if soon:
        out.append(f"\n🟡 마감 임박 ({len(soon)})")
        for i in soon:
            when = "오늘" if i["dday"] == 0 else f"D-{i['dday']}"
            out.append(f"· {i['title']} — {when} ({_mmdd(i['due'])}) {_who(i)}".rstrip())

    if waiting:
        out.append(f"\n⏳ 답 기다리는 것 ({len(waiting)})")
        for i in waiting:
            out.append(f"· {i['title']} — {i['waiting_on']}")

    if not (overdue or answer or soon or waiting):
        out.append("\n급한 것 없음 — 기한 지난 것도, 답할 것도 없습니다.")

    out.append(f"\n그 밖에 진행중 {len(rest)}건 · 최근 완료 {len(done)}건")
    out.append(f"({now:%m/%d %H:%M} 수집 · 자세한 건 업무보드)")
    return "\n".join(out)


# ------------------------------------------------------------------ 업무보드로 올리기
# 업무보드는 본인 Firebase 프로젝트를 따로 쓴다 — 다른 대시보드와 섞지 않는다.
# 그쪽은 서비스계정 키가 없으므로, 기도 리포트(prayer_report.py)와 같은 방식으로
# 웹 API 키 + REST 로 쓴다. 규칙에 workboard_auto 공개 쓰기가 열려 있어야 한다.
WB_PROJECT = load_config().get("fb_project", "")     # 각자 본인 프로젝트
WB_API_KEY = load_config().get("fb_api_key", "")      # 웹 API 키 — 비밀 아님(클라이언트에 이미 박혀 있음)
WB_DOC_URL = ("https://firestore.googleapis.com/v1/projects/" + WB_PROJECT
              + "/databases/(default)/documents/workboard_auto/{doc}?key=" + WB_API_KEY)


def _fs_value(v):
    """파이썬 값 → Firestore REST 표현. 중첩 dict/list 까지."""
    if v is None:
        return {"nullValue": None}
    if isinstance(v, bool):
        return {"booleanValue": v}
    if isinstance(v, int):
        return {"integerValue": str(v)}
    if isinstance(v, float):
        return {"doubleValue": v}
    if isinstance(v, dict):
        return {"mapValue": {"fields": {k: _fs_value(x) for k, x in v.items()}}}
    if isinstance(v, (list, tuple)):
        return {"arrayValue": {"values": [_fs_value(x) for x in v]}}
    return {"stringValue": str(v)}


def push_workboard(board: dict) -> bool:
    """업무보드가 읽을 자리에 올린다 — workboard_auto/latest(현재) + workboard_auto/{시각}(이력).

    이력을 남기는 게 요점이다. 텔레그램은 흘러가서 '이 일이 며칠째 안 움직이는지'가 안 보인다.
    """
    try:
        import requests
    except ImportError:
        print("[workboard] requests 가 없습니다", file=sys.stderr)
        return False
    body = {"fields": {k: _fs_value(v) for k, v in board.items()}}
    stamp = datetime.fromisoformat(board["as_of"]).strftime("%Y%m%d-%H%M")
    ok = True
    for doc in ("latest", stamp):
        try:
            r = requests.patch(WB_DOC_URL.format(doc=doc), json=body, timeout=30)
            if r.status_code >= 400:
                print(f"[workboard] {doc} 쓰기 실패 {r.status_code} — {r.text[:300]}", file=sys.stderr)
                ok = False
        except Exception as e:
            print(f"[workboard] {doc} 쓰기 실패 — {type(e).__name__}: {e}", file=sys.stderr)
            ok = False
    return ok


# ------------------------------------------------------------------ 전송
LIMIT = 3800                                                 # 텔레그램 1메시지 상한(4096)에 여유


def split_chunks(text: str, limit: int = LIMIT) -> list[str]:
    """줄 경계에서 끊는다 — 항목('· …' 한 줄)이 두 메시지에 걸쳐 잘리지 않게.

    전에는 text[i:i+3800] 으로 무조건 잘라서 "…출결 당일·최종" / "데이터 담임강사님…"
    처럼 낱말 한가운데가 쪼개졌다(2026-08-15 실전 발송에서 확인).
    한 줄 자체가 limit 을 넘으면 그 줄은 어쩔 수 없이 잘라 넣는다.
    """
    chunks: list[str] = []
    cur = ""
    for line in text.split("\n"):
        while len(line) > limit:                             # 지나치게 긴 한 줄 — 잘라낼 수밖에
            if cur:
                chunks.append(cur)
                cur = ""
            chunks.append(line[:limit])
            line = line[limit:]
        cand = line if not cur else cur + "\n" + line
        if len(cand) > limit:
            chunks.append(cur)
            cur = line
        else:
            cur = cand
    if cur:
        chunks.append(cur)
    return chunks


def send(text: str) -> bool:
    ok = True
    for chunk in split_chunks(text):
        if chunk.strip():
            ok = send_message(chunk) and ok
    return ok


def main_argv(argv: list | None = None) -> int:
    """main() 과 같지만 인자를 받아서 돈다 — main.py 가 이렇게 부른다."""
    try:                                                     # 클로드 자리·안내를 먼저 챙긴다
        import link
        link.ensure()
    except Exception:                                        # noqa: BLE001
        pass
    ap = argparse.ArgumentParser()
    ap.add_argument("--days", type=int, default=7)
    ap.add_argument("--dry", action="store_true", help="전송·업로드 안 하고 화면에 출력")
    ap.add_argument("--collect-only", action="store_true", help="다이제스트만 만들고 끝")
    ap.add_argument("--no-dashboard", action="store_true", help="업무보드(Firestore)에 안 올림")
    ap.add_argument("--no-telegram", action="store_true", help="텔레그램 발송 안 함(업무보드만)")
    a = ap.parse_args(argv)

    digest = collect(a.days)
    DIGEST_FILE.parent.mkdir(parents=True, exist_ok=True)
    DIGEST_FILE.write_text(digest, encoding="utf-8")
    print(f"수집 완료 — {DIGEST_FILE} ({len(digest):,}자)")
    if a.collect_only:
        return 0

    raw = think(digest, a.days)
    if raw is None:
        # 못 만들었으면 지어내지 말고 못 만들었다고만 알린다.
        msg = "⚠️ 업무현황 브리핑을 만들지 못했습니다 (claude 실행 실패·시간초과·JSON 파싱 실패). 수집 원문은 남아 있습니다."
        print(msg, file=sys.stderr)
        if not (a.dry or a.no_telegram):
            send(msg)
        return 1

    board = enrich(raw)
    board["days"] = a.days
    BOARD_FILE.write_text(json.dumps(board, ensure_ascii=False, indent=2), encoding="utf-8")
    c = board["counts"]
    print(f"판단 완료 — 업무 {len(board['items'])}건 "
          f"(마감임박 {c['마감임박']} / 미회신 {c['미회신']} / 진행중 {c['진행중']} / 완료 {c['완료']})")

    text = render_text(board)
    if a.dry:
        print("\n" + text)
        return 0

    ok = True
    # 대시보드는 방금 쓴 파일(BOARD_FILE)을 읽는다 — 계정도 인터넷도 필요 없다.
    # 파이어베이스는 '폰에서도 보고 싶다' 할 때만 켠다.
    if not a.no_dashboard and WB_PROJECT and WB_API_KEY:
        ok = push_workboard(board) and ok
        print("업무보드(웹) 갱신" if ok else "업무보드(웹) 갱신 실패")
    if not a.no_telegram:
        sent = send(text)
        print("전송 완료" if sent else "전송 실패")
        ok = sent and ok
        # 시각은 **텔레그램으로 실제 보냈을 때만** 찍는다.
        # ★ 는 '지난 브리핑 이후 새로 생긴 일' 표시인데, 안 보냈으면 부장님이 그 브리핑을
        # 본 적이 없다. 업무보드만 갱신하고 시각을 찍으면 다음 텔레 브리핑에서 ★ 가
        # 그만큼 밀려 '새로 생긴 일'이 적게 잡힌다(2026-08-15 --no-telegram 실행에서 확인).
        if sent:
            _stamp_now()
    return 0 if ok else 1


def main() -> int:
    return main_argv(None)


if __name__ == "__main__":
    raise SystemExit(main())
